<?php
if (!function_exists('rit_shortcode_blog')) {
    function rit_shortcode_blog($atts)
    {
        $atts = shortcode_atts(array(
            'title' => ' Blog',
            'post_layout' => 'grid',
            'columns' => 3,
            'cat' => '',
            'post_in' => '',
            'number' => 8,
            'excerpt' => 50,
            'view_more' => false,
            'el_class' => ''
        ), $atts);

        $layout_type = ($atts['post_layout'] != '') ? $atts['post_layout'] : 'large';

        return rit_get_template_part('shortcode', 'blog-' . $layout_type, array('atts' => $atts));
    }
}
add_shortcode('blog', 'rit_shortcode_blog');

add_action('vc_before_init', 'rit_blog_integrate_vc');

if (!function_exists('rit_blog_integrate_vc')) {
    function rit_blog_integrate_vc()
    {
        vc_map(array(
            'name' => __('RIT Blog', 'ri-ghost'),
            'base' => 'blog',
            'category' => __('RIT', 'ri-ghost'),
            'icon' => 'rit-blog',
            "params" => array(
                array(
                    "type" => "textfield",
                    "heading" => __("Title", 'ri-ghost'),
                    "param_name" => "title",
                    "value" => "Blog",
                    "admin_label" => true
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Blog Layout", 'ri-ghost'),
                    "param_name" => "post_layout",
                    'std' => 'grid',
                    "value" => array(
                        __('Full', 'ri-ghost' ) => 'full',
                        __('List', 'ri-ghost' ) => 'list',
                        __('Grid', 'ri-ghost' ) => 'grid',
                        __('List then title', 'ri-ghost' ) => 'list-then-title',
                    ),
                    "admin_label" => true
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Columns", 'ri-ghost'),
                    "param_name" => "columns",
                    'dependency' => Array('element' => 'post_layout', 'value' => array('grid')),
                    'std' => '3',
                    "value" => array(
                        __('1', 'ri-ghost' ) => 1,
                        __('2', 'ri-ghost' ) => 2,
                        __('3', 'ri-ghost' ) => 3,
                        __('4', 'ri-ghost' ) => 4
                    )
                ),
                array(
                    "type" => "rit_post_categories",
                    "heading" => __("Category IDs", 'ri-ghost'),
                    "description" => __("Select category", 'ri-ghost'),
                    "param_name" => "cat",
                    "admin_label" => true
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Post IDs", 'ri-ghost'),
                    "description" => __("comma separated list of post ids", 'ri-ghost'),
                    "param_name" => "post_in"
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Posts Count", 'ri-ghost'),
                    "param_name" => "number",
                    "value" => '8'
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Excerpt Length", 'ri-ghost'),
                    "param_name" => "excerpt",
                    "value" => '50'
                ),
                array(
                    'type' => 'checkbox',
                    'heading' => __("Show View More", 'ri-ghost'),
                    'param_name' => 'view_more',
                    'std' => 'no',
                    'value' => array(__('Yes', 'js_composer') => 'yes')
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __( 'Extra class name', 'ri-ghost' ),
                    'param_name' => 'el_class',
                    'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'ri-ghost' )
                )
            )
        ));
    }
}
