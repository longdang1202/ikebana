<?php
if (!function_exists('rit_shortcode_contact')) {
    function rit_shortcode_contact($atts)
    {
        $atts = shortcode_atts(array(
            'title' => 'Contact Form',
            'shortcode' => '',
            'style' => 'suspensory',
            'el_class' => ''
        ), $atts);

        return rit_get_template_part('shortcode', 'contact-form', array('atts' => $atts));
    }
}

add_shortcode('rit_contact', 'rit_shortcode_contact');

add_action('vc_before_init', 'rit_contact_integrate_vc');

if (!function_exists('rit_contact_integrate_vc')) {
    function rit_contact_integrate_vc()
    {
        $args = array('post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1);
        if( $cf7Forms = get_posts( $args ) ){
            $list_contact = array();
            foreach($cf7Forms as $cf7Form){
                $list_contact[$cf7Form->post_title] = $cf7Form->ID . '-' . $cf7Form->post_title;
            }
        }
        vc_map(array(
            'name' => __('RIT Contact Form', 'ri-ghost'),
            'base' => 'rit_contact',
            'category' => __('RIT', 'ri-ghost'),
            'icon' => 'rit-blog',
            "params" => array(
                array(
                    "type" => "textfield",
                    "heading" => __("Title", 'ri-ghost'),
                    "param_name" => "title",
                    "admin_label" => true,
                    "value" => 'Contact Form'
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Choose Contact Form", 'ri-ghost'),
                    "param_name" => "shortcode",
                    'std' => '',
                    "value" => $list_contact,
                    "admin_label" => true
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Contact Form Style", 'ri-ghost'),
                    "param_name" => "style",
                    'std' => 'suspensory',
                    "value" => array(
                        __('Default', 'ri-ghost' ) => 'default',
                        __('Suspensory', 'ri-ghost' ) => 'suspensory',
                    ),
                    "admin_label" => true
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __( 'Extra class name', 'ri-ghost' ),
                    'param_name' => 'el_class',
                    'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'ri-ghost' )
                )
            )
        ));
    }
}
