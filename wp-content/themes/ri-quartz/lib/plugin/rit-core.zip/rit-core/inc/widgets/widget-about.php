<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */

if (!class_exists('RITAbout')) {
    class RITAbout extends WP_Widget
    {
        public function __construct()
        {
            $widget_ops = array('classname' => 'widget-about-us', 'description' => esc_html__('Show about me.', 'rit-core'));

            $control_ops = array('id_base' => 'about-widget');

            parent::__construct('about-widget', esc_html__('RIT: About Me', 'rit-core'), $widget_ops, $control_ops);
        }

        public function widget($args, $instance)
        {
            extract($args);

            echo $before_widget;

            if ($instance['title']) {
                echo $before_title . $instance['title'] . $after_title;
            }
            $logo_src = '';
            if(!is_404()){
                $logo_src = get_post_meta(get_the_ID(), 'rit_logofooter_image', true);
            }
            ?>
            <?php if($instance['image_uri'] != '') { ?>
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img alt="<?php echo esc_html__('About Image', 'ri-quartz'); ?>" src="<?php echo ($logo_src != '' ? wp_get_attachment_url($logo_src) : esc_url($instance['image_uri'])) ; ?>" />
            </a>
            <?php } ?>
            <p><?php echo wp_kses( $instance['description'], array(
                    'div' => array(
                        'class' => array(),
                    ),
                    'p' => array(),
                    'br' => array(),
                    'span' => array(),
                    'i' => array(
                        'class' => array()
                    ),
                    'a' => array(
                        'href' => array()
                    )
                ) );; ?></p>
            <?php if($instance['enbale_social']){ ?>
            <?php echo do_shortcode('[rit_social name="no" icon="yes" class="about-social"]'); ?>
            <?php } ?>
            <?php

            echo $after_widget;
        }

        public function update($new_instance, $old_instance)
        {
            $instance = $old_instance;

            $instance['title'] = strip_tags($new_instance['title']);
            $instance['image_uri'] = $new_instance['image_uri'];
            $instance['enbale_social'] = $new_instance['enbale_social'];
            $instance['description'] = wp_kses( $new_instance['description'], array(
                'div' => array(
                    'class' => array(),
                ),
                'br' => array(),
                'p' => array(),
                'span' => array(),
                'i' => array(
                    'class' => array()
                ),
                'a' => array(
                    'href' => array()
                )
            ) );

            return $instance;
        }

        public function form($instance)
        {
            $defaults = array(
                'title' => esc_html__('About Me', 'rit-core'),
                'image_uri' => "",
                'enbale_social' => true,
                'description' => "",
            );
            $instance = wp_parse_args((array)$instance, $defaults); ?>
            <p>
                <label for="<?php echo $this->get_field_id('title'); ?>">
                    <strong><?php esc_html_e('Title', 'rit-core') ?>:</strong>
                    <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
                           name="<?php echo $this->get_field_name('title'); ?>"
                           value="<?php if (isset($instance['title'])) echo $instance['title']; ?>"/>
                </label>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('image_uri'); ?>">
                    <strong style="display: block; padding-bottom: 20px"><?php echo esc_html__('Image:', 'rit-core'); ?></strong>
                    <img class="custom_media_image" src="<?php if(!empty($instance['image_uri'])){echo $instance['image_uri'];} ?>" style="display:block; padding-bottom: 20px; max-width: 100%" />
                    <input type="text" class="widefat custom_media_url" name="<?php echo $this->get_field_name('image_uri'); ?>" id="<?php echo $this->get_field_id('image_uri'); ?>" value="<?php echo $instance['image_uri']; ?>">
                    <input style="margin-top: 10px" type="button" value="<?php _e( 'Upload Image', 'themename' ); ?>" class="button custom_media_upload" id="custom_image_uploader"/>
                </label>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('description'); ?>">
                    <strong><?php esc_html_e('Description', 'rit-core') ?>:</strong>
                    <textarea rows="8" cols="10" class="widefat" id="<?php echo $this->get_field_id('description'); ?>" name="<?php echo $this->get_field_name('description'); ?>"><?php if (isset($instance['description'])) echo $instance['description']; ?></textarea>
                </label>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id( 'enbale_social' ); ?>">
                    <strong><?php esc_html_e('Enable Social', 'rit-core') ?>:</strong>
                    <input class="checkbox" type="checkbox" <?php checked( $instance[ 'enbale_social' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'enbale_social' ); ?>" name="<?php echo $this->get_field_name( 'enbale_social' ); ?>" />
                </label>
            </p>
            <script type="text/javascript">
                jQuery(document).ready( function(){
                    function media_upload( button_class) {
                        var _custom_media = true,
                            _orig_send_attachment = wp.media.editor.send.attachment;
                        jQuery('body').on('click',button_class, function(e) {
                            var button_id ='#'+jQuery(this).attr('id');
                            /* console.log(button_id); */
                            var self = jQuery(button_id);
                            var send_attachment_bkp = wp.media.editor.send.attachment;
                            var button = jQuery(button_id);
                            var id = button.attr('id').replace('_button', '');
                            _custom_media = true;
                            wp.media.editor.send.attachment = function(props, attachment){
                                if ( _custom_media  ) {
                                    jQuery('.custom_media_id').val(attachment.id);
                                    jQuery('.custom_media_url').val(attachment.url);
                                    jQuery('.custom_media_image').attr('src',attachment.url).css('display','block');
                                } else {
                                    return _orig_send_attachment.apply( button_id, [props, attachment] );
                                }
                            }
                            wp.media.editor.open(button);
                            return false;
                        });
                    }
                    media_upload( '.custom_media_upload');
                });
            </script>
        <?php
        }
    }
}
add_action('widgets_init', 'rit_about_load_widgets');

function rit_about_load_widgets()
{
    register_widget('RITAbout');
}