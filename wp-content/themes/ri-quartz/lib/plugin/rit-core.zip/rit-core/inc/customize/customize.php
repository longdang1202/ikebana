<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */

require_once( ABSPATH . WPINC . '/class-wp-customize-control.php' );
require_once('classes/customize-category.php');
require_once('classes/customize-multi.php');
require_once('classes/customize-pic.php');
require_once('classes/customize-heading.php');
require_once('classes/customize-googlefont.php');
require_once('classes/customize-sidebar.php');
require_once('classes/customize-import-export.php');

require_once('includes/customize-import-export.php');
require_once('includes/customize-controller.php');
require_once('includes/customize-reset.php');

$rit_customize = RIT_Customize::getInstance();
$rit_customize->init();

