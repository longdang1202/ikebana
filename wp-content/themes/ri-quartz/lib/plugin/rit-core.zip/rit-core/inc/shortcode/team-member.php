<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */

function rit_shortcode_team_member($atts)
{

    $atts = shortcode_atts(
        array(
            'eb_slider' => "no",
            'num_slider' => "3",
            'num_smalldes' => "",
            'num_tablet' => "",
            'num_mobile' => "",
            'limit' => "3",
            'order' => "",
            'eb_position' => "",
            'eb_social' => "",
            'el_class'=> '',

        ), $atts);

    return rit_get_template_part('shortcode', 'team-member', array('atts' => $atts));
}

add_shortcode('rit_team_member', 'rit_shortcode_team_member');

add_action('vc_before_init', 'rit_team_member_integrate_vc');

if (!function_exists('rit_team_member_integrate_vc')) {
    function rit_team_member_integrate_vc()
    {
        vc_map(
            array(
                'name' => esc_html__('RIT Team Member', 'rit-core'),
                'base' => 'rit_team_member',
                'icon' => 'icon-rit',
                'category' => esc_html__('RIT', 'rit-core'),
                'description' => esc_html__('Show team member', 'rit-core'),
                'params' => array(
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__( 'Enable Slider', 'rit-core' ),
                        'param_name' => 'eb_slider',
                        'value' => array(
                            esc_html__( 'Yes', 'rit-core' ) => 'yes',
                            esc_html__( 'No', 'rit-core' ) => 'no'
                        ),
                        'std' => 'no',
                        'description' => ''
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__( 'Number Slider', 'rit-core' ),
                        'param_name' => 'num_slider',
                        'value' => array(
                            esc_html__( '1', 'rit-core' ) => '1',
                            esc_html__( '2', 'rit-core' ) => '2',
                            esc_html__( '3', 'rit-core' ) => '3',
                            esc_html__( '4', 'rit-core' ) => '4',
                            esc_html__( '6', 'rit-core' ) => '6'
                        ),
                        'description' => '',
                        'std' => '3'
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__( 'Number Small Destop', 'rit-core' ),
                        'param_name' => 'num_smalldes',
                        'value' => array(
                            esc_html__( '1', 'rit-core' ) => '1',
                            esc_html__( '2', 'rit-core' ) => '2',
                            esc_html__( '3', 'rit-core' ) => '3',
                            esc_html__( '4', 'rit-core' ) => '4',
                            esc_html__( '6', 'rit-core' ) => '6'
                        ),
                        'description' => '',
                        'dependency' => Array('element' => 'eb_slider', 'value' => array('yes')),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__( 'Number Tablet', 'rit-core' ),
                        'param_name' => 'num_tablet',
                        'value' => array(
                            esc_html__( '1', 'rit-core' ) => '1',
                            esc_html__( '2', 'rit-core' ) => '2',
                            esc_html__( '3', 'rit-core' ) => '3',
                            esc_html__( '4', 'rit-core' ) => '4',
                            esc_html__( '6', 'rit-core' ) => '6'
                        ),
                        'description' => '',
                        'dependency' => Array('element' => 'eb_slider', 'value' => array('yes')),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__( 'Number Mobile', 'rit-core' ),
                        'param_name' => 'num_mobile',
                        'value' => array(
                            esc_html__( '1', 'rit-core' ) => '1',
                            esc_html__( '2', 'rit-core' ) => '2',
                            esc_html__( '3', 'rit-core' ) => '3',
                            esc_html__( '4', 'rit-core' ) => '4',
                            esc_html__( '6', 'rit-core' ) => '6'
                        ),
                        'description' => '',
                        'dependency' => Array('element' => 'eb_slider', 'value' => array('yes')),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__( 'Order', 'rit-core' ),
                        'param_name' => 'order',
                        'value' => array(
                            esc_html__( 'Descending', 'rit-core' ) => 'DESC',
                            esc_html__( 'Ascending', 'rit-core' ) => 'ASC'
                        ),
                        'description' => sprintf( esc_html__( 'Select ascending or descending order. More at %s.', 'rit-core' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__( 'Enable Position', 'rit-core' ),
                        'param_name' => 'eb_position',
                        'value' => array(
                            esc_html__( 'Yes', 'rit-core' ) => 'yes',
                            esc_html__( 'No', 'rit-core' ) => 'no'
                        ),
                        'std' => 'yes',
                        'description' => ''
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__( 'Enable Social', 'rit-core' ),
                        'param_name' => 'eb_social',
                        'value' => array(
                            esc_html__( 'Yes', 'rit-core' ) => 'yes',
                            esc_html__( 'No', 'rit-core' ) => 'no'
                        ),
                        'std' => 'yes',
                        'description' => ''
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__( 'Limit', 'rit-core' ),
                        'param_name' => 'limit',
                        'description' => esc_html__( 'Limit number.', 'rit-core' )
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__( 'Extra class name', 'rit-core' ),
                        'param_name' => 'el_class',
                        'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'rit-core' )
                    )
                )
            )
        );
    }
}
