<?php
if (!function_exists('rit_shortcode_listcate')) {
    function rit_shortcode_listcate($atts)
    {
        $atts = shortcode_atts(array(
            'title'	        => 'Title',
            'bg_title'	        => '#ffffff',
            'products_category'      => '',
            'el_class'      => '',
        ), $atts);

        return rit_get_template_part('shortcode', 'listcate', array('atts' => $atts));
    }
}
add_shortcode('listcate', 'rit_shortcode_listcate');

add_action('vc_before_init', 'rit_listcate_integrate_vc');

if (!function_exists('rit_listcate_integrate_vc')) {
    function rit_listcate_integrate_vc()
    {
        $menus = get_registered_nav_menus();
        $menu = array();
        foreach ( $menus as $location => $name ) {
            $menu[$name] = $location;
        }

        vc_map( array(
            "name"		=> __("RIT List Category", 'ri-ghost'),
            "base"		=> "listcate",
            "class"		=> "",
            'category' => esc_html__('RIT', 'rit-core'),
            "icon"      => "spb-icon-listcate",
            "wrapper_class" => "clearfix",
            "controls"	=> "full",
            "params"	=> array(
                array(
                    "type" => "textfield",
                    "heading" => __("Title", 'ri-ghost'),
                    "param_name" => "title",
                    "value" => "Title",
                    "description" => __("", 'ri-ghost')
                ),
                array(
                    "type" => "colorpicker",
                    "heading" => __("Background color title", 'ri-ghost'),
                    "param_name" => "bg_title",
                    "value" => "#ffffff",
                    "description" => __("Background color title", 'ri-ghost')
                ),
                array(
                    'type' => 'rit_product_categories',
                    'heading' => __('Select Product Category', 'ri-ghost'),
                    'param_name' => 'products_category',
                    'std' => ''
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Extra class name", 'ri-ghost'),
                    "param_name" => "el_class",
                    "value" => "",
                    "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'ri-ghost')
                )
            )
        ) );
    }
}
