<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */

if (!function_exists('rit_shortcode_news')) {
    function rit_shortcode_news($atts, $content)
    {
        $atts = shortcode_atts(array(
            'title' => '',
            'layout_type' => '',
            'cat' => '',
            'posts_per_page' => '4',
            'columns' => 2,
            'orderby' => 'date',
            'order' => 'DESC',
            'post__in' => '',
            'post__not_in' => '',
            'view_more' => false,
            'el_class' => ''
        ), $atts);

        $layout_type = ($atts['layout_type'] != '') ? $atts['layout_type'] : 'vertical';

        return rit_get_template_part('shortcode', 'news-'.$layout_type, array('atts' => $atts));
    }
}

add_shortcode('rit_news', 'rit_shortcode_news');

add_action('vc_before_init', 'rit_news_integrate_vc');

if (!function_exists('rit_news_integrate_vc')) {
    function rit_news_integrate_vc()
    {
        vc_map(
            array(
                'name' => esc_html__('RIT News', 'rit-core'),
                'base' => 'rit_news',
                'icon' => 'icon-rit',
                'category' => esc_html__('RIT', 'rit-core'),
                'description' => esc_html__('Get post and display for news', 'rit-core'),
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Title', 'rit-core'),
                        'value' => 6,
                        'param_name' => 'title',
                        'description' => esc_html__('Enter text used as shortcode title (Note: located above content element)', 'rit-core'),
                    ),
                    array(
                        'type' => 'rit_image_radio',
                        'heading' => esc_html__('Layout type', 'rit-core'),
                        'value' => array(
                            esc_html__(RIT_PLUGIN_URL.'assets/images/headline.png', 'rit-core') => 'headline',
                            esc_html__(RIT_PLUGIN_URL.'assets/images/horizontal.png', 'rit-core') => 'horizontal',
                            esc_html__(RIT_PLUGIN_URL.'assets/images/vertical.png', 'rit-core') => 'vertical',
                            esc_html__(RIT_PLUGIN_URL.'assets/images/normal.png', 'rit-core') => 'normal',
                        ),
                        'width' => '100px',
                        'height' => '70px',
                        'param_name' => 'layout_type',
                        'description' => esc_html__('Select layout type for display post', 'rit-core'),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__('Column', 'rit-core'),
                        "value" => array(
                            esc_html__('1', 'rit-core' ) => 1,
                            esc_html__('2', 'rit-core' ) => 2,
                            esc_html__('3', 'rit-core' ) => 3,
                            esc_html__('4', 'rit-core' ) => 4
                        ),
                        'std' => '2',
                        'param_name' => 'columns',
                        'description' => esc_html__('Display post with the number of column', 'rit-core'),
                    ),
                    array(
                        "type" => "rit_post_categories",
                        "heading" => esc_html__("Category IDs", 'rit-core'),
                        "description" => esc_html__("Select category", 'rit-core'),
                        "param_name" => "cat",
                        "admin_label" => true,
                        'description' => esc_html__('Select category which you want to get post in', 'rit-core'),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Number of post', 'rit-core'),
                        'value' => 6,
                        'param_name' => 'posts_per_page',
                        'description' => esc_html__('Number of post showing', 'rit-core'),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__('Order by', 'rit-core'),
                        'value' => array(
                            esc_html__('Date', 'rit-core') => 'date',
                            esc_html__('Random', 'rit-core') => 'ran',
                            esc_html__('Title', 'rit-core') => 'title',
                            esc_html__('Modified date', 'rit-core') => 'modified',
                        ),
                        'std' => 'date',
                        'param_name' => 'orderby',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => esc_html__('Order', 'rit-core'),
                        'value' => array(
                            esc_html__('DESC', 'rit-core') => 'DESC',
                            esc_html__('ASC', 'rit-core') => 'ASC',
                        ),
                        'std' => 'date',
                        'param_name' => 'order',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__("Exclude Post IDs", 'rit-core'),
                        "description" => esc_html__("comma separated list of post ids", 'rit-core'),
                        "param_name" => "post__not_in"
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__("Include Post IDs", 'rit-core'),
                        "description" => esc_html__("comma separated list of post ids", 'rit-core'),
                        "param_name" => "post__in"
                    ),
                    array(
                        'type' => 'checkbox',
                        'heading' => esc_html__("Show View More", 'rit-core'),
                        'param_name' => 'view_more',
                        'std' => 'no',
                        'value' => array(esc_html__('Yes', 'rit-core') => 'yes')
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__( 'Extra class name', 'rit-core' ),
                        'param_name' => 'el_class',
                        'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'rit-core' )
                    )
                )
            )
        );
    }
}