(function ($) {

    $(document).ready(function(){
        $('.pic-select label img').click(function(){
            $(this).prev().prop('checked');
            $(this).closest('.pic-select').find('label').removeClass('selected');
            $(this).closest('label').addClass('selected');
        });

        // Handles setting the new value in the customizer.
        $('.pic-select label input').change(function() {

                // Get the name of the setting.
                var setting = $( this ).data('id');

                // Get the value of the currently-checked radio input.
                var image = $( this ).val();

                // Set the new value.
                wp.customize( setting, function( obj ) {
                    obj.set( image );
                } );
            }
        );

        function updateGoogleFontData(wrap){
            var data = {};

            data.family = wrap.find('.rit-customize-google-font-family').val();
            data.category = wrap.find('.rit-customize-google-font-family option[selected]').data('category');

            data.variants = new Array();
            wrap.find('.rit-customize-google-font-variant:checked').each(function(){
                data.variants.push($(this).val());
            })

            data.subsets = new Array();
            wrap.find('.rit-customize-google-font-subset:checked').each(function(){
                data.subsets.push($(this).val());
            })

            //console.log(data);
            wrap.find('.customize-input-google-font').val(JSON.stringify(data)).trigger( 'change');
        }

        $('.rit-customize-google-font-family').on('change', function(){

            var wrap = $(this).closest('.customize-wrap-rit_google_font');
            var target_option = $(this).find('option[value="'+$(this).val()+'"]');

            var variants = target_option.data('variants').split(',');
            var subsets = target_option.data('subsets').split(',');

            genderCheckbox(variants, 'variant', wrap);
            genderCheckbox(subsets, 'subset', wrap);

            updateGoogleFontData(wrap);

            bindEventSelectVariantsAndSubsets();

        });

        function genderCheckbox(data, type, wrap){
            var html = '';
            $.each(data, function( index, value ) {
                html += '<li><input class="rit-customize-google-font-'+type+'" type="checkbox" value="'+value+'">'+value+'</li>'
            });

            wrap.find('.rit-customize-font-'+type).html(html);
        }

        function bindEventSelectVariantsAndSubsets(){
            $('.rit-customize-google-font-variant, .rit-customize-google-font-subset').on('change', function(){

                var wrap = $(this).closest('.customize-wrap-rit_google_font');

                updateGoogleFontData( wrap );

            });
        }

        bindEventSelectVariantsAndSubsets();
    });



    var RIT_Customize_Import_Export = {

        init: function () {
            $('input[name=rit-export-button]').on('click', RIT_Customize_Import_Export._export);
            $('input[name=rit-import-button]').on('click', RIT_Customize_Import_Export._import);
        },

        _export: function () {
            window.location.href = RIT_Customize_Import_Export_Config.customizerURL + '?rit-export=' + RIT_Customize_Import_Export_Config.exportNonce;
        },

        _import: function () {
            var win = $(window),
                body = $('body'),
                form = $('<form class="rit-form" method="POST" enctype="multipart/form-data"></form>'),
                controls = $('.rit-import-controls'),
                file = $('input[name=rit-import-file]'),
                message = $('.rit-uploading');

            if ('' == file.val()) {
                alert(RIT_Customize_Import_Export_l10n.emptyImport);
            } else {
                win.off('beforeunload');
                body.append(form);
                form.append(controls);
                message.show();
                form.submit();
            }
        }
    };

    $(RIT_Customize_Import_Export.init);

})(jQuery);


