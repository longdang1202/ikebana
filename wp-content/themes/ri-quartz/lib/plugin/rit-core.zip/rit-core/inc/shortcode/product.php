<?php

/* ================================================================================== */
/*      Products Shortcode
/* ================================================================================== */
if (!function_exists('rit_shortcode_products')) {
    function rit_shortcode_products($atts, $content)
    {
        $atts = shortcode_atts(array(
            'title' => 'Product',
            'title_color' => '#ffffff',
            'post_type' => 'product',
            'products_layout' => 'layout-1',
            'enable_tab' => 0,
            'products_type' => 'products_carousel',
            'products_style' => '',
            'products_category' => '',
            'products_mode' => '',
            'column' => '1',
            'row' => '1',
            'column_smalldes' => '3',
            'column_tablet' => '2',
            'column_mobile' => '1',
            'border_wrap' => 'no',
            'posts_per_page' => 4,
            'paged' => -1,
            'show' => '',
            'thumb_image' => '',
            'thumb_title' => '',
            'thumb_des' => '',
            'thumb_price' => '',
            'thumb_link' => '',
            'countdown' => '0',
            'orderby' => '',
            'el_class' => '',
        ), $atts);

        $output = rit_get_template_part('shortcode', 'product', array('atts' => $atts));

        return $output;
    }
}

add_shortcode('rit_products', 'rit_shortcode_products');

add_action('vc_before_init', 'rit_product_integrate_vc');

if (!function_exists('rit_product_integrate_vc')) {
    function rit_product_integrate_vc()
    {
        vc_map(
            array(
                'name' => __('RIT Products', 'ri-ghost'),
                'base' => 'rit_products',
                'icon' => 'icon-rit',
                'category' => __('RIT', 'ri-ghost'),
                'description' => __('Show multiple products by ID or SKU.', 'ri-ghost'),
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => __('Title', 'ri-ghost'),
                        'value' => 'Product',
                        'param_name' => 'title',
                    ),
                    array(
                        'type' => 'colorpicker',
                        'heading' => __('Title Color', 'ri-ghost'),
                        'value' => '#ffffff',
                        'param_name' => 'title_color',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Enable Tab', 'ri-ghost'),
                        'value' => array(
                            __('Yes', 'ri-ghost') => '1',
                            __('No', 'ri-ghost') => '0'
                        ),
                        'param_name' => 'enable_tab',
                        'std' => '0'
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Select Layout', 'ri-ghost'),
                        'value' => array(
                            __('Layout 1', 'ri-ghost') => 'layout-1',
                            __('Layout 2', 'ri-ghost') => 'layout-2',
                            __('Layout 3', 'ri-ghost') => 'layout-3',
                            __('Layout 4', 'ri-ghost') => 'layout-4',
                            __('Layout 5', 'ri-ghost') => 'layout-5'
                        ),
                        'param_name' => 'products_layout',
                        'std' => ''
                    ),
                    array(
                        'type' => 'checkbox',
                        'heading' => __('Select Mode', 'ri-ghost'),
                        'value' => array(
                            __('New Arrivals', 'ri-ghost') => 'new',
                            __('Best Seller', 'ri-ghost') => 'best_seller',
                            __('Feature', 'ri-ghost') => 'feature',
                            __('On Sale', 'ri-ghost') => 'sale'
                        ),
                        'param_name' => 'products_mode',
                        'std' => '',
                        'dependency' => Array('element' => 'products_layout', 'value' => array('layout-4')),
                    ),
                    array(
                        'type' => 'attach_images',
                        'heading' => __('Thumbnail Image', 'ri-ghost'),
                        'value' => '',
                        'description' => 'Thumbnail for list product',
                        'param_name' => 'thumb_image',
                        'dependency' => Array('element' => 'products_layout', 'value' => array('layout-2')),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Title Thumbnail', 'ri-ghost'),
                        'value' => '',
                        'description' => 'Title Thumbnail for list product',
                        'param_name' => 'thumb_title',
                        'dependency' => Array('element' => 'products_layout', 'value' => array('layout-2')),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Price Thumbnail', 'ri-ghost'),
                        'value' => '',
                        'description' => 'Price Thumbnail for list product',
                        'param_name' => 'thumb_price',
                        'dependency' => Array('element' => 'products_layout', 'value' => array('layout-2')),
                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => __('Description Thumbnail', 'ri-ghost'),
                        'value' => '',
                        'description' => 'Description Thumbnail for list product',
                        'param_name' => 'thumb_des',
                        'dependency' => Array('element' => 'products_layout', 'value' => array('layout-2')),
                    ),
                    array(
                        'type' => 'vc_link',
                        'heading' => __('Link Thumbnail', 'ri-ghost'),
                        'value' => '',
                        'description' => 'Link Thumbnail for list product',
                        'param_name' => 'thumb_link',
                        'dependency' => Array('element' => 'products_layout', 'value' => array('layout-2')),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Select type', 'ri-ghost'),
                        'value' => array(
                            __('Grid', 'ri-ghost') => 'products_grid',
                            __('Carousel', 'ri-ghost') => 'products_carousel'
                        ),
                        'param_name' => 'products_type',
                        'std' => ''
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Product size', 'ri-ghost'),
                        'value' => array(
                            __('Normal', 'ri-ghost') => 'normal',
                            __('Medium', 'ri-ghost') => 'medium',
                            __('Mini', 'ri-ghost') => 'mini'
                        ),
                        'param_name' => 'products_style',
                        'std' => 'normal'
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Border wrap', 'ri-ghost'),
                        'value' => array(
                            __('Yes', 'ri-ghost') => 'yes',
                            __('No', 'ri-ghost') => 'no'
                        ),
                        'param_name' => 'border_wrap',
                        'std' => 'no',
                    ),
                    array(
                        'type' => 'rit_product_categories',
                        'heading' => __('Product Category', 'ri-ghost'),
                        'param_name' => 'products_category',
                        'std' => ''
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Column count', 'ri-ghost'),
                        'value' => array(
                            __('1 Columns', 'ri-ghost') => '1',
                            __('2 Columns', 'ri-ghost') => '2',
                            __('3 Columns', 'ri-ghost') => '3',
                            __('4 Columns', 'ri-ghost') => '4',
                            __('6 Columns', 'ri-ghost') => '6'
                        ),
                        'std' => '1',
                        'param_name' => 'column',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Row count', 'ri-ghost'),
                        'value' => array(
                            __('1 Columns', 'ri-ghost') => '1',
                            __('2 Columns', 'ri-ghost') => '2',
                            __('3 Columns', 'ri-ghost') => '3',
                            __('4 Columns', 'ri-ghost') => '4',
                            __('5 Columns', 'ri-ghost') => '5',
                            __('6 Columns', 'ri-ghost') => '6'
                        ),
                        'std' => '1',
                        'param_name' => 'row',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Column For Small Destop', 'ri-ghost'),
                        'value' => array(
                            __('1 Columns', 'ri-ghost') => '1',
                            __('2 Columns', 'ri-ghost') => '2',
                            __('3 Columns', 'ri-ghost') => '3',
                            __('4 Columns', 'ri-ghost') => '4',
                            __('5 Columns', 'ri-ghost') => '5',
                            __('6 Columns', 'ri-ghost') => '6'
                        ),
                        'std' => '3',
                        'param_name' => 'column_smalldes',
                        'dependency' => Array('element' => 'products_type', 'value' => array('products_carousel')),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Column For Tablet', 'ri-ghost'),
                        'value' => array(
                            __('1 Columns', 'ri-ghost') => '1',
                            __('2 Columns', 'ri-ghost') => '2',
                            __('3 Columns', 'ri-ghost') => '3',
                            __('4 Columns', 'ri-ghost') => '4',
                            __('5 Columns', 'ri-ghost') => '5',
                            __('6 Columns', 'ri-ghost') => '6'
                        ),
                        'std' => '2',
                        'param_name' => 'column_tablet',
                        'dependency' => Array('element' => 'products_type', 'value' => array('products_carousel')),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Column For Mobile', 'ri-ghost'),
                        'value' => array(
                            __('1 Columns', 'ri-ghost') => '1',
                            __('2 Columns', 'ri-ghost') => '2',
                            __('3 Columns', 'ri-ghost') => '3',
                            __('4 Columns', 'ri-ghost') => '4',
                            __('5 Columns', 'ri-ghost') => '5',
                            __('6 Columns', 'ri-ghost') => '6'
                        ),
                        'std' => '1',
                        'param_name' => 'column_mobile',
                        'dependency' => Array('element' => 'products_type', 'value' => array('products_carousel')),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Count', 'ri-ghost'),
                        'value' => 6,
                        'param_name' => 'posts_per_page',
                        'std' => '4'
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Show', 'ri-ghost'),
                        'value' => array(
                            __('All', 'ri-ghost') => '',
                            __('Featured', 'ri-ghost') => 'featured',
                            __('Onsale', 'ri-ghost') => 'onsale',
                            __('Best Selling', 'ri-ghost') => 'best-selling'
                        ),
                        'std' => '',
                        'param_name' => 'show',
                        'dependency' => Array('element' => 'enable_tab', 'value' => array('0')),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Show Count Down Sales', 'ri-ghost'),
                        'value' => array(
                            __('Yes', 'ri-ghost') => '1',
                            __('No', 'ri-ghost') => '0'
                        ),
                        'std' => '0',
                        'param_name' => 'countdown',
                        'dependency' => Array('element' => 'show', 'value' => array('onsale')),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __('Order by', 'ri-ghost'),
                        'value' => array(
                            __('Date', 'ri-ghost') => 'date',
                            __('Menu order', 'ri-ghost') => 'menu_order',
                            __('Title', 'ri-ghost') => 'title',
                        ),
                        'std' => 'date',
                        'param_name' => 'orderby',
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Custom Class', 'ri-ghost'),
                        'value' => '',
                        'param_name' => 'el_class',
                        'description' => __('You can use the custom CSS class for this module', 'ri-ghost'),
                    )
                )
            )
        );
    }
}