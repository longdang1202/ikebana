<?php
if (!function_exists('rit_shortcode_googlemap')) {
    function rit_shortcode_googlemap($atts)
    {
        $atts = shortcode_atts(array(
            'title' => 'Google Map',
            'latitude' => '21.028667',
            'width' => '585px',
            'height' => '205px',
            'longitude' => '105.852148',
            'zoom' => '15',
            'style' => 'light',
            'el_class' => ''
        ), $atts);

        return rit_get_template_part('shortcode', 'google-map', array('atts' => $atts));
    }
}

add_shortcode('rit_googlemap', 'rit_shortcode_googlemap');

add_action('vc_before_init', 'rit_googlemap_integrate_vc');

if (!function_exists('rit_googlemap_integrate_vc')) {
    function rit_googlemap_integrate_vc()
    {
        vc_map(array(
            'name' => __('RIT Goolge Map', 'ri-ghost'),
            'base' => 'rit_googlemap',
            'category' => __('RIT', 'ri-ghost'),
            'icon' => 'rit-googlemap',
            "params" => array(
                array(
                    "type" => "textfield",
                    "heading" => __("Title", 'ri-ghost'),
                    "param_name" => "title",
                    "value" => "Google Map",
                    "admin_label" => true
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Latitude", 'ri-ghost'),
                    "param_name" => "latitude",
                    "admin_label" => true,
                    "value" => "21.028667",
                    'description' => wp_kses(__('Latitude for map. Go to link <a href="http://www.latlong.net/" target="_blank">http://www.latlong.net/</a> enter address and get value in field "Latitude"', 'ri-ghost'), array('a' => array('href' => array(), 'target' => array())))
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Longitude", 'ri-ghost'),
                    "param_name" => "longitude",
                    "value" => "105.852148",
                    "admin_label" => true,
                    'description' => wp_kses(__('Longitude for map. Go to link <a href="http://www.latlong.net/" target="_blank">http://www.latlong.net/</a> enter address and get value in field "Longitude"', 'ri-ghost'), array('a' => array('href' => array(), 'target' => array())))
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Width", 'ri-ghost'),
                    "param_name" => "width",
                    "admin_label" => true,
                    "value" => "585px",
                    'description' => __('Set a width for our map container, the Google Map will take up 100% of this container. EXP: 585px', 'rit-core')
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Height", 'ri-ghost'),
                    "param_name" => "height",
                    "admin_label" => true,
                    "value" => "205px",
                    'description' => __('Set a Height for our map container, the Google Map will take up 100% of this container. EXP: 205px', 'rit-core')
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Zoom", 'ri-ghost'),
                    "param_name" => "zoom",
                    "admin_label" => true,
                    'value' => array(
                        __( '1', 'ri-ghost' ) => '1',
                        __( '2', 'ri-ghost' ) => '2',
                        __( '3', 'ri-ghost' ) => '3',
                        __( '4', 'ri-ghost' ) => '4',
                        __( '5', 'ri-ghost' ) => '5',
                        __( '6', 'ri-ghost' ) => '6',
                        __( '7', 'ri-ghost' ) => '7',
                        __( '8', 'ri-ghost' ) => '8',
                        __( '9', 'ri-ghost' ) => '9',
                        __( '10', 'ri-ghost' ) => '10',
                        __( '11', 'ri-ghost' ) => '11',
                        __( '12', 'ri-ghost' ) => '12',
                        __( '13', 'ri-ghost' ) => '13',
                        __( '14', 'ri-ghost' ) => '14',
                        __( '15', 'ri-ghost' ) => '15',
                        __( '16', 'ri-ghost' ) => '16',
                        __( '17', 'ri-ghost' ) => '17',
                        __( '18', 'ri-ghost' ) => '18',
                        __( '19', 'ri-ghost' ) => '19',
                        __( '20', 'ri-ghost' ) => '20',
                        __( '21', 'ri-ghost' ) => '21',
                        __( '22', 'ri-ghost' ) => '22',
                        __( '23', 'ri-ghost' ) => '23',
                        __( '24', 'ri-ghost' ) => '24',
                    ),
                    'description' => __('Zoom of map', 'rit-core'),
                    'std' => '15'
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Style", 'ri-ghost'),
                    "param_name" => "style",
                    "admin_label" => true,
                    'value' => array(
                        __( 'Ultra Light with Labels', 'ri-ghost' ) => 'light',
                        __( 'Apple Maps-esque', 'ri-ghost' ) => 'apple',
                        __( 'Pale Dawn', 'ri-ghost' ) => 'pale',
                        __( 'Blue Essence', 'ri-ghost' ) => 'blue',
                        __( 'Light Dream', 'ri-ghost' ) => 'dream'
                    ),
                    'description' => __('Style of map', 'rit-core'),
                    'std' => 'light'
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __('Extra class name', 'ri-ghost'),
                    'param_name' => 'el_class',
                    'description' => __('Style particular content element differently - add a class name and refer to it in custom CSS.', 'ri-ghost')
                )
            )
        ));
    }
}
