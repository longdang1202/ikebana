<?php

if (!class_exists('RIT_Custom_Post_Type_Member')) {
    class RIT_Custom_Post_Type_Member
    {
        public static function &getInstance()
        {
            static $instance;
            if (!isset($instance)) {
                $instance = new RIT_Custom_Post_Type_Member();
            }
            return $instance;
        }

        public function init() {
            add_action('init', array($this, 'register_member'));
            add_action('init', array($this, 'register_member_category'));
        }

        public function register_member()
        {
            $labels = array(
                'name' => __('RIT Member', 'ri-ghost'),
                'singular_name' => __('member', 'ri-ghost'),
                'add_new' => __('Add New', 'ri-ghost'),
                'add_new_item' => __('Add New Member', 'ri-ghost'),
                'edit_item' => __('Edit Member', 'ri-ghost'),
                'new_item' => __('New Member', 'ri-ghost'),
                'view_item' => __('View Member', 'ri-ghost'),
                'search_items' => __('Search Member', 'ri-ghost'),
                'not_found' =>  __('No members have been added yet', 'ri-ghost'),
                'not_found_in_trash' => __('Nothing found in Trash', 'ri-ghost'),
                'parent_item_colon' => ''
            );

            $args = array(
                'labels' => $labels,
                'public' => true,
                'show_ui' => true,
                'show_in_menu' => true,
                'show_in_nav_menus' => false,
                'menu_icon'=> 'dashicons-welcome-view-site',
                'rewrite' => false,
                'supports' => array('title', 'editor'),
                'has_archive' => true,
            );

            register_post_type( 'member' , $args );
        }

        public function register_member_category()
        {
            $args = array(
                "label" 						=> __('Member Categories', 'ri-ghost'),
                "singular_label" 				=> __('Member Category', 'ri-ghost'),
                'public'                        => true,
                'hierarchical'                  => true,
                'show_ui'                       => true,
                'show_in_nav_menus'             => false,
                'args'                          => array( 'orderby' => 'term_order' ),
                'rewrite'                       => false,
                'query_var'                     => true
            );

            register_taxonomy( 'member_category', 'parallax', $args );
        }
    }

    RIT_Custom_Post_Type_Member::getInstance()->init();
}