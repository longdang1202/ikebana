<?php
if (!function_exists('rit_shortcode_vertical')) {
    function rit_shortcode_vertical($atts)
    {
        $atts = shortcode_atts(array(
            'title'	        => 'Title',
            'show_mode'	    => 'hover',
            'location'	    => 'vertical',
            'el_class'      => '',
        ), $atts);

        return rit_get_template_part('shortcode', 'vertical-menu', array('atts' => $atts));
    }
}
add_shortcode('vertical', 'rit_shortcode_vertical');

add_action('vc_before_init', 'rit_vertical_integrate_vc');

if (!function_exists('rit_vertical_integrate_vc')) {
    function rit_vertical_integrate_vc()
    {
        $menus = get_registered_nav_menus();
        $menu = array();
        foreach ( $menus as $location => $name ) {
            $menu[$name] = $location;
        }

        vc_map( array(
            "name"		=> __("RIT Vertical Menu", 'ri-ghost'),
            "base"		=> "vertical",
            "class"		=> "",
            'category' => esc_html__('RIT', 'rit-core'),
            "icon"      => "spb-icon-vertical",
            "wrapper_class" => "clearfix",
            "controls"	=> "full",
            "params"	=> array(
                array(
                    "type" => "textfield",
                    "heading" => __("Title", 'ri-ghost'),
                    "param_name" => "title",
                    "value" => "Title",
                    "description" => __("", 'ri-ghost')
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Show Menu Mode", 'ri-ghost'),
                    "param_name" => "show_mode",
                    "value" => array(
                        __('When Hover', 'ri-ghost') => "hover",
                        __('When Click', 'ri-ghost') => "click",
                        __('Always Show', 'ri-ghost') => "show"
                    ),
                    "std" => 'hover',
                    "description" => __("Show Menu mode.", 'ri-ghost')
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Menu Location", 'ri-ghost'),
                    "param_name" => "location",
                    "value" => $menu,
                    "std" => 'hover',
                    "description" => __("Show Menu mode.", 'ri-ghost')
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Extra class name", 'ri-ghost'),
                    "param_name" => "el_class",
                    "value" => "",
                    "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'ri-ghost')
                )
            )
        ) );
    }
}
