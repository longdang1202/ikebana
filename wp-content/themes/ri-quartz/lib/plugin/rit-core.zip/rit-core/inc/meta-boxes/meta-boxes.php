<?php

$sidebar_options = array();
$sidebars = $GLOBALS['wp_registered_sidebars'];

foreach ( $sidebars as $sidebar ){
    $sidebar_options[] = array(
        'name'  => $sidebar['name'],
        'value' => $sidebar['id']
    );
}

if (!class_exists('RIT_Meta_Boxes')) {
    class RIT_Meta_Boxes
    {
        public $meta_boxes;

        public function __construct()
        {
            $this->add_meta_box_options();
            add_action('admin_init', array($this, 'register'));
        }

        public static function &getInstance()
        {
            static $instance;
            if (!isset($instance)) {
                $instance = new RIT_Meta_Boxes();
            }
            return $instance;
        }

        public function add_meta_box_options()
        {
            $meta_boxes = array();

            /* Post Meta Box */
            $meta_boxes[] = array(
                'id' => 'post_meta_box',
                'title' => __('Post Meta', 'ri-ghost'),
                'pages' => array('post'),
                'context' => 'normal',
                'fields' => array(

                    // CUSTOM EXCERPT SECTION
                    array(
                        'name' => '',
                        'title' => __('Custom Excerpt', 'ri-ghost'),
                        'id' => "rit_heading_custom_excerpt",
                        'type' => 'heading'
                    ),

                    // CUSTOM EXCERPT
                    array(
                        'name' => __('Custom excerpt', 'ri-ghost'),
                        'desc' => __("You can optionally write a custom excerpt here to display instead of the excerpt that is automatically generated. If you use the page builder, then you'll want to add content to this box.", 'ri-ghost'),
                        'id' => "rit_custom_excerpt",
                        'type' => 'textarea',
                        'std' => "",
                        'cols' => '40',
                        'rows' => '8',
                    ),

                    // MAIN DETAIL SECTION
                    array(
                        'name' => '',
                        'title' => __('Main Detail Options', 'ri-ghost'),
                        'id' => "rit_heading_detail",
                        'type' => 'heading'
                    ),

                    // FULL WIDTH MEDIA
                    array(
                        'name' => __('Full Width Media Display', 'ri-ghost'),
                        'id' => "rit_full_width_display",
                        'type' => 'checkbox',
                        'desc' => __('Check this box to show the detail media above the page content / sidebar config, rather than inside the page content.', 'ri-ghost'),
                        'std' => 0,
                    ),

                    // INCLUDE AUTHOR INFO
                    array(
                        'name' => __('Include author info', 'ri-ghost'),
                        'id' => "rit_author_info",
                        'type' => 'checkbox',
                        'desc' => __('Check this box to show the author info box on the detail page.', 'ri-ghost'),
                        'std' => 1,
                    ),

                    // INCLUDE SOCIAL SHARING
                    array(
                        'name' => __('Include social sharing', 'ri-ghost'),
                        'id' => "rit_social_sharing",
                        'type' => 'checkbox',
                        'desc' => __('Check this box to show social sharing icons on the detail page.', 'ri-ghost'),
                        'std' => 1,
                    ),

                    // INCLUDE RELATED ARTICLES
                    array(
                        'name' => __('Include related articles', 'ri-ghost'),
                        'id' => "rit_related_articles",
                        'type' => 'checkbox',
                        'desc' => __('Check this box to show related articles on the detail page.', 'ri-ghost'),
                        'std' => 1,
                    ),

                    // SIDEBAR OPTIONS SECTION
                    array(
                        'name' => '',
                        'title' => __('Sidebar Options', 'ri-ghost'),
                        'id' => "rit_heading_sidebar",
                        'type' => 'heading'
                    ),
                )
            );
            /* Page Background Meta Box */
            $meta_boxes[] = array(
                'id' => 'page_background_meta_box',
                'title' => __('Page Style Options', 'ri-ghost'),
                'pages' => array('post', 'page', 'portfolio'),
                'context' => 'normal',
                'fields' => array(
                    // INNER BACKGROUND IMAGE
                    array(
                        'name' => __('Custom Primary Color', 'ri-ghost'),
                        'desc' => __('Custom primary color for only this page.', 'ri-ghost'),
                        'id' => "rit_custom_primary_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom Primary Color 2', 'ri-ghost'),
                        'desc' => __('Custom primary color 2 for only this page.', 'ri-ghost'),
                        'id' => "rit_custom_primary_color_2",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom Page Background Color', 'ri-ghost'),
                        'desc' => __('Custom Page Background Color.', 'ri-ghost'),
                        'id' => "rit_custom_page_bg_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Poster Image', 'ri-ghost'),
                        'desc' => __('The image that will be used as the poster page image.', 'ri-ghost'),
                        'id' => "rit_poster_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    )
                )
            );

            /* Page Background Meta Box */
            $meta_boxes[] = array(
                'id' => 'title_meta_box',
                'title' => __('Meta Options', 'ri-ghost'),
                'pages' => array('post', 'page'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Choose Page Width', 'ri-ghost'),
                        'id'   => "rit_page_width",
                        'type' => 'select',
                        'options' => array(
                            'use-default'		=> 'Default',
                            'full'		=> 'Full Width',
                            'boxed'		=> 'Boxed'
                        ),
                        'std'  => 'default',
                        'desc' => __('Choose Options Header.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Custom Background Body', 'ri-ghost'),
                        'desc' => __('Custom background body.', 'ri-ghost'),
                        'id' => "rit_custom_bg_body",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom Background Body Image', 'ri-ghost'),
                        'desc' => __('Custom Background Body Image.', 'ri-ghost'),
                        'id' => "rit_bg_body_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                    array(
                        'name' => __('Custom Background Repeat', 'ri-ghost'),
                        'id'   => "rit_bg_body_repeat",
                        'type' => 'select',
                        'options' => array(
                            'default'		=> 'Default',
                            'no-repeat'		=> 'no-repeat',
                            'repeat'		=> 'repeat',
                            'repeat-x'		=> 'repeat-x',
                            'repeat-y'		=> 'repeat-y',
                            'round'		=> 'round',
                            'space'		=> 'space'
                        ),
                        'std'  => 'default',
                        'desc' => __('Choose Custom Background Repeat.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Custom Background Size', 'ri-ghost'),
                        'id'   => "rit_bg_body_size",
                        'type' => 'select',
                        'options' => array(
                            'default'		=> 'Default',
                            'contain'		=> 'contain',
                            'auto'		=> 'auto',
                            'cover'		=> 'cover',
                            '100%'		=> '100%'
                        ),
                        'std'  => 'default',
                        'desc' => __('Choose Custom Background Size.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Custom Background Attachment', 'ri-ghost'),
                        'id'   => "rit_bg_body_attachment",
                        'type' => 'select',
                        'options' => array(
                            'default'		=> 'Default',
                            'fixed'		=> 'fixed',
                            'scroll'		=> 'scroll',
                            'local'		=> 'scroll'
                        ),
                        'std'  => 'default',
                        'desc' => __('Choose Custom Background Attachment.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Disible Title', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_disible_title",
                        'type' => 'checkbox'
                    ),
                    array(
                        'name' => __('Custom Title', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_custom_title",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Sub Title', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_sub_title",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Disible Breadcrumb', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_disible_breadcrumb",
                        'type' => 'checkbox'
                    ),
                    array(
                        'name' => __('Enable One Page', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_enable_one_page",
                        'type' => 'checkbox'
                    ),
                    array(
                        'name' => __('Custom Class Page', 'ri-ghost'),
                        'desc' => __('Custom Css Class', 'ri-ghost'),
                        'id' => "rit_custom_class_page",
                        'type' => 'text'
                    ),
                )
            );

            $menus = get_registered_nav_menus();
            $menu = array();
            foreach ( $menus as $location => $name ) {
                $menu[$name] = $location;
            }
            /* Header Option */
            $meta_boxes[] = array(
                'id' => 'header_option',
                'title' => __('Header Option', 'ri-ghost'),
                'pages' => array('page'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Header Options', 'ri-ghost'),
                        'id'   => "rit_header_options",
                        'type' => 'image_select',
                        'options' => array(
                            'use-default' => RIT_PLUGIN_URL . 'inc/customize/assets/images/header/default.png',
                            '1'		=> RIT_PLUGIN_URL . 'inc/customize/assets/images/header/header-1.png',
                            '2'		=> RIT_PLUGIN_URL . 'inc/customize/assets/images/header/header-2.png',
                            '3'		=> RIT_PLUGIN_URL . 'inc/customize/assets/images/header/header-3.png',
                            '4'		=> RIT_PLUGIN_URL . 'inc/customize/assets/images/header/header-4.png',
                            '5'		=> RIT_PLUGIN_URL . 'inc/customize/assets/images/header/header-5.png',
                            '6'		=> RIT_PLUGIN_URL . 'inc/customize/assets/images/header/header-6.png'
                        ),
                        'std'  => 'use-default',
                        'desc' => __('Choose Options Header.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Header Position', 'ri-ghost'),
                        'id'   => "rit_header_position",
                        'type' => 'select',
                        'options' => array(
                            'use-default' => 'Use Default',
                            'normal'	=> 'Normal',
                            'absolute'	=> 'Absolute'
                        ),
                        'std'  => 'normal',
                        'desc' => __('If you choose Use Default. Header position will get value in customizer. If you choose position absolute. Header will override slider or content.', 'ri-ghost')
                    ),
                    // LOGO IMAGE
                    array(
                        'name' => __('Logo Image', 'ri-ghost'),
                        'desc' => __('The image that will be used as the OUTER logo image.', 'ri-ghost'),
                        'id' => "rit_logo_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                    array(
                        'name' => __('Custom logo top spacing', 'ri-ghost'),
                        'desc' => __('Custom logo top spacing. Not include "px" after value. E.g: 26', 'ri-ghost'),
                        'id' => "rit_logo_top_spacing",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Enable Header Top', 'ri-ghost'),
                        'desc' => __('Enable Header Top.', 'ri-ghost'),
                        'id' => "rit_enable_header_top",
                        'type' => 'checkbox',
                        'std' => '1'
                    ),
                    array(
                        'name' => __('Disible Margin Content', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_disible_mr_header",
                        'type' => 'checkbox'
                    ),
                    array(
                        'name' => __('Vertical Menu Show Mode', 'ri-ghost'),
                        'id'   => "rit_vertical_menu_mode",
                        'type' => 'select',
                        'options' => array(
                            'use-default' => 'Use Default',
                            'hover'	=> 'When Hover',
                            'click'	=> 'When Click',
                            'show'	=> 'Always Show',
                        ),
                        'std'  => 'hover',
                        'desc' => __('Vertical Menu Show Mode.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Vertical Menu Location', 'ri-ghost'),
                        'id'   => "rit_vertical_menu_location",
                        'type' => 'select',
                        'options' => array(
                            'use-default' => 'Use Default',
                            'primary'	=> 'Primary Menu',
                            'vertical'	=> 'Vertical Menu',
                            'vertical-2'	=> 'Vertical Menu 2',
                            'vertical-3'	=> 'Vertical Menu 3',
                            'vertical-4'	=> 'Vertical Menu 4',
                        ),
                        'std'  => 'primary',
                        'desc' => __('Vertical Menu Location.', 'ri-ghost')
                    ),
                )
            );

            /* Custom Menu Color Meta Box */
            $meta_boxes[] = array(
                'id' => 'custom_menu_meta_box',
                'title' => __('Custom Color Options', 'ri-ghost'),
                'pages' => array('page'),
                'context' => 'normal',
                'fields' => array(
                    // Custom Header Top
                    array(
                        'name' => __('Custom Header Top', 'ri-ghost'),
                        'desc' => __('Custom Header Top. Note: Set custom menu color if you want to change color for only this page.', 'ri-ghost'),
                        'id' => "rit_heading_header_top_color",
                        'type' => 'heading'
                    ),
                    array(
                        'name' => __('Custom header top background image', 'ri-ghost'),
                        'desc' => __('Custom header top background image.', 'ri-ghost'),
                        'id' => "rit_custom_htop_bg_img",
                        'type' => 'image_advanced'
                    ),
                    array(
                        'name' => __('Custom header top background color', 'ri-ghost'),
                        'desc' => __('Custom header top background color.', 'ri-ghost'),
                        'id' => "rit_custom_htop_bg_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom header top text color', 'ri-ghost'),
                        'desc' => __('Custom header top text color.', 'ri-ghost'),
                        'id' => "rit_custom_htop_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom header top link color', 'ri-ghost'),
                        'desc' => __('Custom header top link color.', 'ri-ghost'),
                        'id' => "rit_custom_htop_link_color",
                        'type' => 'color'
                    ),
                    // Custom Header Bottom
                    array(
                        'name' => __('Custom Header Bottom', 'ri-ghost'),
                        'desc' => __('Custom Header Bottom. Note: Set custom menu color if you want to change color for only this page.', 'ri-ghost'),
                        'id' => "rit_heading_header_top_color",
                        'type' => 'heading'
                    ),
                    array(
                        'name' => __('Custom header bottom background color', 'ri-ghost'),
                        'desc' => __('Custom header bottom background color.', 'ri-ghost'),
                        'id' => "rit_custom_hbottom_bg_color",
                        'type' => 'color'
                    ),
                    // Custom Menu Color
                    array(
                        'name' => __('Custom Menu Color', 'ri-ghost'),
                        'desc' => __('Custom menu color. Note: Set custom menu color if you want to change color for only this page.', 'ri-ghost'),
                        'id' => "rit_heading_menu_color",
                        'type' => 'heading'
                    ),
                    array(
                        'name' => __('Custom item background color', 'ri-ghost'),
                        'desc' => __('Custom item background color.', 'ri-ghost'),
                        'id' => "rit_custom_item_bg_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom item menu color', 'ri-ghost'),
                        'desc' => __('Custom item menu color.', 'ri-ghost'),
                        'id' => "rit_custom_item_menu_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom item background hover color', 'ri-ghost'),
                        'desc' => __('Custom item background hover color.', 'ri-ghost'),
                        'id' => "rit_custom_item_bg_hover_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom item menu hover color', 'ri-ghost'),
                        'desc' => __('Custom item menu hover color.', 'ri-ghost'),
                        'id' => "rit_custom_item_menu_hover_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom footer color', 'ri-ghost'),
                        'desc' => __('Custom footer color. Note: Set custom footer color if you want to change color for only this page', 'ri-ghost'),
                        'id' => "rit_heading_footer_color",
                        'type' => 'heading'
                    ),
                    array(
                        'name' => __('Custom footer background color', 'ri-ghost'),
                        'desc' => __('Custom footer background color.', 'ri-ghost'),
                        'id' => "rit_custom_footer_bg_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom Footer text color', 'ri-ghost'),
                        'desc' => __('Custom footer text color.', 'ri-ghost'),
                        'id' => "rit_custom_footer_text_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom Footer widget title color', 'ri-ghost'),
                        'desc' => __('Custom Footer widget title color.', 'ri-ghost'),
                        'id' => "rit_custom_footer_widget_title_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom Footer link color', 'ri-ghost'),
                        'desc' => __('Custom footer link color.', 'ri-ghost'),
                        'id' => "rit_custom_footer_link_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom Footer link hover color', 'ri-ghost'),
                        'desc' => __('Custom footer link hover color.', 'ri-ghost'),
                        'id' => "rit_custom_footer_link_hover_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom copyright color', 'ri-ghost'),
                        'desc' => __('Custom footer color. Note: Set custom copyright color if you want to change color for only this page', 'ri-ghost'),
                        'id' => "rit_heading_copyright_color",
                        'type' => 'heading'
                    ),
                    array(
                        'name' => __('Custom copyright background color', 'ri-ghost'),
                        'desc' => __('Custom copyright background color.', 'ri-ghost'),
                        'id' => "rit_custom_copyright_bg_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom copyright text color', 'ri-ghost'),
                        'desc' => __('Custom copyright text color.', 'ri-ghost'),
                        'id' => "rit_custom_copyright_text_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom copyright link color', 'ri-ghost'),
                        'desc' => __('Custom copyright link color.', 'ri-ghost'),
                        'id' => "rit_custom_copyright_link_color",
                        'type' => 'color'
                    ),
                    array(
                        'name' => __('Custom copyright link hover color', 'ri-ghost'),
                        'desc' => __('Custom copyright link hover color.', 'ri-ghost'),
                        'id' => "rit_custom_copyright_link_hover_color",
                        'type' => 'color'
                    ),
                )
            );

            /* Sidebar Option */
            $meta_boxes[] = array(
                'id' => 'sidebar_option',
                'title' => __('Sidebar Option', 'ri-ghost'),
                'pages' => array('page'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Sidebar Options', 'ri-ghost'),
                        'id'   => "rit_sidebar_options",
                        'type' => 'select',
                        'options' => array(
                            'use-default'		=> 'Use Default',
                            'no-sidebar'		=> 'No Sidebar',
                            'left-sidebar'		=> 'Left Sidebar',
                            'right-sidebar'		=> 'Right Sidebar',
                            'both-sidebar'	    => 'Both Sidebar'
                        ),
                        'std'  => 'no-sidebar',
                        'desc' => __('Choose Options Sidebar.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Padding Content', 'ri-ghost'),
                        'id'   => "rit_sidebar_padding",
                        'type' => 'checkbox',
                        'desc' => __('Padding sidebar with content.', 'ri-ghost')
                    )
                )
            );

            /* Footer Option */
            $meta_boxes[] = array(
                'id' => 'footer_option',
                'title' => __('Footer Option', 'ri-ghost'),
                'pages' => array('page'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Footer Layouts', 'ri-ghost'),
                        'id'   => "rit_footer_options",
                        'type' => 'image_select',
                        'options' => array(
                            'use-default' => RIT_PLUGIN_URL . 'inc/customize/assets/images/footer/default.png',
                            '1' => RIT_PLUGIN_URL . 'inc/customize/assets/images/footer/footer-1.png',
                            '2' => RIT_PLUGIN_URL . 'inc/customize/assets/images/footer/footer-2.png',
                        ),
                        'std'  => 'use-default',
                        'desc' => __('Choose Options Footer Layouts.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Logo Image', 'ri-ghost'),
                        'desc' => __('The image that will be used as the OUTER logo image.', 'ri-ghost'),
                        'id' => "rit_logofooter_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                    array(
                        'name' => __('Disible Margin Content', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_disible_mr_footer",
                        'type' => 'checkbox'
                    )
                )
            );

            /* Banner Meta Box */
            $meta_boxes[] = array(
                'id' => 'banner_meta_box',
                'title' => __('Banner Options', 'ri-ghost'),
                'pages' => array('banner'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Banner Url', 'ri-ghost'),
                        'desc' => __('When click into banner, it will be redirect to this url', 'ri-ghost'),
                        'id' => "rit_banner_url",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Banner class', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_banner_class",
                        'type' => 'text'
                    ),
                )
            );

            /* Pallarax Meta Box */
            $meta_boxes[] = array(
                'id' => 'parallax_meta_box',
                'title' => __('Pallarax Options', 'ri-ghost'),
                'pages' => array('parallax'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Link', 'ri-ghost'),
                        'desc' => __('When click into parallax, it will be redirect to this url', 'ri-ghost'),
                        'id' => "rit_parallax_link",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Text Link', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_parallax_text",
                        'type' => 'text'
                    ),
                )
            );

            /* Slider Meta Box */
            $meta_boxes[] = array(
                'id' => 'slider_meta_box',
                'title' => __('Slider Post Options', 'ri-ghost'),
                'pages' => array('slider'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Sub Title', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_slider_subtitle",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Feature Image', 'ri-ghost'),
                        'desc' => __('The image that will be used as the feature post image', 'ri-ghost'),
                        'id' => "rit_slider_feature_img",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    )
                )
            );

            /* Slider Meta Box */
            $meta_boxes[] = array(
                'id' => 'testimonials_meta_box',
                'title' => __('Testimonials Options', 'ri-ghost'),
                'pages' => array('testimonial'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Avatar', 'ri-ghost'),
                        'desc' => __('Avatar for author', 'ri-ghost'),
                        'id' => "rit_testimonial_avatar",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1,
                    ),
                    array(
                        'name' => __('Testimonials', 'ri-ghost'),
                        'desc' => __('The Testimonials', 'ri-ghost'),
                        'id' => "rit_testimonial",
                        'type' => 'textarea'
                    ),
                    array(
                        'name' => __('Author Name', 'ri-ghost'),
                        'desc' => __('The Author Name', 'ri-ghost'),
                        'id' => "rit_testimonial_name",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Author Position', 'ri-ghost'),
                        'desc' => __('The Author Position', 'ri-ghost'),
                        'id' => "rit_testimonial_position",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Link Facebook', 'ri-ghost'),
                        'desc' => __('Link Facebook of author', 'ri-ghost'),
                        'id' => "rit_testimonial_fb",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Link Twitter', 'ri-ghost'),
                        'desc' => __('Link Twitter of author', 'ri-ghost'),
                        'id' => "rit_testimonial_tt",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Link Goolge', 'ri-ghost'),
                        'desc' => __('Link Goolge of author', 'ri-ghost'),
                        'id' => "rit_testimonial_gg",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Link Linkedin', 'ri-ghost'),
                        'desc' => __('Link Linkedin of author', 'ri-ghost'),
                        'id' => "rit_testimonial_li",
                        'type' => 'text'
                    )
                )
            );

            /* Portfolio Meta Box */
            $meta_boxes[] = array(
                'id' => 'portfolio_meta_box',
                'title' => __('Portfolio Options', 'rit-core'),
                'pages' => array('portfolio'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Disible Title', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_disible_title",
                        'type' => 'checkbox'
                    ),
                    array(
                        'name' => __('Tile Position', 'ri-ghost'),
                        'id'   => "rit_title_position",
                        'type' => 'select',
                        'options' => array(
                            'center'		=> __('Center', 'ri-ghost'),
                            'left'		=> __('Left', 'ri-ghost'),
                        ),
                        'std'  => 'center',
                        'desc' => __('Choose Title Position.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Custom Title', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_custom_title",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Sub Title', 'ri-ghost'),
                        'desc' => __('', 'ri-ghost'),
                        'id' => "rit_sub_title",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Breadcrumbs Layout', 'ri-ghost'),
                        'id'   => "rit_breadcrumbs_layout",
                        'type' => 'select',
                        'options' => array(
                            'large'		=> __('Large', 'ri-ghost'),
                            'small'		=> __('Small', 'ri-ghost'),
                        ),
                        'std'  => 'large',
                        'desc' => __('Choose Breadcrumbs Layout.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Details Layout', 'ri-ghost'),
                        'id'   => "rit_details_layout",
                        'type' => 'select',
                        'options' => array(
                            'layout-1'		=> __('Layout 1', 'ri-ghost'),
                            'layout-2'		=> __('Layout 2', 'ri-ghost'),
                        ),
                        'std'  => 'layout-1',
                        'desc' => __('Choose Details Layout.', 'ri-ghost')
                    ),
                    array(
                        'name' => __('Details Image', 'rit-core'),
                        'desc' => __('Image Cover for portfolio details. If empty, feature image will is image cover details.', 'rit-core'),
                        'id' => "rit_portfolio_details_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 20
                    ),
                    array(
                        'name' => __('Portfolio Information', 'rit-core'),
                        'id' => "rit_portfolio_information",
                        'type' => 'checkbox',
                        'desc' => __('Check box to show Information Portfolio.', 'rit-core')
                    ),
                    array(
                        'name' => __('Client', 'rit-core'),
                        'id' => "rit_portfolio_client",
                        'type' => 'text',
                        'desc' => __('The Name of client.', 'rit-core')
                    ),
                    array(
                        'name' => __('Date Complete', 'rit-core'),
                        'id' => "rit_portfolio_date",
                        'type' => 'date',
                        'desc' => __('The Date Complete Project.', 'rit-core')
                    ),
                    array(
                        'name' => __('Link Demo', 'rit-core'),
                        'id' => "rit_portfolio_link",
                        'type' => 'text',
                        'desc' => __('Link of project.', 'rit-core')
                    ),
                    array(
                        'name' => __('Short Description', 'rit-core'),
                        'id' => "rit_portfolio_short_des",
                        'type' => 'wysiwyg',
                        'desc' => __('Some description of project.', 'rit-core')
                    ),
                )
            );

            /* Member Meta Box */
            $meta_boxes[] = array(
                'id' => 'member_meta_box',
                'title' => __('Member Options', 'rit-core'),
                'pages' => array('member'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Member Image', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_member_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                    array(
                        'name' => __('Member Position', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_member_position",
                        'type' => 'text',
                        'std' => '#'
                    ),
                    array(
                        'name' => __('Link Facebook', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_member_fb",
                        'type' => 'text',
                        'std' => '#'
                    ),
                    array(
                        'name' => __('Link Twitter', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_member_tw",
                        'type' => 'text',
                        'std' => '#'
                    ),
                    array(
                        'name' => __('Link Instagram', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_member_isg",
                        'type' => 'text',
                        'std' => '#'
                    ),
                    array(
                        'name' => __('Link Goolge +', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_member_gl",
                        'type' => 'text',
                        'std' => '#'
                    ),
                )
            );

            /* Menu Meta Box */
            $meta_boxes[] = array(
                'id' => 'menu_meta_box',
                'title' => __('Menu Options', 'rit-core'),
                'pages' => array('menu'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Menu Image', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_menu_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                    array(
                        'name' => __('Menu Details Image', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_menu_details_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                    array(
                        'name' => __('Menu Short Description', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_menu_short",
                        'type' => 'textarea',
                        'std' => ''
                    ),
                    array(
                        'name' => __('Menu Link Details Text', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_menu_link_text",
                        'type' => 'text',
                        'std' => ''
                    ),
                    array(
                        'name' => __('Menu Custom Link Details', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_menu_link",
                        'type' => 'text',
                        'std' => ''
                    ),
                )
            );

            /* Menu Meta Box */
            $meta_boxes[] = array(
                'id' => 'partner_meta_box',
                'title' => __('Partner Options', 'rit-core'),
                'pages' => array('partner'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Link To Parner', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_link_partner",
                        'type' => 'text',
                    ),
                )
            );

            /* Events Meta Box */
            $meta_boxes[] = array(
                'id' => 'events_meta_box',
                'title' => __('Events Options', 'rit-core'),
                'pages' => array('events'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Events Image', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_events_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                    array(
                        'name' => __('Events Details Image', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_events_details_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                    array(
                        'name' => __('Events Date', 'rit-core'),
                        'desc' => __('Date of event.', 'rit-core'),
                        'id' => "rit_events_date",
                        'type' => 'date',
                        'js_options' => array(
                            'dateFormat' => 'mm-dd-yy'
                        ),
                        'std' => ''
                    ),
                    array(
                        'name' => __('Events Time Start / End', 'rit-core'),
                        'desc' => __('Time of event. Exp: 8am - 5pm', 'rit-core'),
                        'id' => "rit_events_time",
                        'type' => 'text',
                        'std' => '8am - 5pm'
                    ),
                    array(
                        'name' => __('Events Short Description', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_events_short",
                        'type' => 'textarea',
                        'std' => ''
                    ),
                    array(
                        'name' => __('Events Link Details Text', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_events_link_text",
                        'type' => 'text',
                        'std' => ''
                    ),
                    array(
                        'name' => __('Events Custom Link Details', 'rit-core'),
                        'desc' => __('', 'rit-core'),
                        'id' => "rit_events_link",
                        'type' => 'url',
                        'std' => ''
                    ),
                )
            );

            $this->meta_boxes = $meta_boxes;
        }

        public function register()
        {
            if (class_exists('RW_Meta_Box')) {
                foreach ($this->meta_boxes as $meta_box) {
                    new RW_Meta_Box($meta_box);
                }
            }
        }
    }
}

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if(is_plugin_active('meta-box/meta-box.php')){
    RIT_Meta_Boxes::getInstance();
}