<?php

if (!class_exists('RIT_Custom_Post_Type_Menu')) {
    class RIT_Custom_Post_Type_Menu
    {
        public static function &getInstance()
        {
            static $instance;
            if (!isset($instance)) {
                $instance = new RIT_Custom_Post_Type_Menu();
            }
            return $instance;
        }

        public function init() {
            add_action('init', array($this, 'register_menu'));
            add_action('init', array($this, 'register_menu_category'));
        }

        public function register_menu()
        {
            $labels = array(
                'name' => __('RIT Menu', 'ri-ghost'),
                'singular_name' => __('menu', 'ri-ghost'),
                'add_new' => __('Add New', 'ri-ghost'),
                'add_new_item' => __('Add New Menu', 'ri-ghost'),
                'edit_item' => __('Edit Menu', 'ri-ghost'),
                'new_item' => __('New Menu', 'ri-ghost'),
                'view_item' => __('View Menu', 'ri-ghost'),
                'search_items' => __('Search Menu', 'ri-ghost'),
                'not_found' =>  __('No menus have been added yet', 'ri-ghost'),
                'not_found_in_trash' => __('Nothing found in Trash', 'ri-ghost'),
                'parent_item_colon' => ''
            );

            $args = array(
                'labels' => $labels,
                'public' => true,
                'show_ui' => true,
                'show_in_menu' => true,
                'show_in_nav_menus' => false,
                'menu_icon'=> 'dashicons-welcome-view-site',
                'rewrite' => false,
                'supports' => array('title', 'editor'),
                'has_archive' => true,
            );

            register_post_type( 'menu' , $args );
        }

        public function register_menu_category()
        {
            $args = array(
                "label" 						=> __('Menu Categories', 'ri-ghost'),
                "singular_label" 				=> __('Menu Category', 'ri-ghost'),
                'public'                        => true,
                'hierarchical'                  => true,
                'show_ui'                       => true,
                'show_in_nav_menus'             => false,
                'args'                          => array( 'orderby' => 'term_order' ),
                'rewrite'                       => false,
                'query_var'                     => true
            );

            register_taxonomy( 'menu_category', 'menu', $args );
        }
    }

    RIT_Custom_Post_Type_Menu::getInstance()->init();
}