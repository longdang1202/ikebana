<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */

if (!class_exists('RIT_Custom_Post_Type_Testimonial')) {
    class RIT_Custom_Post_Type_Testimonial
    {
        public static function &getInstance()
        {
            static $instance;
            if (!isset($instance)) {
                $instance = new RIT_Custom_Post_Type_Testimonial();
            }
            return $instance;
        }

        public function init() {
            add_action('init', array($this, 'register_testimonial'));
            add_action('init', array($this, 'register_testimonial_category'));
        }

        public function register_testimonial()
        {
            $labels = array(
                'name' => esc_html__('Testimonials', 'rit-core'),
                'singular_name' => esc_html__('Testimonial', 'rit-core'),
                'add_new' => esc_html__('Add New', 'rit-core'),
                'add_new_item' => esc_html__('Add New Testimonial', 'rit-core'),
                'edit_item' => esc_html__('Edit Testimonial', 'rit-core'),
                'new_item' => esc_html__('New Testimonial', 'rit-core'),
                'view_item' => esc_html__('View Testimonial', 'rit-core'),
                'search_items' => esc_html__('Search Testimonials', 'rit-core'),
                'not_found' =>  esc_html__('No testimonials have been added yet', 'rit-core'),
                'not_found_in_trash' => esc_html__('Nothing found in Trash', 'rit-core'),
                'parent_item_colon' => ''
            );

            $args = array(
                'labels' => $labels,
                'public' => true,
                'show_ui' => true,
                'show_in_menu' => true,
                'show_in_nav_menus' => false,
                'menu_icon'=> 'dashicons-format-quote',
                'rewrite' => false,
                'supports' => array('title', 'editor'),
                'has_archive' => true,
            );

            register_post_type( 'testimonial' , $args );
        }

        public function register_testimonial_category()
        {
            $args = array(
                "label" 						=> esc_html__('Testimonial Categories', 'rit-core'),
                "singular_label" 				=> esc_html__('Testimonial Category', 'rit-core'),
                'public'                        => true,
                'hierarchical'                  => true,
                'show_ui'                       => true,
                'show_in_nav_menus'             => false,
                'args'                          => array( 'orderby' => 'term_order' ),
                'rewrite'                       => false,
                'query_var'                     => true
            );

            register_taxonomy( 'testimonial_category', 'testimonial', $args );
        }
    }

    RIT_Custom_Post_Type_Testimonial::getInstance()->init();
}