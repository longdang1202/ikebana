<?php
if (!function_exists('rit_shortcode_partner')) {
    function rit_shortcode_partner($atts)
    {
        $atts = shortcode_atts(array(
            'enable_carousel'   => '1',
            'column'	        => '6',
            'title'	            => 'Title',
            'control'	            => '0',
            'scale'	            => true,
            'border'	            => true,
            'partner_cat'	    => '',
            'el_class' => '',
        ), $atts);

        return rit_get_template_part('shortcode', 'partner', array('atts' => $atts));
    }
}
add_shortcode('partner', 'rit_shortcode_partner');

add_action('vc_before_init', 'rit_partner_integrate_vc');

if (!function_exists('rit_partner_integrate_vc')) {
    function rit_partner_integrate_vc()
    {
        vc_map( array(
            "name"		=> __("RIT Partner Logo", 'ri-ghost'),
            "base"		=> "partner",
            "class"		=> "",
            'category' => esc_html__('RIT', 'rit-core'),
            "icon"      => "spb-icon-partner",
            "wrapper_class" => "clearfix",
            "controls"	=> "full",
            "params"	=> array(
                array(
                    "type" => "textfield",
                    "heading" => __("Title", 'ri-ghost'),
                    "param_name" => "title",
                    "value" => "Title",
                    "description" => __("", 'ri-ghost')
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Enable Carousel", 'ri-ghost'),
                    "param_name" => "enable_carousel",
                    "value" => array(
                        __('Yes', 'ri-ghost') => "1",
                        __('No', 'ri-ghost') => "0"
                    ),
                    "std" => '1',
                    "description" => __("Enable Carousel.", 'ri-ghost')
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Control Diplay", 'ri-ghost'),
                    "param_name" => "control",
                    "value" => array(
                        __('Always Show', 'ri-ghost') => "1",
                        __('When hover', 'ri-ghost') => "0"
                    ),
                    "std" => '0',
                    "description" => __("Control Diplay.", 'ri-ghost'),
                    'dependency' => array(
                        'element' => 'enable_carousel',
                        'value' => '1',
                    ),
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Column", 'ri-ghost'),
                    "param_name" => "column",
                    "value" => array(
                        __('1', 'ri-ghost') => "1",
                        __('2', 'ri-ghost') => "2",
                        __('3', 'ri-ghost') => "3",
                        __('4', 'ri-ghost') => "4",
                        __('5', 'ri-ghost') => "5",
                        __('6', 'ri-ghost') => "6",
                    ),
                    "std" => '6',
                    "description" => __("Column Show Partner", 'ri-ghost')
                ),
                array(
                    "type" => "rit_partner_categories",
                    "class" => "",
                    "heading" => __("Partner Category", 'ri-ghost'),
                    "param_name" => "partner_cat",
                    "value" => "6",
                    "description" => __("Choose the Partner Content Type Category.", 'ri-ghost')
                ),
                array(
                    "type" => "checkbox",
                    "heading" => __("Border logo", 'ri-ghost'),
                    "param_name" => "border",
                    "std" => true,
                    "description" => __("Enable border around logo.", 'ri-ghost')
                ),
                array(
                    "type" => "checkbox",
                    "heading" => __("Gray Scale", 'ri-ghost'),
                    "param_name" => "scale",
                    "std" => true,
                    "description" => __("If enable, image logo will gray scale, when hover, image will back normal color.", 'ri-ghost')
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Extra class name", 'ri-ghost'),
                    "param_name" => "el_class",
                    "value" => "",
                    "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'ri-ghost')
                )
            )
        ) );
    }
}
