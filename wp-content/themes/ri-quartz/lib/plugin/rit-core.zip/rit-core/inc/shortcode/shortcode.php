<?php
    /* SPACE SHORTCODE
    ================================================== */
    if(!function_exists('rit_space')) {
        function rit_space($atts, $content = null)
        {
            $class = $id = $height = '';
            extract(shortcode_atts(array(
                "id" => "",
                "height" => "30",
                "class" => "rit-space"
            ), $atts));

            $html = '';

            $html .= '<div class="' . $class . '" '. ($id ? 'id="' . $id . '"' : '') .' style="height: ' . $height . 'px"></div>';

            return $html;
        }
        add_shortcode('rit_space', 'rit_space');
    }

    /* DIVIDER SHORTCODE
        ================================================== */
    if(!function_exists('rit_divider')) {
        function rit_divider($atts, $content = null)
        {
            $id = $height = $width = $bgcolor = $margin = $class = '';
            extract(shortcode_atts(array(
                "id" => "",
                "height" => "1",
                "width" => "50",
                "bgcolor" => "#000000",
                "margin" => "0 0 0 0",
                "class" => ""
            ), $atts));

            $html = $_id = '';
            if($id != ''){
                $_id .= 'id="'. $id .'"';
            }

            $html .= '<div class="rit-divider ' . $class . '" '.$_id.' style="height: ' . $height . 'px; width: '. ($width == 'auto' ? 'auto' : $width . 'px') .'; background-color: '. $bgcolor .'; margin: '. $margin .'"></div>';

            return $html;
        }
        add_shortcode('rit_divider', 'rit_divider');
    }

    /* DIVIDER DROPCAP
            ================================================== */
    if(!function_exists('rit_dropcap')) {
        function rit_dropcap($atts, $content = null)
        {
            $class = $id = $bgcolor = $color = '';
            extract(shortcode_atts(array(
                "bgcolor" => "#000000",
                "color" => "#fff",
                "class" => "rit-dropcap"
            ), $atts));

            $html = '';

            $html .= '<span class="' . $class . '" id="' . $id . '" style="background-color: '. $bgcolor .'; color: '. $color .'">'. $content .'</span>';

            return $html;
        }
        add_shortcode('rit_dropcap', 'rit_dropcap');
    }

    /* SOCIAL SHORTCODE
            ================================================== */
    if(!function_exists('rit_social')) {
        function rit_social($atts, $content = null)
        {
            $id = $_id = $name = $icon = $class = '';
            extract(shortcode_atts(array(
                "id" => "",
                "name" => "yes",
                "icon" => "yes",
                "class" => ""
            ), $atts));

            $class_new = '';
            if($name != 'yes'){
                $class_new .= 'no-name ';
            }
            if($icon != 'yes'){
                $class_new .= 'no-icon ';
            }
            $class_new .= $class;

            $twitter = get_theme_mod('rit_social_twitter', 'username');
            $facebook = get_theme_mod('rit_social_facebook', 'page');
            $dribbble = get_theme_mod('rit_social_dribbble', 'username');
            $vimeo = get_theme_mod('rit_social_vimeo', '');
            $tumblr = get_theme_mod('rit_social_tumblr', '');
            $skype = get_theme_mod('rit_social_skype', '');
            $linkedin = get_theme_mod('rit_social_linkedin', '');
            $googleplus = get_theme_mod('rit_social_googleplus', 'page');
            $flickr = get_theme_mod('rit_social_flickr', 'link');
            $youtube = get_theme_mod('rit_social_youTube', 'link');
            $pinterest = get_theme_mod('rit_social_pinterest', 'username');
            $foursquare = get_theme_mod('rit_social_foursquare', '');
            $instagram = get_theme_mod('rit_social_instagram', '');
            $github = get_theme_mod('rit_social_github', '');
            $xing = get_theme_mod('rit_social_xing', '');

            $html = '';
            if($id != ''){
                $_id .= 'id="'. $id .'"';
            }

            $html .= '<div class="rit-social ' . $class_new . '" '.$_id.'>';
            $html .= '<ul>';
            if ($twitter != '') {
                $html .= '<li class="twitter"><a href="http://www.twitter.com/'.$twitter.'" target="_blank"><span>'. __('twitter', 'ri-ghost') .'</span><i class="fa fa-twitter"></i></a></li>'."\n";
            }
            if ($facebook != '') {
                $html .= '<li class="facebook"><a href="'.$facebook.'" target="_blank"><span>'. __('facebook', 'ri-ghost') .'</span><i class="fa fa-facebook"></i></a></li>'."\n";
            }
            if ($dribbble != '') {
                $html .= '<li class="dribbble"><a href="http://www.dribbble.com/'.$dribbble.'" target="_blank"><span>'. __('dribbble', 'ri-ghost') .'</span><i class="fa fa-dribbble"></i></a></li>'."\n";
            }
            if ($youtube != '') {
                $html .= '<li class="youtube"><a href="'.$youtube.'" target="_blank"><span>'. __('youtube', 'ri-ghost') .'</span><i class="fa fa-youtube-play"></i></a></li>'."\n";
            }
            if ($vimeo != '') {
                $html .= '<li class="vimeo"><a href="http://www.vimeo.com/'.$vimeo.'" target="_blank"><span>'. __('vimeo', 'ri-ghost') .'</span><i class="fa fa-vimeo"></i></a></li>'."\n";
            }
            if ($tumblr != '') {
                $html .= '<li class="tumblr"><a href="http://'.$tumblr.'.tumblr.com/" target="_blank"><span>'. __('tumblr', 'ri-ghost') .'</span><i class="fa fa-tumblr-square"></i></a></li>'."\n";
            }
            if ($skype != '') {
                $html .= '<li class="skype"><a href="skype:'.$skype.'" target="_blank"><span>'. __('skype', 'ri-ghost') .'</span><i class="fa fa-skype"></i></a></li>'."\n";
            }
            if ($linkedin != '') {
                $html .= '<li class="linkedin"><a href="'.$linkedin.'" target="_blank"><span>'. __('linkedin', 'ri-ghost') .'</span><i class="fa fa-linkedin"></i></a></li>'."\n";
            }
            if ($googleplus != '') {
                $html .= '<li class="googleplus"><a href="'.$googleplus.'" target="_blank"><span>'. __('google +', 'ri-ghost') .'</span><i class="fa fa-google-plus"></i></a></li>'."\n";
            }
            if ($flickr != '') {
                $html .= '<li class="flickr"><a href="'.$flickr.'" target="_blank"><span>'. __('flickr', 'ri-ghost') .'</span><i class="fa fa-flickr"></i></a></li>'."\n";
            }
            if ($pinterest != '') {
                $html .= '<li class="pinterest"><a href="http://www.pinterest.com/'.$pinterest.'/" target="_blank"><span>'. __('pinterest', 'ri-ghost') .'</span><i class="fa fa-pinterest"></i></a></li>'."\n";
            }
            if ($foursquare != '') {
                $html .= '<li class="foursquare"><a href="'.$foursquare.'" target="_blank"><span>'. __('foursquare', 'ri-ghost') .'</span><i class="fa fa-foursquare"></i></a></li>'."\n";
            }
            if ($instagram != '') {
                $html .= '<li class="instagram"><a href="http://instagram.com/'.$instagram.'" target="_blank"><span>'. __('instagram', 'ri-ghost') .'</span><i class="fa fa-instagram"></i></a></li>'."\n";
            }
            if ($github != '') {
                $html .= '<li class="github"><a href="'.$github.'" target="_blank"><span>'. __('github', 'ri-ghost') .'</span><i class="fa fa-github"></i></a></li>'."\n";
            }
            if ($xing != '') {
                $html .= '<li class="xing"><a href="'.$xing.'" target="_blank"><span>'. __('xing', 'ri-ghost') .'</span><i class="fa fa-xing"></i></a></li>'."\n";
            }
            $html .= '</ul>';
            $html .= '</div>';

            return $html;
        }
        add_shortcode('rit_social', 'rit_social');
    }
?>