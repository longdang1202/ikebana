<?php

add_action('vc_before_init', 'rit_divider_integrate_vc');
if (!function_exists('rit_divider_integrate_vc')) {
    function rit_divider_integrate_vc()
    {
        vc_map(
            array(
                'name' => esc_html__('RIT Divider', 'rit-core'),
                'base' => 'rit_divider',
                'icon' => 'icon-rit',
                'category' => esc_html__('RIT', 'rit-core'),
                'description' => esc_html__('Divider', 'rit-core'),
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('ID', 'rit-core'),
                        'param_name' => 'id',
                        'value' => "",
                        'description' => esc_html__('', 'rit-core')
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Height', 'rit-core'),
                        'param_name' => 'height',
                        'value' => "1",
                        'description' => esc_html__('', 'rit-core')
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Width', 'rit-core'),
                        'param_name' => 'width',
                        'value' => "50",
                        'description' => esc_html__('', 'rit-core')
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Margin', 'rit-core'),
                        'param_name' => 'margin',
                        'value' => "0 0 0 0",
                        'description' => esc_html__('', 'rit-core')
                    ),
                    array(
                        'type' => 'colorpicker',
                        'heading' => esc_html__('Background Color', 'rit-core'),
                        'param_name' => 'bgcolor',
                        'description' => esc_html__('', 'rit-core')
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Extra class name', 'rit-core'),
                        'param_name' => 'el_class',
                        'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'rit-core')
                    )
                )
            )
        );
    }
}
?>