<?php
if (!function_exists('rit_shortcode_posttype')) {
    function rit_shortcode_posttype($atts)
    {
        $atts = shortcode_atts(array(
            'element_title'       => '',
            'enable_carousel'   => '1',
            'column'	        => '',
            'title'	            => '',
            'testimonials_layout' => '',
            'description'	    => '',
            'testimonials_cat'	    => '',
            'enable_social'	    => '0',
            'el_class' => '',
        ), $atts);

        return rit_get_template_part('shortcode', 'posttype', array('atts' => $atts));
    }
}
add_shortcode('posttype', 'rit_shortcode_posttype');

add_action('vc_before_init', 'rit_posttype_integrate_vc');

if (!function_exists('rit_posttype_integrate_vc')) {
    function rit_posttype_integrate_vc()
    {
        vc_map( array(
            "name"		=> __("RIT Custom Post Type", 'ri-ghost'),
            "base"		=> "posttype",
            "class"		=> "",
            'category' => esc_html__('RIT', 'rit-core'),
            "icon"      => "spb-icon-posttype",
            "wrapper_class" => "clearfix",
            "controls"	=> "full",
            "params"	=> array(
                array(
                    "type" => "textfield",
                    "heading" => __("Title", 'ri-ghost'),
                    "param_name" => "element_title",
                    "admin_label" => true
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Parallax Content Type", 'ri-ghost'),
                    "param_name" => "posttype_type",
                    "value" => array(
                        __('RIT Testimonials Post Type', 'ri-ghost') => "testimonials_type",
                    ),
                    "std" => 'post_type',
                    "description" => __("Choose the Parallax Content Type.", 'ri-ghost')
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Testimonials Layout", 'ri-ghost'),
                    "param_name" => "testimonials_layout",
                    "value" => array(
                        __('Layout 1', 'ri-ghost') => "1",
                        __('Layout 2', 'ri-ghost') => "2"
                    ),
                    "std" => '',
                    'dependency' => Array(
                        'element' => 'posttype_type',
                        'value' => array('testimonials_type')
                    ),
                    "description" => __("Testimonials Item Layout.", 'ri-ghost')
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Enable Carousel", 'ri-ghost'),
                    "param_name" => "enable_carousel",
                    "value" => array(
                        __('Yes', 'ri-ghost') => "1",
                        __('No', 'ri-ghost') => "0"
                    ),
                    "std" => '1',
                    'dependency' => Array(
                        'element' => 'posttype_type',
                        'value' => array('post_type')
                    ),
                    "description" => __("Enable Carousel.", 'ri-ghost')
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Column", 'ri-ghost'),
                    "param_name" => "column",
                    "value" => array(
                        __('1', 'ri-ghost') => "1",
                        __('2', 'ri-ghost') => "2",
                        __('3', 'ri-ghost') => "3",
                        __('4', 'ri-ghost') => "4",
                    ),
                    "description" => __("Column Show Testimonials", 'ri-ghost'),
                    'dependency' => Array(
                        'element' => 'posttype_type',
                        'value' => array('testimonials_type', 'menu_type')
                    ),
                ),
                array(
                    "type" => "rit_testimonial_categories",
                    "class" => "",
                    "heading" => __("Testimonials Category", 'ri-ghost'),
                    "param_name" => "testimonials_cat",
                    "value" => "6",
                    'dependency' => Array('element' => 'posttype_type', 'value' => 'testimonials_type'),
                    "description" => __("Choose the Testimonials Content Type Category.", 'ri-ghost')
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Enable Social", 'ri-ghost'),
                    "param_name" => "enable_social",
                    "value" => array(
                        __('Yes', 'ri-ghost') => "1",
                        __('No', 'ri-ghost') => "0"
                    ),
                    "std" => '0',
                    'dependency' => Array(
                        'element' => 'posttype_type',
                        'value' => array('testimonials_type')
                    ),
                    "description" => __("Enable Social below position.", 'ri-ghost')
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Extra class name", 'ri-ghost'),
                    "param_name" => "el_class",
                    "value" => "",
                    "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'ri-ghost')
                )
            )
        ) );
    }
}
