<?php

function rit_shortcode_image_hover($atts)
{

    $atts = shortcode_atts(
        array(
            'thumbnail_library' => '',
            'image' => '',
            'video_url' => '',
            'title' => 'Title',
            'title_color' => '',
            'title_tag' => '6',
            'sub_title' => 'Sub Title',
            'sub_title_color' => '',
            'link' => '#',
            'link_style' => 'accent',
            'text_link' => 'Link',
            'new_tab' => "0",
            'description' => 'Description',
            'style' => 1,
            'border' => 0,
            'position' => 'middle-center',
            'el_class' => ''

        ), $atts);

    return rit_get_template_part('shortcode', 'image-hover', array('atts' => $atts));
}

add_shortcode('rit_image_hover', 'rit_shortcode_image_hover');

add_action('vc_before_init', 'rit_image_hover_integrate_vc');

if (!function_exists('rit_image_hover_integrate_vc')) {
    function rit_image_hover_integrate_vc()
    {
        vc_map(
            array(
                'name' => __('RIT Image Box', 'ri-ghost'),
                'base' => 'rit_image_hover',
                'icon' => 'icon-rit',
                'category' => __('RIT', 'ri-ghost'),
                'description' => __('Show Image Hover', 'ri-ghost'),
                'params' => array(
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Thumbnail Library', 'ri-ghost' ),
                        'param_name' => 'thumbnail_library',
                        'value' => array(
                            __( 'Image', 'ri-ghost' ) => 'image',
                            __( 'Video', 'ri-ghost' ) => 'video'
                        ),
                        'std' => 'image',
                        'description' => 'Select Style'
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Style', 'ri-ghost' ),
                        'param_name' => 'style',
                        'value' => array(
                            __( 'Style 1', 'ri-ghost' ) => '1',
                            __( 'Style 2', 'ri-ghost' ) => '2',
                            __( 'Style 3', 'ri-ghost' ) => '3',
                            __( 'Style 4', 'ri-ghost' ) => '4',
                        ),
                        'description' => 'Select Style'
                    ),
                    array(
                        'type' => 'checkbox',
                        'heading' => __('Enable border', 'ri-ghost'),
                        'value' => 'Enable border',
                        'param_name' => 'border',
                    ),
                    array(
                        'type' => 'attach_images',
                        'heading' => __('Thumbnail Image', 'ri-ghost'),
                        'value' => '',
                        'description' => 'If you choose type "Full Width Image | Content | Image". Please select 2 image',
                        'param_name' => 'image',
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Video Urls', 'ri-ghost'),
                        'value' => '',
                        'param_name' => 'video_url',
                        'description' => 'Link video. We are support video youtube and vimeo: Example: https://youtu.be/nrJtHemSPW4',
                        'dependency' => Array('element' => 'thumbnail_library', 'value' => array('video')),
                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => __('Title', 'ri-ghost'),
                        'value' => 'Title',
                        'param_name' => 'title',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Title Tag', 'ri-ghost' ),
                        'param_name' => 'title_tag',
                        'value' => array(
                            __( 'H1', 'ri-ghost' ) => '1',
                            __( 'H2', 'ri-ghost' ) => '2',
                            __( 'H3', 'ri-ghost' ) => '3',
                            __( 'H4', 'ri-ghost' ) => '4',
                            __( 'H5', 'ri-ghost' ) => '5',
                            __( 'H6', 'ri-ghost' ) => '6',
                        ),
                        'description' => 'Select Tag for title.'
                    ),
                    array(
                        'type' => 'colorpicker',
                        'heading' => __('Title Color', 'ri-ghost'),
                        'param_name' => 'title_color',
                        'description' => 'Custom title color',
                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => __('Sub Title', 'ri-ghost'),
                        'value' => 'Sub Title',
                        'param_name' => 'sub_title',
                    ),
                    array(
                        'type' => 'colorpicker',
                        'heading' => __('Sub Title Color', 'ri-ghost'),
                        'param_name' => 'sub_title_color',
                        'description' => 'Custom sub title color',
                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => __('Description', 'ri-ghost'),
                        'value' => 'Description',
                        'param_name' => 'description',
                        'dependency' => Array('element' => 'style', 'value' => array('1')),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Link', 'ri-ghost'),
                        'value' => '#',
                        'param_name' => 'link',
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Text Link', 'ri-ghost'),
                        'value' => 'Text Link',
                        'param_name' => 'text_link',
                    ),
                    array(
                        'type' => 'checkbox',
                        'heading' => __('Open link in a new tab', 'ri-ghost'),
                        'value' => 'Open link in a new tab',
                        'param_name' => 'new_tab',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Link Style', 'ri-ghost' ),
                        'param_name' => 'link_style',
                        'value' => array(
                            __( 'Accent', 'ri-ghost' ) => 'accent',
                            __( 'Accent Radius', 'ri-ghost' ) => 'accent-radius',
                            __( 'Gray Light', 'ri-ghost' ) => 'gray-light',
                            __( 'Gray Light Radius', 'ri-ghost' ) => 'gray-light-radius',
                        ),
                        'description' => 'Select Content Position',
                        'std' => 'accent'
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Content Position', 'ri-ghost' ),
                        'param_name' => 'position',
                        'value' => array(
                            __( 'Top Left', 'ri-ghost' ) => 'top-left',
                            __( 'Top Center', 'ri-ghost' ) => 'top-center',
                            __( 'Top Right', 'ri-ghost' ) => 'top-right',
                            __( 'Middle Left', 'ri-ghost' ) => 'middle-left',
                            __( 'Middle Center', 'ri-ghost' ) => 'middle-center',
                            __( 'Middle Right', 'ri-ghost' ) => 'middle-right',
                            __( 'Bottom Left', 'ri-ghost' ) => 'bottom-left',
                            __( 'Bottom Center', 'ri-ghost' ) => 'bottom-center',
                            __( 'Bottom Right', 'ri-ghost' ) => 'bottom-right'
                        ),
                        'description' => 'Select Content Position',
                        'std' => 'middle-center'
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __( 'Extra class name', 'ri-ghost' ),
                        'param_name' => 'el_class',
                        'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'ri-ghost' )
                    )

                )
            )
        );
    }
}