<?php

if (!class_exists('RIT_Custom_Post_Type_Slider')) {
    class RIT_Custom_Post_Type_Slider
    {
        public static function &getInstance()
        {
            static $instance;
            if (!isset($instance)) {
                $instance = new RIT_Custom_Post_Type_Slider();
            }
            return $instance;
        }

        public function init() {
            add_action('init', array($this, 'register_slider'));
            add_action('init', array($this, 'register_slider_category'));
        }

        public function register_slider()
        {
            $labels = array(
                'name' => __('RIT Sliders', 'ri-ghost'),
                'singular_name' => __('Slider', 'ri-ghost'),
                'add_new' => __('Add New', 'ri-ghost'),
                'add_new_item' => __('Add New Slider', 'ri-ghost'),
                'edit_item' => __('Edit Slider', 'ri-ghost'),
                'new_item' => __('New Slider', 'ri-ghost'),
                'view_item' => __('View Slider', 'ri-ghost'),
                'search_items' => __('Search Sliders', 'ri-ghost'),
                'not_found' =>  __('No sliders have been added yet', 'ri-ghost'),
                'not_found_in_trash' => __('Nothing found in Trash', 'ri-ghost'),
                'parent_item_colon' => ''
            );

            $args = array(
                'labels' => $labels,
                'public' => true,
                'show_ui' => true,
                'show_in_menu' => true,
                'show_in_nav_menus' => false,
                'menu_icon'=> 'dashicons-image-flip-horizontal',
                'rewrite' => false,
                'supports' => array('title', 'editor'),
                'has_archive' => true,
            );

            register_post_type( 'slider' , $args );
        }

        public function register_slider_category()
        {
            $args = array(
                "label" 						=> __('Slider Categories', 'ri-ghost'),
                "singular_label" 				=> __('Slider Category', 'ri-ghost'),
                'public'                        => true,
                'hierarchical'                  => true,
                'show_ui'                       => true,
                'show_in_nav_menus'             => false,
                'args'                          => array( 'orderby' => 'term_order' ),
                'rewrite'                       => false,
                'query_var'                     => true
            );

            register_taxonomy( 'slider_category', 'slider', $args );
        }
    }

    RIT_Custom_Post_Type_Slider::getInstance()->init();
}