<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */
if (!function_exists('rit_shortcode_products_filter')) {
    function rit_shortcode_products_filter($atts, $content)
    {
        if ( class_exists( 'WooCommerce' ) ) {
            $product_categories = get_categories(
                array(
                    'taxonomy' => 'product_cat',
                )
            );
            $product_cats = array();
            $product_cats_all = '';
            if (count($product_categories) > 0) {

                foreach ($product_categories as $value) {
                    $product_cats[$value->name] = $value->slug;
                }
                $product_cats_all = implode(',', $product_cats);
            }


            $product_tags = get_terms('product_tag');
            $product_tags_arr = array();
            $product_tags_all = '';
            if (count($product_tags) > 0) {

                foreach ($product_tags as $value) {
                    $product_tags_arr[$value->name] = $value->slug;
                }
                $product_tags_all = implode(',', $product_tags_arr);
            }


            $attributes_arr = array();
            $attributes_arr_all = '';
            if (function_exists('wc_get_attribute_taxonomies')) {
                $product_attribute_taxonomies = wc_get_attribute_taxonomies();
                if (count($product_attribute_taxonomies) > 0) {

                    foreach ($product_attribute_taxonomies as $value) {
                        $attributes_arr[$value->attribute_label] = $value->attribute_name;
                    }
                    $attributes_arr_all = implode(',', $attributes_arr);
                }
            }

            $atts = shortcode_atts(array(
                'title' => 'Product Filter',
                'post_type' => 'product',
                'pagination' => 'simple',
                'column' => '3',
                'posts_per_page' => 4,
                'category' => '',
                'products_type' => 'products_grid',
                'products_img_size' => 'shop_thumbnail',
                'paged' => 1,
                'ignore_sticky_posts' => 1,
                'show' => '',
                'orderby' => 'date',
                'element_custom_class' => '',
                'filter_categories' => $product_cats_all,
                'filter_tags' => $product_tags_all,
                'filter_attributes' => $attributes_arr_all,
                'show_filter' => 1,
                'show_reset_filter' => '',
                'show_loadmore' => 1,
                'animation_show' => ''
            ), $atts);


            $meta_query = WC()->query->get_meta_query();


            $wc_attr = array(
                'post_type' => 'product',
                'posts_per_page' => $atts['posts_per_page'],
                'paged' => $atts['paged'],
                'orderby' => $atts['orderby'],
                'ignore_sticky_posts' => $atts['ignore_sticky_posts'],
            );

            if ($atts['show'] == 'featured') {


                $meta_query[] = array(
                    'key' => '_featured',
                    'value' => 'yes'
                );

                $wc_attr['meta_key'] = $meta_query;

            } elseif ($atts['show'] == 'onsale') {

                $product_ids_on_sale = wc_get_product_ids_on_sale();

                $wc_attr['post__in'] = $product_ids_on_sale;

                $wc_attr['meta_query'] = $meta_query;

            } elseif ($atts['show'] == 'best-selling') {

                $wc_attr['meta_key'] = 'total_sales';

                $wc_attr['meta_query'] = $meta_query;

            } elseif ($atts['show'] == 'latest') {

                $wc_attr['orderby'] = 'date';

                $wc_attr['order'] = 'DESC';

            } elseif ($atts['show'] == 'toprate') {

                add_filter('posts_clauses', array('WC_Shortcodes', 'order_by_rating_post_clauses'));

            } elseif ($atts['show'] == 'price') {

                $wc_attr['orderby'] = "meta_value_num {$wpdb->posts}.ID";
                $wc_attr['order'] = 'ASC';
                $wc_attr['meta_key'] = '_price';

            } elseif ($atts['show'] == 'price-desc') {

                $wc_attr['orderby'] = "meta_value_num {$wpdb->posts}.ID";
                $wc_attr['order'] = 'DESC';
                $wc_attr['meta_key'] = '_price';

            }
            if($atts['filter_categories'] != $product_cats_all && $atts['filter_categories'] !=  ''){
                $wc_attr['product_cat'] = $atts['filter_categories'];
            }

            $atts['wc_attr'] = $wc_attr;


            return rit_get_template_part('shortcode', 'product-filter', array('atts' => $atts));
        }
    }
}
if (!function_exists('products_carousel_script')) {
    function products_carousel_script()
    {
        wp_enqueue_script('owlCarousel', RIT_PLUGIN_URL . '/assets/js/owl.carousel.min.js', false, false, true);
    }
}

add_shortcode('rit_products_filter', 'rit_shortcode_products_filter');

add_action('vc_before_init', 'rit_product_filter_integrate_vc');

if (!function_exists('rit_product_filter_integrate_vc')) {
    function rit_product_filter_integrate_vc()
    {
        if ( class_exists( 'WooCommerce' ) ) {
            $product_categories = get_categories(
                array(
                    'taxonomy' => 'product_cat',
                )
            );
            $product_cats = array();
            $product_cats_all = '';
            if (count($product_categories) > 0) {

                foreach ($product_categories as $value) {
                    $product_cats[$value->name] = $value->slug;
                }
                $product_cats_all = implode(',', $product_cats);
            }


            $product_tags = get_terms('product_tag');
            $product_tags_arr = array();
            $product_tags_all = '';
            if (count($product_tags) > 0) {

                foreach ($product_tags as $value) {
                    $product_tags_arr[$value->name] = $value->slug;
                }
                $product_tags_all = implode(',', $product_tags_arr);
            }


            $attributes_arr = array();
            $attributes_arr_all = '';
            if (function_exists('wc_get_attribute_taxonomies')) {
                $product_attribute_taxonomies = wc_get_attribute_taxonomies();
                if (count($product_attribute_taxonomies) > 0) {

                    foreach ($product_attribute_taxonomies as $value) {
                        $attributes_arr[$value->attribute_label] = $value->attribute_name;
                    }
                    $attributes_arr_all = implode(',', $attributes_arr);
                }
            }


            vc_map(
                array(
                    'name' => esc_html__('RIT Products Filter', 'rit-core'),
                    'base' => 'rit_products_filter',
                    'icon' => 'icon-rit',
                    'category' => esc_html__('RIT', 'rit-core'),
                    'description' => esc_html__('Show multiple products by ID or SKU.', 'rit-core'),
                    'params' => array(
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Title', 'rit-core'),
                            'value' => 'Product Filter',
                            'param_name' => 'title',
                            'description' => esc_html__('Enter text used as shortcode title (Note: located above content element)', 'rit-core'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Layout type', 'rit-core'),
                            'value' => array(
                                esc_html__('Carousel', 'rit-core') => 'products_carousel',
                                esc_html__('Grid', 'rit-core') => 'products_grid',
                                esc_html__('List', 'rit-core') => 'products_list'
                            ),
                            'param_name' => 'products_type',
                            'description' => esc_html__('Select layout type for display product', 'rit-core'),
                            'std' => 'products_grid'
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Image size', 'rit-core'),
                            'value' => array(
                                esc_html__('Thumbnail', 'rit-core') => 'shop_thumbnail',
                                esc_html__('Catalog Images', 'rit-core') => 'shop_catalog',
                                esc_html__('Single Product Image', 'rit-core') => 'shop_single'
                            ),
                            'param_name' => 'products_img_size',
                            'description' => esc_html__('Select image size follow size in woocommerce product image size', 'rit-core'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Column number', 'rit-core'),
                            'value' => array(
                                esc_html__('1 Columns', 'rit-core') => '1',
                                esc_html__('2 Columns', 'rit-core') => '2',
                                esc_html__('3 Columns', 'rit-core') => '3',
                                esc_html__('4 Columns', 'rit-core') => '4',
                                esc_html__('6 Columns', 'rit-core') => '6'
                            ),
                            'std' => '3',
                            'param_name' => 'column',
                            'description' => esc_html__('Display product with the number of column', 'rit-core'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Asset type', 'rit-core'),
                            'value' => array(
                                esc_html__('All', 'rit-core') => '',
                                esc_html__('Featured product', 'rit-core') => 'featured',
                                esc_html__('Onsale product', 'rit-core') => 'onsale',
                                esc_html__('Best Selling', 'rit-core') => 'best-selling',
                                esc_html__('Latest product', 'rit-core') => 'latest',
                                esc_html__('Top rate product', 'rit-core') => 'toprate ',
                                esc_html__('Sort by price: low to high', 'rit-core') => 'price',
                                esc_html__('Sort by price: high to low', 'rit-core') => 'price-desc',
                            ),
                            'std' => '',
                            'param_name' => 'show',
                            'description' => esc_html__('Select asset type of products', 'rit-core'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Order by', 'rit-core'),
                            'value' => array(
                                esc_html__('Date', 'rit-core') => 'date',
                                esc_html__('Menu order', 'rit-core') => 'menu_order',
                                esc_html__('Title', 'rit-core') => 'title',
                            ),
                            'std' => 'date',
                            'param_name' => 'orderby',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Number of product', 'rit-core'),
                            'value' => 6,
                            'param_name' => 'posts_per_page',
                            'description' => esc_html__('Number of product showing', 'rit-core'),
                        ),
                        array(
                            "type" => "dropdown",
                            "heading" => esc_html__("Ignore sticky posts", 'rit-core'),
                            "param_name" => "ignore_sticky_posts",
                            'std' => 1,
                            "value" => array(
                                esc_html__('No', 'rit-core') => 0,
                                esc_html__('Yes', 'rit-core') => 1,
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Custom Class', 'rit-core'),
                            'value' => '',
                            'param_name' => 'element_custom_class',
                            'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'rit-core'),
                        ),
                        array(
                            "type" => "rit_multi_select",
                            "heading" => esc_html__("Categories showing in the filter", 'rit-core'),
                            "param_name" => "filter_categories",
                            "std" => $product_cats_all,
                            "value" => $product_cats,
                        ),
                        array(
                            "type" => "rit_multi_select",
                            "heading" => esc_html__("Tags showing in the filter", 'rit-core'),
                            "param_name" => "filter_tags",
                            "std" => $product_tags_all,
                            "value" => $product_tags_arr,
                        ),
                        array(
                            "type" => "rit_multi_select",
                            "heading" => esc_html__("Product attributes showing in the filter", 'rit-core'),
                            "param_name" => "filter_attributes",
                            "std" => $attributes_arr_all,
                            "value" => $attributes_arr,
                        ),
                        array(
                            "type" => "dropdown",
                            "heading" => esc_html__("Show Filter", 'rit-core'),
                            "param_name" => "show_filter",
                            'std' => 1,
                            "value" => array(
                                esc_html__('No', 'rit-core') => 0,
                                esc_html__('Yes', 'rit-core') => 1,
                            ),
                        ),
                        array(
                            "type" => "dropdown",
                            "heading" => esc_html__("Show Reset Filter", 'rit-core'),
                            "param_name" => "show_reset_filter",
                            'std' => 0,
                            "value" => array(
                                esc_html__('No', 'rit-core') => 0,
                                esc_html__('Yes', 'rit-core') => 1,
                            ),
                        ),
                        array(
                            "type" => "dropdown",
                            "heading" => esc_html__("Show Load More button", 'rit-core'),
                            "param_name" => "show_loadmore",
                            'std' => 1,
                            "value" => array(
                                esc_html__('No', 'rit-core') => 0,
                                esc_html__('Yes', 'rit-core') => 1,
                            ),
                        )
                    )
                )
            );
        }
    }
}