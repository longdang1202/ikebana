<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */

require_once RIT_PLUGIN_PATH . '/vendor/vafpress-post-formats-ui-develop/vp-post-formats-ui.php';