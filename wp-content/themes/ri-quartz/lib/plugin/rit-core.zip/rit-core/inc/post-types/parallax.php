<?php

if (!class_exists('RIT_Custom_Post_Type_Parallax')) {
    class RIT_Custom_Post_Type_Parallax
    {
        public static function &getInstance()
        {
            static $instance;
            if (!isset($instance)) {
                $instance = new RIT_Custom_Post_Type_Parallax();
            }
            return $instance;
        }

        public function init() {
            add_action('init', array($this, 'register_parallax'));
            add_action('init', array($this, 'register_parallax_category'));
        }

        public function register_parallax()
        {
            $labels = array(
                'name' => __('RIT Parallax', 'ri-ghost'),
                'singular_name' => __('parallax', 'ri-ghost'),
                'add_new' => __('Add New', 'ri-ghost'),
                'add_new_item' => __('Add New Parallax', 'ri-ghost'),
                'edit_item' => __('Edit Parallax', 'ri-ghost'),
                'new_item' => __('New Parallax', 'ri-ghost'),
                'view_item' => __('View Parallax', 'ri-ghost'),
                'search_items' => __('Search Parallax', 'ri-ghost'),
                'not_found' =>  __('No parallaxs have been added yet', 'ri-ghost'),
                'not_found_in_trash' => __('Nothing found in Trash', 'ri-ghost'),
                'parent_item_colon' => ''
            );

            $args = array(
                'labels' => $labels,
                'public' => true,
                'show_ui' => true,
                'show_in_menu' => true,
                'show_in_nav_menus' => false,
                'menu_icon'=> 'dashicons-welcome-view-site',
                'rewrite' => false,
                'supports' => array('title', 'editor'),
                'has_archive' => true,
            );

            register_post_type( 'parallax' , $args );
        }

        public function register_parallax_category()
        {
            $args = array(
                "label" 						=> __('Parallax Categories', 'ri-ghost'),
                "singular_label" 				=> __('Parallax Category', 'ri-ghost'),
                'public'                        => true,
                'hierarchical'                  => true,
                'show_ui'                       => true,
                'show_in_nav_menus'             => false,
                'args'                          => array( 'orderby' => 'term_order' ),
                'rewrite'                       => false,
                'query_var'                     => true
            );

            register_taxonomy( 'parallax_category', 'parallax', $args );
        }
    }

    RIT_Custom_Post_Type_Parallax::getInstance()->init();
}