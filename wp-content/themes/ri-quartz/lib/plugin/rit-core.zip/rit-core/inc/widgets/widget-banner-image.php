<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */

if (!class_exists('RITBannerImage')) {
    class RITBannerImage extends WP_Widget
    {
        public function __construct()
        {
            $widget_ops = array('classname' => 'widget-banner-image', 'description' => esc_html__('Show Banner Image.', 'rit-core'));

            $control_ops = array('id_base' => 'banner-widget');

            parent::__construct('banner-widget', esc_html__('RIT: Banner Image', 'rit-core'), $widget_ops, $control_ops);
        }

        public function widget($args, $instance)
        {
            extract($args);

            echo $before_widget;

            ?>
            <div class="banner-widget">
                <img src="<?php echo esc_url($instance['image_uri']); ?>" alt="<?php echo esc_html__('Banner Image', 'rit-core'); ?>" />
                <div class="banner-widget-content">
                    <?php
                    if ($instance['title']) {
                        echo '<h3>' . wp_kses($instance['title'], array('br'=>array(), 'span'=>array('style'=>array()))) . '</h3>';
                    }
                    ?>
                    <p><?php echo wp_kses($instance['description'], array('br'=>array())); ?></p>
                    <?php if($instance['link'] != ''){ ?>
                        <a class="rit-button rit-button-accent" href="<?php echo esc_url($instance['link']); ?>"><?php echo ($instance['text_link'] ? esc_html($instance['text_link']) : ''); ?></a>
                    <?php } ?>
                </div>
            </div>
            <?php

            echo $after_widget;
        }

        public function update($new_instance, $old_instance)
        {
            $instance = $old_instance;

            $instance['title'] = wp_kses($new_instance['title'], array('br'=>array(), 'span'=>array('style'=>array())));
            $instance['link'] = strip_tags($new_instance['link']);
            $instance['text_link'] = strip_tags($new_instance['text_link']);
            $instance['image_uri'] = $new_instance['image_uri'];
            $instance['description'] = strip_tags( $new_instance['description'] );

            return $instance;
        }

        public function form($instance)
        {
            $defaults = array(
                'title' => esc_html__('Banner Image Me', 'rit-core'),
                'image_uri' => "",
                'description' => "",
                'link' => "",
                'text_link' => "",
            );
            $instance = wp_parse_args((array)$instance, $defaults); ?>
            <p>
                <label for="<?php echo $this->get_field_id('title'); ?>">
                    <strong><?php esc_html_e('Title', 'rit-core') ?>:</strong>
                    <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
                           name="<?php echo $this->get_field_name('title'); ?>"
                           value="<?php if (isset($instance['title'])) echo $instance['title']; ?>"/>
                </label>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('image_uri'); ?>">
                    <strong style="display: block; padding-bottom: 20px"><?php echo esc_html__('Image:', 'rit-core'); ?></strong>
                    <img class="custom_media_image" src="<?php if(!empty($instance['image_uri'])){echo $instance['image_uri'];} ?>" style="display:block; padding-bottom: 20px; max-width: 100%" />
                    <input type="text" class="widefat custom_media_url" name="<?php echo $this->get_field_name('image_uri'); ?>" id="<?php echo $this->get_field_id('image_uri'); ?>" value="<?php echo $instance['image_uri']; ?>">
                    <input style="margin-top: 10px" type="button" value="<?php _e( 'Upload Image', 'themename' ); ?>" class="button custom_media_upload" id="custom_image_uploader"/>
                </label>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('description'); ?>">
                    <strong><?php esc_html_e('Description', 'rit-core') ?>:</strong>
                    <textarea rows="8" cols="10" class="widefat" id="<?php echo $this->get_field_id('description'); ?>" name="<?php echo $this->get_field_name('description'); ?>"><?php if (isset($instance['description'])) echo $instance['description']; ?></textarea>
                </label>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('link'); ?>">
                    <strong><?php esc_html_e('Link', 'rit-core') ?>:</strong>
                    <input type="text" class="widefat" id="<?php echo $this->get_field_id('link'); ?>"
                           name="<?php echo $this->get_field_name('link'); ?>"
                           value="<?php if (isset($instance['link'])) echo $instance['link']; ?>"/>
                </label>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('text_link'); ?>">
                    <strong><?php esc_html_e('Text Link', 'rit-core') ?>:</strong>
                    <input type="text" class="widefat" id="<?php echo $this->get_field_id('text_link'); ?>"
                           name="<?php echo $this->get_field_name('text_link'); ?>"
                           value="<?php if (isset($instance['text_link'])) echo $instance['text_link']; ?>"/>
                </label>
            </p>
            <script type="text/javascript">
                jQuery(document).ready( function(){
                    function media_upload( button_class) {
                        var _custom_media = true,
                            _orig_send_attachment = wp.media.editor.send.attachment;
                        jQuery('body').on('click',button_class, function(e) {
                            var button_id ='#'+jQuery(this).attr('id');
                            /* console.log(button_id); */
                            var self = jQuery(button_id);
                            var send_attachment_bkp = wp.media.editor.send.attachment;
                            var button = jQuery(button_id);
                            var id = button.attr('id').replace('_button', '');
                            _custom_media = true;
                            wp.media.editor.send.attachment = function(props, attachment){
                                if ( _custom_media  ) {
                                    jQuery('.custom_media_id').val(attachment.id);
                                    jQuery('.custom_media_url').val(attachment.url);
                                    jQuery('.custom_media_image').attr('src',attachment.url).css('display','block');
                                } else {
                                    return _orig_send_attachment.apply( button_id, [props, attachment] );
                                }
                            }
                            wp.media.editor.open(button);
                            return false;
                        });
                    }
                    media_upload( '.custom_media_upload');
                });
            </script>
        <?php
        }
    }
}
add_action('widgets_init', 'rit_banner_load_widgets');

function rit_banner_load_widgets()
{
    register_widget('RITBannerImage');
}