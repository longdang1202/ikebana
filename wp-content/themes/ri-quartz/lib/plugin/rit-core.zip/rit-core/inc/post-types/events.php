<?php

if (!class_exists('RIT_Custom_Post_Type_Events')) {
    class RIT_Custom_Post_Type_Events
    {
        public static function &getInstance()
        {
            static $instance;
            if (!isset($instance)) {
                $instance = new RIT_Custom_Post_Type_Events();
            }
            return $instance;
        }

        public function init() {
            add_action('init', array($this, 'register_events'));
            add_action('init', array($this, 'register_events_category'));
        }

        public function register_events()
        {
            $labels = array(
                'name' => __('RIT Events', 'ri-ghost'),
                'singular_name' => __('events', 'ri-ghost'),
                'add_new' => __('Add New', 'ri-ghost'),
                'add_new_item' => __('Add New Events', 'ri-ghost'),
                'edit_item' => __('Edit Events', 'ri-ghost'),
                'new_item' => __('New Events', 'ri-ghost'),
                'view_item' => __('View Events', 'ri-ghost'),
                'search_items' => __('Search Events', 'ri-ghost'),
                'not_found' =>  __('No eventss have been added yet', 'ri-ghost'),
                'not_found_in_trash' => __('Nothing found in Trash', 'ri-ghost'),
                'parent_item_colon' => ''
            );

            $args = array(
                'labels' => $labels,
                'public' => true,
                'show_ui' => true,
                'show_in_events' => true,
                'show_in_nav_eventss' => false,
                'events_icon'=> 'dashicons-welcome-view-site',
                'rewrite' => false,
                'supports' => array('title', 'editor'),
                'has_archive' => true,
            );

            register_post_type( 'events' , $args );
        }

        public function register_events_category()
        {
            $args = array(
                "label" 						=> __('Events Categories', 'ri-ghost'),
                "singular_label" 				=> __('Events Category', 'ri-ghost'),
                'public'                        => true,
                'hierarchical'                  => true,
                'show_ui'                       => true,
                'show_in_nav_eventss'             => false,
                'args'                          => array( 'orderby' => 'term_order' ),
                'rewrite'                       => false,
                'query_var'                     => true
            );

            register_taxonomy( 'events_category', 'events', $args );
        }
    }

    RIT_Custom_Post_Type_Events::getInstance()->init();
}
