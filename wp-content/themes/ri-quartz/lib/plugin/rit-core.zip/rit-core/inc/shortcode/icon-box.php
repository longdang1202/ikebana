<?php

function rit_shortcode_icon_box($atts)
{

    $atts = shortcode_atts(
        array(
            'type' => 'fontawesome',
            'icon_fontawesome' => 'fa fa-anchor',
            'icon_openiconic' => 'vc-oi vc-oi-dial',
            'icon_typicons' => 'typcn typcn-adjust-brightness',
            'icon_entypo' => 'entypo-icon entypo-icon-note',
            'icon_linecons' => 'vc_li vc_li-heart',
            'title' => 'Title',
            'title_top' => '15',
            'icon_top' => '10',
            'icon_custom' => '',
            'bg_color' => '',
            'description' => 'Description',
            'style' => 'horizontal',
            'border' => 'no',
            'custom_color' => '',
            'link' => '#',
            'el_class' => ''

        ), $atts);

    return rit_get_template_part('shortcode', 'icon-box', array('atts' => $atts));
}

add_shortcode('rit_icon_box', 'rit_shortcode_icon_box');

add_action('vc_before_init', 'rit_icon_box_integrate_vc');

if (!function_exists('rit_icon_box_integrate_vc')) {
    function rit_icon_box_integrate_vc()
    {
        vc_map(
            array(
                'name' => __('RIT Icon Box', 'ri-ghost'),
                'base' => 'rit_icon_box',
                'icon' => 'icon-rit',
                'category' => __('RIT', 'ri-ghost'),
                'description' => __('Show Icon Box', 'ri-ghost'),
                'params' => array(
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Icon library', 'js_composer' ),
                        'value' => array(
                            __( 'Font Awesome', 'js_composer' ) => 'fontawesome',
                            __( 'Open Iconic', 'js_composer' ) => 'openiconic',
                            __( 'Typicons', 'js_composer' ) => 'typicons',
                            __( 'Entypo', 'js_composer' ) => 'entypo',
                            __( 'Linecons', 'js_composer' ) => 'linecons',
                            __( 'Custom', 'js_composer' ) => 'custom',
                        ),
                        'admin_label' => true,
                        'param_name' => 'type',
                        'std' => 'fontawesome',
                        'description' => __( 'Select icon library.', 'js_composer' ),
                    ),
                    array(
                        'type' => 'iconpicker',
                        'heading' => __( 'Icon', 'js_composer' ),
                        'param_name' => 'icon_fontawesome',
                        'value' => 'fa fa-adjust', // default value to backend editor admin_label
                        'settings' => array(
                            'emptyIcon' => false,
                            // default true, display an "EMPTY" icon?
                            'iconsPerPage' => 4000,
                            // default 100, how many icons per/page to display, we use (big number) to display all icons in single page
                        ),
                        'dependency' => array(
                            'element' => 'type',
                            'value' => 'fontawesome',
                        ),
                        'description' => __( 'Select icon from library.', 'js_composer' ),
                    ),
                    array(
                        'type' => 'iconpicker',
                        'heading' => __( 'Icon', 'js_composer' ),
                        'param_name' => 'icon_openiconic',
                        'value' => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
                        'settings' => array(
                            'emptyIcon' => false, // default true, display an "EMPTY" icon?
                            'type' => 'openiconic',
                            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
                        ),
                        'dependency' => array(
                            'element' => 'type',
                            'value' => 'openiconic',
                        ),
                        'description' => __( 'Select icon from library.', 'js_composer' ),
                    ),
                    array(
                        'type' => 'iconpicker',
                        'heading' => __( 'Icon', 'js_composer' ),
                        'param_name' => 'icon_typicons',
                        'value' => 'typcn typcn-adjust-brightness', // default value to backend editor admin_label
                        'settings' => array(
                            'emptyIcon' => false, // default true, display an "EMPTY" icon?
                            'type' => 'typicons',
                            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
                        ),
                        'dependency' => array(
                            'element' => 'type',
                            'value' => 'typicons',
                        ),
                        'description' => __( 'Select icon from library.', 'js_composer' ),
                    ),
                    array(
                        'type' => 'iconpicker',
                        'heading' => __( 'Icon', 'js_composer' ),
                        'param_name' => 'icon_entypo',
                        'value' => 'entypo-icon entypo-icon-note', // default value to backend editor admin_label
                        'settings' => array(
                            'emptyIcon' => false, // default true, display an "EMPTY" icon?
                            'type' => 'entypo',
                            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
                        ),
                        'dependency' => array(
                            'element' => 'type',
                            'value' => 'entypo',
                        ),
                    ),
                    array(
                        'type' => 'iconpicker',
                        'heading' => __( 'Icon', 'js_composer' ),
                        'param_name' => 'icon_linecons',
                        'value' => 'vc_li vc_li-heart', // default value to backend editor admin_label
                        'settings' => array(
                            'emptyIcon' => false, // default true, display an "EMPTY" icon?
                            'type' => 'linecons',
                            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
                        ),
                        'dependency' => array(
                            'element' => 'type',
                            'value' => 'linecons',
                        ),
                        'description' => __( 'Select icon from library.', 'js_composer' ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Icon Custom', 'ri-ghost'),
                        'value' => 'Icon Custom',
                        'param_name' => 'icon_custom',
                        'dependency' => array(
                            'element' => 'type',
                            'value' => 'custom',
                        ),
                        'description' => __( 'Insert icon custom. Go to <a target="_blank" href="http://fortawesome.github.io/Font-Awesome/cheatsheet/">Font Awesome</a> and coppy class', 'js_composer' ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Title', 'ri-ghost'),
                        'value' => 'Title',
                        'param_name' => 'title',
                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => __('Description', 'ri-ghost'),
                        'value' => 'Description',
                        'param_name' => 'description',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Style', 'ri-ghost' ),
                        'param_name' => 'style',
                        'value' => array(
                            __( 'Horizontal', 'ri-ghost' ) => 'horizontal',
                            __( 'Horizontal 2', 'ri-ghost' ) => 'horizontal-2',
                            __( 'Horizontal 3', 'ri-ghost' ) => 'horizontal-3',
                            __( 'Vertical', 'ri-ghost' ) => 'vertical',
                            __( 'Icon Title', 'ri-ghost' ) => 'icon-title'
                        ),
                        'description' => 'Select Style'
                    ),
                    array(
                        'type' => 'colorpicker',
                        'heading' => __('Custom Color', 'ri-ghost'),
                        'param_name' => 'custom_color',
                        'description' => __( 'Color aplly for title and border around and icon color.', 'ri-ghost' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('horizontal-2', 'horizontal-3'),
                        ),
                    ),
                    array(
                        'type' => 'colorpicker',
                        'heading' => __('Background Icon Color', 'ri-ghost'),
                        'param_name' => 'bg_color',
                        'description' => __( 'Color aplly for icon background color.', 'ri-ghost' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('icon-title'),
                        ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Icon top spacing', 'ri-ghost'),
                        'value' => '10',
                        'param_name' => 'icon_top',
                        'description' => __( 'Logo top spacing. Note: Not include "px" after value.', 'ri-ghost' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('horizontal','horizontal-2','horizontal-3','vertical'),
                        ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Title top spacing', 'ri-ghost'),
                        'value' => '15',
                        'param_name' => 'title_top',
                        'description' => __( 'Title top spacing. Note: Not include "px" after value.', 'ri-ghost' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('icon-title'),
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Border Bottom', 'ri-ghost' ),
                        'param_name' => 'border',
                        'value' => array(
                            __( 'Yes', 'ri-ghost' ) => 'yes',
                            __( 'No', 'ri-ghost' ) => 'no'
                        ),
                        'std' => 'no',
                        'description' => 'Select Style'
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __('Link', 'ri-ghost'),
                        'value' => '#',
                        'param_name' => 'link',
                        'description' => __( 'If Empty title will disable link.', 'ri-ghost' )
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => __( 'Extra class name', 'ri-ghost' ),
                        'param_name' => 'el_class',
                        'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'ri-ghost' )
                    )
                    
                )
            )
        );
    }
}