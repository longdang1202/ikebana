<?php
if (!class_exists('RIT_Customize')) {
    class RIT_Customize
    {
        public $customizers = array();

        public function init()
        {
            $this->customizer();
            add_action('customize_controls_enqueue_scripts', array($this, 'rit_customizer_script'));
            add_action('customize_controls_print_scripts', array($this, 'rit_customizer_controls_print_scripts'));
            add_action('customize_register', array($this, 'rit_register_theme_customizer'));
            add_action('customize_register', array($this, 'remove_default_customize_section'), 20);
            RIT_Customize_Import_Export::getInstance();
        }

        public static function &getInstance()
        {
            static $instance;
            if (!isset($instance)) {
                $instance = new RIT_Customize();
            }
            return $instance;
        }

        protected function customizer()
        {

            $this->panels = array(
                'header_panel' => array(
                    'title'          => 'Header Options',
                    'description'    => '',
                    'priority' => 1,
                ),
                'color_panel' => array(
                    'title'          => 'Customizer color, background...',
                    'description'    => '',
                    'priority' => 6,
                ),
            );

            $this->customizers = array(

                'rit_new_section_general' => array(
                    'title' => __('General Options', 'ri-ghost'),
                    'description' => '',
                    'priority' => 0,
                    'settings' => array(
                        'rit_favicon' => array(
                            'class' => 'image',
                            'label' => __('Upload Favicon', 'ri-ghost'),
                            'priority' => 0
                        ),
                        'rit_loader_type' => array(
                            'type' => 'radio',
                            'label' => __('Icon Loader', 'ri-ghost'),
                            'priority' => 2,
                            'choices' => array(
                                '1' => __('Yes', 'ri-ghost'),
                                '0' => __('No', 'ri-ghost')
                            ),
                            'params' => array(
                                'default' => '1',
                            )
                        ),
                        'rit_enable_responsive' => array(
                            'type' => 'radio',
                            'label' => __('Enable Responsive', 'ri-ghost'),
                            'priority' => 1,
                            'choices' => array(
                                '1' => __('Yes', 'ri-ghost'),
                                '0' => __('No', 'ri-ghost')
                            ),
                            'params' => array(
                                'default' => '1',
                            )
                        ),
                        'rit_page_layout' => array(
                            'type' => 'radio',
                            'label' => __('Page Layout', 'ri-ghost'),
                            'priority' => 2,
                            'choices' => array(
                                'full' => __('Full Width', 'ri-ghost'),
                                'boxed' => __('Boxed', 'ri-ghost')
                            ),
                            'params' => array(
                                'default' => '1',
                            )
                        ),
                        'rit_custom_css' => array(
                            'type' => 'textarea',
                            'label' => __('Custom CSS', 'ri-ghost'),
                            'priority' => 6
                        ),
                        'rit_custom_js' => array(
                            'type' => 'textarea',
                            'label' => __('Custom JS', 'ri-ghost'),
                            'priority' => 7
                        )
                    )
                ),

                'rit_new_section_header_top' => array(
                    'title' => __('Header Top Options', 'ri-ghost'),
                    'description' => 'Header Top Options',
                    'priority' => 1,
                    'panel' => 'header_panel',
                    'settings' => array(
                        'rit_enable_header_top' => array(
                            'type' => 'radio',
                            'label' => __('Enable Header Top', 'ri-ghost'),
                            'priority' => 0,
                            'choices' => array(
                                '1' => __('Yes', 'ri-ghost'),
                                '0' => __('No', 'ri-ghost')
                            ),
                            'params' => array(
                                'default' => '0',
                            ),
                        ),
                        'rit_enable_header_top_link' => array(
                            'type' => 'radio',
                            'label' => __('Enable Header Top Link', 'ri-ghost'),
                            'priority' => 0,
                            'choices' => array(
                                '1' => __('Yes', 'ri-ghost'),
                                '0' => __('No', 'ri-ghost')
                            ),
                            'params' => array(
                                'default' => '1',
                            ),
                        )
                    ),
                ),

                'rit_new_section_header' => array(
                    'title' => __('Header Primary', 'ri-ghost'),
                    'description' => '',
                    'priority' => 1,
                    'panel' => 'header_panel',
                    'settings' => array(
                        'rit_default_header' => array(
                            'class' => 'pic',
                            'label' => __('Header Option', 'ri-ghost'),
                            'priority' => 2,
                            'type' => 'grid',
                            'choices' => array(
                                '1' => __(RIT_PLUGIN_URL. 'inc/customize/assets/images/header/header-1.png', 'ri-ghost'),
                                '2' => __(RIT_PLUGIN_URL. 'inc/customize/assets/images/header/header-2.png', 'ri-ghost'),
                                '3' => __(RIT_PLUGIN_URL. 'inc/customize/assets/images/header/header-3.png', 'ri-ghost'),
                                '4' => __(RIT_PLUGIN_URL. 'inc/customize/assets/images/header/header-4.png', 'ri-ghost'),
                                '5' => __(RIT_PLUGIN_URL. 'inc/customize/assets/images/header/header-5.png', 'ri-ghost'),
                                '6' => __(RIT_PLUGIN_URL. 'inc/customize/assets/images/header/header-6.png', 'ri-ghost')

                            ),
                            'params' => array(
                                'default' => '5',
                            )
                        ),
                        'rit_logo' => array(
                            'class' => 'image',
                            'label' => __('Logo', 'ri-ghost'),
                            'description' => __('Upload Logo Image', 'ri-ghost'),
                            'priority' => 0
                        ),
                        'rit_logo_sticky' => array(
                            'class' => 'image',
                            'label' => __('Logo Sticky', 'ri-ghost'),
                            'description' => __('Upload Logo Image', 'ri-ghost'),
                            'priority' => 0
                        ),
                        'rit_logo_retina' => array(
                            'class' => 'image',
                            'label' => __('Logo Retina', 'ri-ghost'),
                            'description' => __('Upload Logo Retina Image', 'ri-ghost'),
                            'priority' => 1
                        ),
                        'rit_header_position' => array(
                            'type' => 'select',
                            'label' => __('Header Position', 'ri-ghost'),
                            'priority' => 2,
                            'choices' => array(
                                'normal' => __('Normal', 'ri-ghost'),
                                'absolute' => __('Absolute', 'ri-ghost')
                            ),
                            'params' => array(
                                'default' => 'normal',
                            ),
                            'description' => __('If you choose position absolute. Header will override slider or content', 'ri-ghost'),
                        ),
                        'rit_logo_height' => array(
                            'type' => 'number',
                            'label' => __('Logo Height', 'ri-ghost'),
                            'description' => __('Fill Height Logo. Note: without include (px)', 'ri-ghost'),
                            'priority' => 2,
                            'params' => array(
                                'default' => '54',
                            ),
                        ),
                        'rit_logo_retina_height' => array(
                            'type' => 'number',
                            'label' => __('Logo Retina Height', 'ri-ghost'),
                            'description' => __('Fill Height Logo. Note: without include (px)', 'ri-ghost'),
                            'priority' => 2,
                            'params' => array(
                                'default' => '40',
                            ),
                        ),
                        'rit_logo_top_spacing' => array(
                            'type' => 'number',
                            'label' => __('Logo Top spacing', 'ri-ghost'),
                            'description' => __('Fill Logo Top spacing. Note: without include (px)', 'ri-ghost'),
                            'priority' => 3,
                            'params' => array(
                                'default' => '0',
                            ),
                        ),
                        'rit_logo_bottom_spacing' => array(
                            'type' => 'number',
                            'label' => __('Logo Bottom spacing', 'ri-ghost'),
                            'description' => __('Fill Logo Bottom spacing. Note: without include (px)', 'ri-ghost'),
                            'priority' => 4,
                            'params' => array(
                                'default' => '0',
                            ),
                        ),
                        'rit_enable_sticky_header' => array(
                            'type' => 'radio',
                            'label' => __('Enable Sticky Header', 'ri-ghost'),
                            'priority' => 2,
                            'choices' => array(
                                '1' => __('Yes', 'ri-ghost'),
                                '0' => __('No', 'ri-ghost')
                            ),
                            'params' => array(
                                'default' => '1',
                            ),
                        ),
                        'rit_show_tagline' => array(
                            'type' => 'radio',
                            'label' => __('Show Tagline', 'ri-ghost'),
                            'priority' => 2,
                            'choices' => array(
                                '1' => __('Yes', 'ri-ghost'),
                                '0' => __('No', 'ri-ghost')
                            ),
                            'params' => array(
                                'default' => '1',
                            ),
                        )
                    )
                ),

                'rit_new_section_header_bottom' => array(
                    'title' => __('Header Bottom Options', 'ri-ghost'),
                    'description' => 'Header Bottom Option',
                    'priority' => 2,
                    'panel' => 'header_panel',
                    'settings' => array(
                        'rit_enable_header_bottom' => array(
                            'type' => 'radio',
                            'label' => __('Enable Header Bottom', 'ri-ghost'),
                            'priority' => 0,
                            'choices' => array(
                                '1' => __('Yes', 'ri-ghost'),
                                '0' => __('No', 'ri-ghost')
                            ),
                            'params' => array(
                                'default' => '1',
                            ),
                        ),
                        'rit_heading_vertical' => array(
                            'class' => 'heading',
                            'label' => __('Vertical menu', 'ri-ghost'),
                            'priority' => 0,
                        ),
                        'rit_vertical_title' => array(
                            'type' => 'text',
                            'label' => __('Vertical menu title', 'ri-ghost'),
                            'description' => '',
                            'priority' => 1,
                            'params' => array(
                                'default' => 'CATEGORIES',
                            ),
                        ),
                        'rit_vertical_show' => array(
                            'type' => 'select',
                            'label' => __('Show Menu Mode', 'ri-ghost'),
                            'priority' => 2,
                            'choices' => array(
                                'hover' => __('When Hover', 'ri-ghost'),
                                'click' => __('When Click', 'ri-ghost'),
                                'show' => __('Always Show', 'ri-ghost')
                            ),
                            'params' => array(
                                'default' => 'show',
                            ),
                        ),
                    ),
                ),

                'rit_new_section_footer' => array(
                    'title' => __('Footer Options', 'ri-ghost'),
                    'description' => '',
                    'priority' => 2,
                    'settings' => array(
                        'rit_default_footer' => array(
                            'class' => 'pic',
                            'label' => __('Footer Layouts', 'ri-ghost'),
                            'priority' => 0,
                            'type' => 'grid',
                            'choices' => array(
                                '1' => __(RIT_PLUGIN_URL. 'inc/customize/assets/images/footer/footer-1.png', 'ri-ghost'),
                                '2' => __(RIT_PLUGIN_URL. 'inc/customize/assets/images/footer/footer-2.png', 'ri-ghost'),
                            ),
                            'params' => array(
                                'default' => '1',
                            )
                        ),
                        'rit_footer_logo' => array(
                            'class' => 'image',
                            'label' => __('Footer Logo', 'ri-ghost'),
                            'priority' => 1
                        ),
                        'rit_enable_copyright' => array(
                            'type' => 'checkbox',
                            'label' => __('Enable Copyright', 'ri-ghost'),
                            'description' => '',
                            'priority' => 2,
                            'params' => array(
                                'default' => '1',
                            ),
                        ),
                        'rit_copyright_text' => array(
                            'type' => 'textarea',
                            'label' => __('Footer Copyright Text', 'ri-ghost'),
                            'description' => '',
                            'priority' => 3
                        )
                    )
                ),

                'rit_new_section_font_family' => array(
                    'title' => esc_html(__('Font Family Options', 'ri-logistic')),
                    'description' => '',
                    'priority' => 4,
                    'settings' => array(
                        'rit_body_font_heading' => array(
                            'class' => 'heading',
                            'label' => esc_html(__('Body Font', 'ri-logistic')),
                            'priority' => 0
                        ),
                        'rit_body_font_select' => array(
                            'type' => 'select',
                            'label' => esc_html(__('Body Font', 'ri-logistic')),
                            'description' => '',
                            'priority' => 1,
                            'choices' => array(
                                'standard' => esc_html(__('Standard', 'ri-logistic')),
                                'google' => esc_html(__('Google', 'ri-logistic'))
                            ),
                            'params' => array(
                                'default' => 'google',
                            ),
                        ),
                        'rit_body_font_standard' => array(
                            'type' => 'select',
                            'label' => esc_html(__('Body Standard Font', 'ri-logistic')),
                            'description' => '',
                            'priority' => 2,
                            'choices' => array(
                                'Arial' => esc_html(__('Arial', 'ri-logistic')),
                                'Courier New' => esc_html(__('Courier New', 'ri-logistic')),
                                'Georgia' => esc_html(__('Georgia', 'ri-logistic')),
                                'Helvetica' => esc_html(__('Helvetica', 'ri-logistic')),
                                'Lucida Sans' => esc_html(__('Lucida Sans', 'ri-logistic')),
                                'Lucida Sans Unicode' => esc_html(__('Lucida Sans Unicode', 'ri-logistic')),
                                'Myriad Pro' => esc_html(__('Myriad Pro', 'ri-logistic')),
                                'Palatino Linotype' => esc_html(__('Palatino Linotype', 'ri-logistic')),
                                'Tahoma' => esc_html(__('Tahoma', 'ri-logistic')),
                                'Times New Roman' => esc_html(__('Times New Roman', 'ri-logistic')),
                                'Trebuchet MS' => esc_html(__('Trebuchet MS', 'ri-logistic')),
                                'Verdana' => esc_html(__('Verdana', 'ri-logistic'))
                            ),
                            'params' => array(
                                'default' => 'Arial',
                            ),
                            'dependency' => array('rit_body_font_select'=> 'standard')
                        ),
                        'rit_body_font_google' => array(
                            'class' => 'googlefont',
                            'label' => esc_html(__('Body Google Font', 'ri-logistic')),
                            'description' => '',
                            'priority' => 3,
                            'params' => array(
                                'default' => json_encode(array('family' => 'Lato', 'variants' => array('300','400','700', '900'), 'subsets' => array('latin'))),
                            ),
                            'dependency' => array('rit_body_font_select'=> 'google')
                        ),
                        'rit_menu_font_heading' => array(
                            'class' => 'heading',
                            'label' => esc_html(__('Menu Font', 'ri-logistic')),
                            'priority' => 4
                        ),
                        'rit_menu_font_select' => array(
                            'type' => 'select',
                            'label' => esc_html(__('Menu Font', 'ri-logistic')),
                            'description' => '',
                            'priority' => 5,
                            'choices' => array(
                                'standard' => esc_html(__('Standard', 'ri-logistic')),
                                'google' => esc_html(__('Google', 'ri-logistic'))
                            ),
                            'params' => array(
                                'default' => 'google',
                            ),
                        ),
                        'rit_menu_font_standard' => array(
                            'type' => 'select',
                            'label' => esc_html(__('Menu Standard Font', 'ri-logistic')),
                            'description' => '',
                            'priority' => 6,
                            'choices' => array(
                                'Arial' => esc_html(__('Arial', 'ri-logistic')),
                                'Courier New' => esc_html(__('Courier New', 'ri-logistic')),
                                'Georgia' => esc_html(__('Georgia', 'ri-logistic')),
                                'Helvetica' => esc_html(__('Helvetica', 'ri-logistic')),
                                'Lucida Sans' => esc_html(__('Lucida Sans', 'ri-logistic')),
                                'Lucida Sans Unicode' => esc_html(__('Lucida Sans Unicode', 'ri-logistic')),
                                'Myriad Pro' => esc_html(__('Myriad Pro', 'ri-logistic')),
                                'Palatino Linotype' => esc_html(__('Palatino Linotype', 'ri-logistic')),
                                'Tahoma' => esc_html(__('Tahoma', 'ri-logistic')),
                                'Times New Roman' => esc_html(__('Times New Roman', 'ri-logistic')),
                                'Trebuchet MS' => esc_html(__('Trebuchet MS', 'ri-logistic')),
                                'Verdana' => esc_html(__('Verdana', 'ri-logistic'))
                            ),
                            'params' => array(
                                'default' => 'Arial',
                            ),
                            'dependency' => array('rit_menu_font_select'=> 'standard')
                        ),
                        'rit_menu_font_google' => array(
                            'class' => 'googlefont',
                            'label' => esc_html(__('Menu Google Font', 'ri-logistic')),
                            'description' => '',
                            'priority' => 7,
                            'params' => array(
                                'default' => json_encode(array('family' => 'Montserrat', 'variants' => array('400','700'), 'subsets' => array('latin'))),
                            ),
                            'dependency' => array('rit_menu_font_select'=> 'google')
                        ),
                        'rit_heading_font_heading' => array(
                            'class' => 'heading',
                            'label' => esc_html(__('Heading Font', 'ri-logistic')),
                            'description' => 'Font for tag heading (h1 - h6)',
                            'priority' => 8
                        ),
                        'rit_heading_font_select' => array(
                            'type' => 'select',
                            'label' => esc_html(__('Heading Font', 'ri-logistic')),
                            'description' => '',
                            'priority' => 9,
                            'choices' => array(
                                'standard' => esc_html(__('Standard', 'ri-logistic')),
                                'google' => esc_html(__('Google', 'ri-logistic'))
                            ),
                            'params' => array(
                                'default' => 'google',
                            ),
                        ),
                        'rit_heading_font_standard' => array(
                            'type' => 'select',
                            'label' => esc_html(__('Heading Standard Font', 'ri-logistic')),
                            'description' => '',
                            'priority' => 10,
                            'choices' => array(
                                'Arial' => esc_html(__('Arial', 'ri-logistic')),
                                'Courier New' => esc_html(__('Courier New', 'ri-logistic')),
                                'Georgia' => esc_html(__('Georgia', 'ri-logistic')),
                                'Helvetica' => esc_html(__('Helvetica', 'ri-logistic')),
                                'Lucida Sans' => esc_html(__('Lucida Sans', 'ri-logistic')),
                                'Lucida Sans Unicode' => esc_html(__('Lucida Sans Unicode', 'ri-logistic')),
                                'Myriad Pro' => esc_html(__('Myriad Pro', 'ri-logistic')),
                                'Palatino Linotype' => esc_html(__('Palatino Linotype', 'ri-logistic')),
                                'Tahoma' => esc_html(__('Tahoma', 'ri-logistic')),
                                'Times New Roman' => esc_html(__('Times New Roman', 'ri-logistic')),
                                'Trebuchet MS' => esc_html(__('Trebuchet MS', 'ri-logistic')),
                                'Verdana' => esc_html(__('Verdana', 'ri-logistic'))
                            ),
                            'params' => array(
                                'default' => 'Arial',
                            ),
                            'dependency' => array('rit_heading_font_select'=> 'standard')
                        ),
                        'rit_heading_font_google' => array(
                            'class' => 'googlefont',
                            'label' => esc_html(__('Heading Google Font', 'ri-logistic')),
                            'description' => '',
                            'priority' => 11,
                            'params' => array(
                                'default' => json_encode(array('family' => 'Montserrat', 'variants' => array('400','700'), 'subsets' => array('latin'))),
                            ),
                            'dependency' => array('rit_heading_font_select'=> 'google')
                        )
                    )
                ),
                'rit_new_section_font_size' => array(
                    'title' => __('Font Size Options', 'ri-logistic'),
                    'description' => '',
                    'priority' => 4,
                    'settings' => array(
                        'rit_fontsize_heading' => array(
                            'class' => 'heading',
                            'label' => esc_html(__('Font Size', 'ri-logistic')),
                            'priority' => 0
                        ),
                        'rit_enable_body_font_size' => array(
                            'type' => 'number',
                            'label' => __('Body Font Size', 'ri-logistic'),
                            'description' => wp_kses(__('Font size of body. <strong>Note: Excluding "px" after value</strong>', 'ri-logistic'), array('strong'=>array())),
                            'priority' => 0,
                            'params' => array(
                                'default' => '14',
                            )
                        ),
                        'rit_enable_bodyline_height' => array(
                            'type' => 'number',
                            'label' => __('Body Font Line Height', 'ri-logistic'),
                            'description' => wp_kses(__('Line Height font of body. <strong>Note: Excluding "px" after value</strong>', 'ri-logistic'), array('strong'=>array())),
                            'priority' => 1,
                            'params' => array(
                                'default' => '14',
                            )
                        ),
                        'rit_enable_menu_font_size' => array(
                            'type' => 'number',
                            'label' => __('Menu Font Size', 'ri-logistic'),
                            'description' => wp_kses(__('Font size of font of body. <strong>Note: Excluding "px" after value</strong>', 'ri-logistic'), array('strong'=>array())),
                            'priority' => 2,
                            'params' => array(
                                'default' => '14',
                            )
                        ),
                        'rit_font_heading_size' => array(
                            'class' => 'heading',
                            'label' => esc_html(__('Font Size Heading', 'ri-logistic')),
                            'priority' => 2
                        ),
                        'rit_font_size_h1' => array(
                            'type' => 'number',
                            'label' => __('Font Size h1', 'ri-logistic'),
                            'description' => wp_kses(__('Fontsize of tag "h1". <strong>Note: Excluding "px" after value</strong>', 'ri-logistic'), array('strong'=>array())),
                            'priority' => 2,
                            'params' => array(
                                'default' => '36',
                            )
                        ),
                        'rit_font_size_h2' => array(
                            'type' => 'number',
                            'label' => __('Font Size h2', 'ri-logistic'),
                            'description' => wp_kses(__('Fontsize of tag "h2". <strong>Note: Excluding "px" after value</strong>', 'ri-logistic'), array('strong'=>array())),
                            'priority' => 2,
                            'params' => array(
                                'default' => '30',
                            )
                        ),
                        'rit_font_size_h3' => array(
                            'type' => 'number',
                            'label' => __('Font Size h3', 'ri-logistic'),
                            'description' => wp_kses(__('Fontsize of tag "h3". <strong>Note: Excluding "px" after value</strong>', 'ri-logistic'), array('strong'=>array())),
                            'priority' => 2,
                            'params' => array(
                                'default' => '24',
                            )
                        ),
                        'rit_font_size_h4' => array(
                            'type' => 'number',
                            'label' => __('Font Size h4', 'ri-logistic'),
                            'description' => wp_kses(__('Fontsize of tag "h4". <strong>Note: Excluding "px" after value</strong>', 'ri-logistic'), array('strong'=>array())),
                            'priority' => 2,
                            'params' => array(
                                'default' => '22',
                            )
                        ),
                        'rit_font_size_h5' => array(
                            'type' => 'number',
                            'label' => __('Font Size h5', 'ri-logistic'),
                            'description' => wp_kses(__('Fontsize of tag "h5". <strong>Note: Excluding "px" after value</strong>', 'ri-logistic'), array('strong'=>array())),
                            'priority' => 2,
                            'params' => array(
                                'default' => '20',
                            )
                        ),
                        'rit_font_size_h6' => array(
                            'type' => 'number',
                            'label' => __('Font Size h6', 'ri-logistic'),
                            'description' => wp_kses(__('Fontsize of tag "h6". <strong>Note: Excluding "px" after value</strong>', 'ri-logistic'), array('strong'=>array())),
                            'priority' => 2,
                            'params' => array(
                                'default' => '18',
                            )
                        ),
                    )
                ),

                'rit_new_section_social' => array(
                    'title' => __('Social Profiles', 'ri-ghost'),
                    'description' => '',
                    'priority' => 5,
                    'settings' => array(
                        'rit_social_twitter' => array(
                            'type' => 'text',
                            'label' => __('Twitter', 'ri-ghost'),
                            'description' => 'Your Twitter username (no @).',
                            'priority' => 0,
                            'params' => array(
                                'default' => 'username',
                            ),
                        ),
                        'rit_social_facebook' => array(
                            'type' => 'text',
                            'label' => __('Facebook', 'ri-ghost'),
                            'description' => 'Your facebook page/profile url',
                            'priority' => 1,
                            'params' => array(
                                'default' => 'page/profile-url',
                            ),
                        ),
                        'rit_social_dribbble' => array(
                            'type' => 'text',
                            'label' => __('Dribbble', 'ri-ghost'),
                            'description' => 'Your Dribbble username',
                            'priority' => 2,
                            'params' => array(
                                'default' => 'username',
                            ),
                        ),
                        'rit_social_vimeo' => array(
                            'type' => 'text',
                            'label' => __('Vimeo', 'ri-ghost'),
                            'description' => 'Your Vimeo username',
                            'priority' => 3,
                            'params' => array(
                                'default' => 'username',
                            ),
                        ),
                        'rit_social_tumblr' => array(
                            'type' => 'text',
                            'label' => __('Tumblr', 'ri-ghost'),
                            'description' => 'Your Tumblr username',
                            'priority' => 4,
                            'params' => array(
                                'default' => 'username',
                            ),
                        ),
                        'rit_social_skype' => array(
                            'type' => 'text',
                            'label' => __('Skype', 'ri-ghost'),
                            'description' => 'Your Skype username',
                            'priority' => 5,
                            'params' => array(
                                'default' => 'username',
                            ),
                        ),
                        'rit_social_linkedin' => array(
                            'type' => 'text',
                            'label' => __('LinkedIn', 'ri-ghost'),
                            'description' => 'Your LinkedIn page/profile url',
                            'priority' => 6,
                            'params' => array(
                                'default' => 'page/profile-url',
                            ),
                        ),
                        'rit_social_googleplus' => array(
                            'type' => 'text',
                            'label' => __('Google+', 'ri-ghost'),
                            'description' => 'Your Google+ page/profile URL',
                            'priority' => 7,
                            'params' => array(
                                'default' => 'page/profile-url',
                            ),
                        ),
                        'rit_social_flickr' => array(
                            'type' => 'text',
                            'label' => __('Flickr', 'ri-ghost'),
                            'description' => 'Your Flickr page url',
                            'priority' => 8,
                            'params' => array(
                                'default' => 'page-url',
                            ),
                        ),
                        'rit_social_youTube' => array(
                            'type' => 'text',
                            'label' => __('YouTube', 'ri-ghost'),
                            'description' => 'Your YouTube URL',
                            'priority' => 9,
                            'params' => array(
                                'default' => 'youtube-url',
                            ),
                        ),
                        'rit_social_pinterest' => array(
                            'type' => 'text',
                            'label' => __('Pinterest', 'ri-ghost'),
                            'description' => 'Your Pinterest username',
                            'priority' => 10,
                            'params' => array(
                                'default' => 'username',
                            ),
                        ),
                        'rit_social_foursquare' => array(
                            'type' => 'text',
                            'label' => __('Foursquare', 'ri-ghost'),
                            'description' => 'Your Foursqaure URL',
                            'priority' => 11,
                            'params' => array(
                                'default' => 'url',
                            ),
                        ),
                        'rit_social_instagram' => array(
                            'type' => 'text',
                            'label' => __('Instagram', 'ri-ghost'),
                            'description' => 'Your Instagram username',
                            'priority' => 12,
                            'params' => array(
                                'default' => 'username',
                            ),
                        ),
                        'rit_social_github' => array(
                            'type' => 'text',
                            'label' => __('GitHub', 'ri-ghost'),
                            'description' => 'Your GitHub URL',
                            'priority' => 13,
                            'params' => array(
                                'default' => 'url',
                            ),
                        ),
                        'rit_social_xing' => array(
                            'type' => 'text',
                            'label' => __('Xing', 'ri-ghost'),
                            'description' => 'Your Xing URL',
                            'priority' => 14,
                            'params' => array(
                                'default' => 'url',
                            ),
                        ),
                    )
                ),

                'rit_new_section_color_accent' => array(
                    'title' => __('Color - Accent', 'ri-ghost'),
                    'description' => '',
                    'priority' => 6,
                    'panel' => 'color_panel',
                    'settings' => array(
                        'rit_accent_color' => array(
                            'class' => 'color',
                            'label' => __('Accent Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_accent_color_2' => array(
                            'class' => 'color',
                            'label' => __('Accent Color 2', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#ff6600',
                            ),
                        )
                    )
                ),


                'rit_new_section_color_page' => array(
                    'title' => __('Color - Page', 'ri-ghost'),
                    'description' => '',
                    'priority' => 7,
                    'panel' => 'color_panel',
                    'settings' => array(
                        'rit_page_bg' => array(
                            'class' => 'image',
                            'label' => __('Page Background Image', 'ri-ghost'),
                            'priority' => 0
                        ),
                        'rit_page_background_color' => array(
                            'class' => 'color',
                            'label' => __('Page Background Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#ffffff',
                            )
                        ),
                        'rit_page_text_color' => array(
                            'class' => 'color',
                            'label' => __('Page Text Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#353535',
                            )
                        ),
                        'rit_page_link_color' => array(
                            'class' => 'color',
                            'label' => __('Page Link Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#353535',
                            )
                        ),
                        'rit_page_link_hover_color' => array(
                            'class' => 'color',
                            'label' => __('Page Link Hover Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#353535',
                            )
                        )
                    )
                ),

                'rit_new_section_color_header_top' => array(
                    'title' => __('Color - Header Top', 'ri-ghost'),
                    'description' => '',
                    'priority' => 8,
                    'panel' => 'color_panel',
                    'settings' => array(
                        'rit_header_top_bg_image' => array(
                            'class' => 'image',
                            'label' => __('Background Image', 'ri-ghost'),
                            'priority' => 0,
                        ),
                        'rit_header_top_bg_repeat' => array(
                            'type' => 'select',
                            'label' => __('Background Repeat', 'ri-ghost'),
                            'priority' => 0,
                            'choices' => array(
                                'no-repeat'		=> 'no-repeat',
                                'repeat'		=> 'repeat',
                                'repeat-x'		=> 'repeat-x',
                                'repeat-y'		=> 'repeat-y',
                                'round'		=> 'round',
                                'space'		=> 'space'
                            ),
                            'params' => array(
                                'default' => 'no-repeat',
                            ),
                        ),
                        'rit_header_top_bg_size' => array(
                            'type' => 'select',
                            'label' => __('Background Size', 'ri-ghost'),
                            'priority' => 0,
                            'choices' => array(
                                'default'		=> 'Default',
                                'contain'		=> 'contain',
                                'auto'		=> 'auto',
                                'cover'		=> 'cover',
                                '100%'		=> '100%'
                            ),
                            'params' => array(
                                'default' => 'cover',
                            ),
                        ),
                        'rit_header_top_bg_color' => array(
                            'class' => 'color',
                            'label' => __('Background Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#252525',
                            ),
                        ),
                        'rit_header_top_color' => array(
                            'class' => 'color',
                            'label' => __('Text color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#959595',
                            ),
                        ),
                        'rit_header_top_link_color' => array(
                            'class' => 'color',
                            'label' => __('Link color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#959595',
                            ),
                        ),
                        'rit_header_top_link_hover_color' => array(
                            'class' => 'color',
                            'label' => __('Link hover color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#ff9248',
                            ),
                        )
                    )
                ),

                'rit_new_section_color_header' => array(
                    'title' => __('Color - Header', 'ri-ghost'),
                    'description' => '',
                    'priority' => 8,
                    'panel' => 'color_panel',
                    'settings' => array(
                        'rit_header_background_color' => array(
                            'class' => 'color',
                            'label' => __('Background Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => 'transparent',
                            ),
                        ),
                        'rit_header_page_background_color' => array(
                            'class' => 'color',
                            'label' => __('Inner background color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_header_text_color' => array(
                            'class' => 'color',
                            'label' => __('Text color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#ffffff',
                            ),
                        ),
                        'rit_header_link_color' => array(
                            'class' => 'color',
                            'label' => __('Link color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#ffffff',
                            ),
                        ),
                        'rit_header_link_hover_color' => array(
                            'class' => 'color',
                            'label' => __('Link Hover color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                    )
                ),

                'rit_new_section_color_header_botton' => array(
                    'title' => __('Color - Header Bottom', 'ri-ghost'),
                    'description' => '',
                    'priority' => 9,
                    'panel' => 'color_panel',
                    'settings' => array(
                        'rit_header_botton_bg_color' => array(
                            'class' => 'color',
                            'label' => __('Background Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#252525',
                            ),
                        ),
                    )
                ),

                'rit_new_section_color_navigation' => array(
                    'title' => __('Color - Navigation', 'ri-ghost'),
                    'description' => '',
                    'priority' => 9,
                    'panel' => 'color_panel',
                    'settings' => array(
                        'rit_nav_bg_color' => array(
                            'class' => 'color',
                            'label' => __('Nav Background Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_nav_text_color' => array(
                            'class' => 'color',
                            'label' => __('Nav Text Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_nav_link_color' => array(
                            'class' => 'color',
                            'label' => __('Nav Link Color', 'ri-ghost'),
                            'priority' => 2,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_nav_link_hover_color' => array(
                            'class' => 'color',
                            'label' => __('Nav Link Hover Color', 'ri-ghost'),
                            'priority' => 3,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_nav_sub_bg_color' => array(
                            'class' => 'color',
                            'label' => __('Nav Drop Down Background Color', 'ri-ghost'),
                            'priority' => 4,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_nav_sub_link_color' => array(
                            'class' => 'color',
                            'label' => __('Nav Drop Down Link Color', 'ri-ghost'),
                            'priority' => 5,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_nav_sub_link_hover_color' => array(
                            'class' => 'color',
                            'label' => __('Nav Drop Down Link Hover Color', 'ri-ghost'),
                            'priority' => 6,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                    )
                ),

                'rit_new_section_color_body' => array(
                    'title' => __('Color - Body', 'ri-ghost'),
                    'description' => '',
                    'priority' => 10,
                    'panel' => 'color_panel',
                    'settings' => array(
                        'rit_body_bg_image' => array(
                            'class' => 'image',
                            'label' => __('Body Background Image', 'ri-ghost'),
                            'priority' => 0
                        ),
                        'rit_bg_body_repeat' => array(
                            'type' => 'select',
                            'label' => __('Background Repeat', 'ri-ghost'),
                            'priority' => 0,
                            'choices' => array(
                                'no-repeat'		=> 'no-repeat',
                                'repeat'		=> 'repeat',
                                'repeat-x'		=> 'repeat-x',
                                'repeat-y'		=> 'repeat-y',
                                'round'		=> 'round',
                                'space'		=> 'space'
                            ),
                            'params' => array(
                                'default' => 'no-repeat',
                            ),
                        ),
                        'rit_bg_body_size' => array(
                            'type' => 'select',
                            'label' => __('Background Size', 'ri-ghost'),
                            'priority' => 0,
                            'choices' => array(
                                'default'		=> 'Default',
                                'contain'		=> 'contain',
                                'auto'		=> 'auto',
                                'cover'		=> 'cover',
                                '100%'		=> '100%'
                            ),
                            'params' => array(
                                'default' => 'cover',
                            ),
                        ),
                        'rit_bg_body_attachment' => array(
                            'type' => 'select',
                            'label' => __('Background Attachment', 'ri-ghost'),
                            'priority' => 0,
                            'choices' => array(
                                'default'		=> 'Default',
                                'fixed'		=> 'fixed',
                                'scroll'		=> 'scroll',
                                'local'		=> 'scroll'
                            ),
                            'params' => array(
                                'default' => 'fixed',
                            ),
                        ),
                        'rit_custom_bg_body' => array(
                            'class' => 'color',
                            'label' => __('Body Background Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#ffffff',
                            ),
                        ),
                        'rit_body_text_color' => array(
                            'class' => 'color',
                            'label' => __('Text Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_body_link_color' => array(
                            'class' => 'color',
                            'label' => __('Link Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_body_link_hover_color' => array(
                            'class' => 'color',
                            'label' => __('Link Hover Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_body_h1_color' => array(
                            'class' => 'color',
                            'label' => __('H1 Text Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_body_h2_color' => array(
                            'class' => 'color',
                            'label' => __('H2 Text Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_body_h3_color' => array(
                            'class' => 'color',
                            'label' => __('H3 Text Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_body_h4_color' => array(
                            'class' => 'color',
                            'label' => __('H4 Text Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_body_h5_color' => array(
                            'class' => 'color',
                            'label' => __('H5 Text Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_body_h6_color' => array(
                            'class' => 'color',
                            'label' => __('H6 Text Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        )
                    )
                ),

                'rit_new_section_color_footer' => array(
                    'title' => __('Color - Footer', 'ri-ghost'),
                    'description' => '',
                    'priority' => 11,
                    'panel' => 'color_panel',
                    'settings' => array(
                        'rit_footer_background_color' => array(
                            'class' => 'color',
                            'label' => __('Footer Background Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#ffffff',
                            ),
                        ),
                        'rit_footer_text_color' => array(
                            'class' => 'color',
                            'label' => __('Footer Text Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_footer_title_color' => array(
                            'class' => 'color',
                            'label' => __('Footer Widget Title Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#ffffff',
                            ),
                        ),
                        'rit_footer_link_color' => array(
                            'class' => 'color',
                            'label' => __('Footer Link Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_footer_link_hover_color' => array(
                            'class' => 'color',
                            'label' => __('Footer Link Hover Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_copyright_bg_color' => array(
                            'class' => 'color',
                            'label' => __('Copyright Background Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#ffffff',
                            ),
                        ),
                        'rit_copyright_text_color' => array(
                            'class' => 'color',
                            'label' => __('Copyright Text Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_copyright_link_color' => array(
                            'class' => 'color',
                            'label' => __('Copyright Link Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        ),
                        'rit_copyright_link_hover_color' => array(
                            'class' => 'color',
                            'label' => __('Copyright Link Hover Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#353535',
                            ),
                        )
                    )
                ),

                'rit_new_section_color_woocommerce ' => array(
                    'title' => __('Color - Product', 'ri-ghost'),
                    'description' => '',
                    'priority' => 12,
                    'panel' => 'color_panel',
                    'settings' => array(
                        'rit_label_sale_background_color' => array(
                            'class' => 'color',
                            'label' => __('Label Sale Background Color', 'ri-ghost'),
                            'priority' => 0,
                            'params' => array(
                                'default' => '#ff9933',
                            ),
                        ),
                        'rit_label_sale_color' => array(
                            'class' => 'color',
                            'label' => __('Label Sale Color', 'ri-ghost'),
                            'priority' => 1,
                            'params' => array(
                                'default' => '#ffffff',
                            ),
                        ),
                        'rit_label_new_background_color' => array(
                            'class' => 'color',
                            'label' => __('Label New Background Color', 'ri-ghost'),
                            'priority' => 2,
                            'params' => array(
                                'default' => '#99cc00',
                            ),
                        ),
                        'rit_label_new_color' => array(
                            'class' => 'color',
                            'label' => __('Label New Color', 'ri-ghost'),
                            'priority' => 3,
                            'params' => array(
                                'default' => '#ffffff',
                            ),
                        )
                    )
                )
            );

        }

        public function rit_customizer_script()
        {
            // Register
            wp_enqueue_style('rit-customize-css', RIT_PLUGIN_URL . 'inc/customize/assets/css/customizer.css', array(), RIT_VERSION);
            wp_enqueue_script('rit-customize-js', RIT_PLUGIN_URL . 'inc/customize/assets/js/customizer.js', array('jquery'), RIT_VERSION, true);

            // Localize
            wp_localize_script('rit-customize-js', 'RIT_Customize_Import_Export_l10n', array(
                'emptyImport' => esc_html__('Please choose a file to import.', 'rit-core-language')
            ));

            // Config
            wp_localize_script('rit-customize-js', 'RIT_Customize_Import_Export_Config', array(
                'customizerURL' => admin_url('customize.php'),
                'exportNonce' => wp_create_nonce('rit-exporting')
            ));
        }

        /**
         * @method controls_print_scripts
         */
        public function rit_customizer_controls_print_scripts()
        {
            global $cei_error;

            if ($cei_error) {
                echo '<script> alert("' . esc_js($cei_error) . '"); </script>';
            }
        }

        public function add_customize($customizers) {
            $this->customizers = array_merge($this->customizers, $customizers);
        }

        public function add_panel($panels) {
            $this->panels = array_merge($this->panels, $panels);
        }

        // magic method for active callback function
        public function __call($func, $params){
            if(in_array($func, $this->activeCallbackFunctions)){
                $controlName = str_replace('_active_callback_function', '', $func);
                $customizeControl = $this->getCustomizeControl($controlName);
                if($customizeControl && isset($customizeControl['dependency']) && count($customizeControl['dependency']) > 0){
                    foreach($customizeControl['dependency'] as $dependency => $values){
                        if(is_array($values) &&  count($values) > 0){
                            $result = false;
                            foreach($values as $val){
                                if ($params[0]->manager->get_setting($dependency)->value() == $val){
                                    $result = true;
                                }
                            }
                            return $result;
                        } elseif ( $params[0]->manager->get_setting($dependency)->value() != $values ) {
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        private function getCustomizeControl($name){
            foreach ($this->customizers as $section => $section_params) {
                foreach ($section_params['settings'] as $setting => $params) {
                    if($setting == $name)
                        return $params;
                }
            }
            return false;
        }

        public function rit_register_theme_customizer()
        {
            global $wp_customize;

            foreach ($this->customizers as $section => $section_params) {

                //add section
                $wp_customize->add_section($section, $section_params);
                if (isset($section_params['settings']) && count($section_params['settings']) > 0) {
                    foreach ($section_params['settings'] as $setting => $params) {

                        if(isset($params['dependency']) && count($params['dependency']) > 0){

                            $callbackFunctionName = $setting.'_active_callback_function';

                            $this->activeCallbackFunctions[] =  $callbackFunctionName;

                            $params['active_callback'] = array($this, $callbackFunctionName);

                            unset($params['dependency']);
                        }

                        //add setting
                        $setting_params = array();
                        if (isset($params['params'])) {
                            $setting_params = $params['params'];
                            unset($params['params']);
                        }

                        $settings_callback_default = array(
                            'default' => null,
                            'sanitize_callback' => 'wp_kses_post',
                            'sanitize_js_callback' => null
                        );
                        $setting_params = array_merge( $settings_callback_default,  $setting_params);

                        $wp_customize->add_setting($setting, $setting_params);


                        //Get class control
                        $class = 'WP_Customize_Control';
                        if (isset($params['class']) && !empty($params['class'])) {
                            $class = 'WP_Customize_' . ucfirst($params['class']) . '_Control';
                            unset($params['class']);
                        }

                        //add params section and settings
                        $params['section'] = $section;
                        $params['settings'] = $setting;

                        //add controll
                        $wp_customize->add_control(
                            new $class($wp_customize, $setting, $params)
                        );
                    }
                }
            }

            foreach($this->panels as $key => $panel){
                $wp_customize->add_panel($key, $panel);
            }

            return;
        }

        public function remove_default_customize_section()
        {
            global $wp_customize;
            // Remove Sections
            $wp_customize->remove_section('nav');
            $wp_customize->remove_section('static_front_page');
            $wp_customize->remove_section('colors');
            $wp_customize->remove_section('background_image');
            $wp_customize->remove_section('nav_menus');
            $wp_customize->remove_section('widgets');
        }
    }
}