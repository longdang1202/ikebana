<?php
if (!function_exists('rit_recent_posts')) {
    function rit_recent_posts($atts)
    {
        $atts = shortcode_atts(array(
            'title' => 'Recent Post',
            'columns' => 3,
            'row' => 1,
            'column_smalldes' => 3,
            'column_tablet' => 2,
            'column_mobile' => 1,
            'layout' => '',
            'border_wrap' => 'no',
            'enable_carousel' => 1,
            'cat' => '',
            'post_in' => '',
            'enable_control' => false,
            'enable_pager' => true,
            'number' => 8,
            'limit' => 15,
            'view_more' => false,
            'el_class' => ''
        ), $atts);

        return rit_get_template_part('shortcode', 'recent-posts', array('atts' => $atts));
    }
}
add_shortcode('recent_posts', 'rit_recent_posts');

add_action('vc_before_init', 'rit_recent_posts_integrate_vc');

if (!function_exists('rit_recent_posts_integrate_vc')) {
    function rit_recent_posts_integrate_vc()
    {
        vc_map(array(
            'name' => __('RIT Recent Posts', 'ri-ghost'),
            'base' => 'recent_posts',
            'category' => __('RIT', 'ri-ghost'),
            'icon' => 'rit-recent_posts',
            "params" => array(
                array(
                    "type" => "textfield",
                    "heading" => __("Title", 'ri-ghost'),
                    "param_name" => "title",
                    "value" => "Recent Post",
                    "admin_label" => true
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Layout", 'ri-ghost'),
                    "param_name" => "layout",
                    'std' => 'default',
                    "value" => array(
                        __('default', 'ri-ghost' ) => 'default',
                        __('Style 1', 'ri-ghost' ) => '1',
                        __('Style 2', 'ri-ghost' ) => '2'
                    )
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => __('Border wrap', 'ri-ghost'),
                    'value' => array(
                        __('Yes', 'ri-ghost') => 'yes',
                        __('No', 'ri-ghost') => 'no'
                    ),
                    'param_name' => 'border_wrap',
                    'std' => 'no',
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Enable Carousel", 'ri-ghost'),
                    "param_name" => "enable_carousel",
                    'std' => '3',
                    "value" => array(
                        __('Yes', 'ri-ghost' ) => 1,
                        __('No', 'ri-ghost' ) => 0
                    )
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Columns", 'ri-ghost'),
                    "param_name" => "columns",
                    'std' => '3',
                    "value" => array(
                        __('1', 'ri-ghost' ) => 1,
                        __('2', 'ri-ghost' ) => 2,
                        __('3', 'ri-ghost' ) => 3,
                        __('4', 'ri-ghost' ) => 4
                    )
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => __('Row count', 'ri-ghost'),
                    'value' => array(
                        __('1 Columns', 'ri-ghost') => '1',
                        __('2 Columns', 'ri-ghost') => '2',
                        __('3 Columns', 'ri-ghost') => '3',
                        __('4 Columns', 'ri-ghost') => '4',
                        __('5 Columns', 'ri-ghost') => '5',
                        __('6 Columns', 'ri-ghost') => '6'
                    ),
                    'std' => '1',
                    'param_name' => 'row',
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => __('Column For Small Destop', 'ri-ghost'),
                    'value' => array(
                        __('1', 'ri-ghost' ) => 1,
                        __('2', 'ri-ghost' ) => 2,
                        __('3', 'ri-ghost' ) => 3,
                        __('4', 'ri-ghost' ) => 4
                    ),
                    'std' => '3',
                    'param_name' => 'column_smalldes',
                    'dependency' => Array('element' => 'enable_carousel', 'value' => array('1')),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => __('Column For Tablet', 'ri-ghost'),
                    'value' => array(
                        __('1', 'ri-ghost' ) => 1,
                        __('2', 'ri-ghost' ) => 2,
                        __('3', 'ri-ghost' ) => 3,
                        __('4', 'ri-ghost' ) => 4
                    ),
                    'std' => '2',
                    'param_name' => 'column_tablet',
                    'dependency' => Array('element' => 'enable_carousel', 'value' => array('1')),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => __('Column For Mobile', 'ri-ghost'),
                    'value' => array(
                        __('1', 'ri-ghost' ) => 1,
                        __('2', 'ri-ghost' ) => 2,
                        __('3', 'ri-ghost' ) => 3,
                        __('4', 'ri-ghost' ) => 4
                    ),
                    'std' => '1',
                    'param_name' => 'column_mobile',
                    'dependency' => Array('element' => 'enable_carousel', 'value' => array('1')),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => __('Enable Control', 'ri-ghost'),
                    'value' => array(
                        __('Yes', 'ri-ghost' ) => 'yes',
                        __('no', 'ri-ghost' ) => 'no'
                    ),
                    'std' => 'false',
                    'param_name' => 'enable_control',
                    'dependency' => Array('element' => 'enable_carousel', 'value' => array('1')),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => __('Enable Pager', 'ri-ghost'),
                    'value' => array(
                        __('Yes', 'ri-ghost' ) => 'yes',
                        __('no', 'ri-ghost' ) => 'No'
                    ),
                    'std' => 'true',
                    'param_name' => 'enable_pager',
                    'dependency' => Array('element' => 'enable_carousel', 'value' => array('1')),
                ),
                array(
                    "type" => "rit_post_categories",
                    "heading" => __("Category IDs", 'ri-ghost'),
                    "description" => __("Select category", 'ri-ghost'),
                    "param_name" => "cat",
                    "admin_label" => true
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Post IDs", 'ri-ghost'),
                    "description" => __("comma separated list of post ids", 'ri-ghost'),
                    "param_name" => "post_in"
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Posts Count", 'ri-ghost'),
                    "param_name" => "number",
                    "value" => '8'
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Excerpt Length", 'ri-ghost'),
                    "param_name" => "limit",
                    "value" => '15'
                ),
                array(
                    'type' => 'checkbox',
                    'heading' => __("Show View More", 'ri-ghost'),
                    'param_name' => 'view_more',
                    'std' => 'no',
                    'value' => array(__('Yes', 'js_composer') => 'yes')
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __( 'Extra class name', 'ri-ghost' ),
                    'param_name' => 'el_class',
                    'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'ri-ghost' )
                )
            )
        ));
    }
}
