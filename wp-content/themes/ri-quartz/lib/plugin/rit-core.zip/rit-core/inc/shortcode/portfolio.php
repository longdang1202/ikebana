<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */


if (!function_exists('rit_shortcode_portfolio')) {
    function rit_shortcode_portfolio($atts)
    {
        $atts = shortcode_atts(array(
            'title' => 'Portfolios',
            'title_divider' => '',
            'title_size' => '',
            'title_position' => '',
            'portfolio_layout' => 'grid',
            'portfolio_style' => '',
            'columns' => '3',
            'cat' => '',
            'post_in' => '',
            'number' => 8,
            'view_more' => false,
            'pagination' => 'standard',
            'el_class' => ''
        ), $atts);

        $layout_type = ($atts['portfolio_layout'] != '') ? $atts['portfolio_layout'] : 'large';

        return rit_get_template_part('shortcode', 'portfolio-' . $layout_type, array('atts' => $atts));
    }
}
add_shortcode('portfolio', 'rit_shortcode_portfolio');

add_action('vc_before_init', 'rit_portfolio_integrate_vc');

if (!function_exists('rit_portfolio_integrate_vc')) {
    function rit_portfolio_integrate_vc()
    {
        vc_map( array(
            'name' => esc_html__('RIT Portfolios', 'rit-core'),
            'base' => 'portfolio',
            'category' => esc_html__('RIT', 'rit-core'),
            'icon' => 'rit-portfolios',
            "params" => array(
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Title", 'rit-core'),
                    "param_name" => "title",
                    "admin_label" => true,
                    'value' => 'Portfolios',
                    'description' => esc_html__('Enter text used as shortcode title (Note: located above content element)', 'rit-core'),
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Title Divider", 'ri-ghost'),
                    "param_name" => "title_divider",
                    'std' => '0',
                    "description" => __("Show Only has title", 'ri-ghost'),
                    "value" => array(
                        __('Yes', 'ri-ghost' ) => 1,
                        __('No', 'ri-ghost' ) => 0
                    )
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Title Size", 'ri-ghost'),
                    "param_name" => "title_size",
                    'std' => 'default',
                    "description" => __("Font Size Of Title", 'ri-ghost'),
                    "value" => array(
                        __('Default', 'ri-ghost' ) => 'default',
                        __('Size 2x', 'ri-ghost' ) => 'font-2x',
                        __('Size 3x', 'ri-ghost' ) => 'font-3x',
                        __('Size 4x', 'ri-ghost' ) => 'font-4x',
                        __('Size 5x', 'ri-ghost' ) => 'font-5x'
                    )
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Title Position", 'ri-ghost'),
                    "param_name" => "title_position",
                    'std' => 'center',
                    "description" => __("Show Only has title", 'ri-ghost'),
                    "value" => array(
                        __('Left', 'ri-ghost' ) => 'left',
                        __('Center', 'ri-ghost' ) => 'center'
                    )
                ),
                array(
                    "type" => "dropdown",
                    "heading" => esc_html__("Portfolio Layout", 'rit-core'),
                    "param_name" => "portfolio_layout",
                    'std' => 'timeline',
                    "value" => array(
                        esc_html__('Showcase', 'rit-core' ) => 'showcase',
                        esc_html__('Grid', 'rit-core' ) => 'grid',
                        esc_html__('Full', 'rit-core' ) => 'full',
                        esc_html__('Masonry', 'rit-core' ) => 'masonry'
                    ),
                    "admin_label" => true,
                    'description' => esc_html__('Select layout type for display portfolio', 'rit-core'),
                ),
                array(
                    "type" => "dropdown",
                    "heading" => esc_html__("Portfolio Item Style", 'rit-core'),
                    "param_name" => "portfolio_style",
                    'std' => 'timeline',
                    "value" => array(
                        esc_html__('Default', 'rit-core' ) => 'default',
                        esc_html__('Style 1', 'rit-core' ) => '1'
                    ),
                    "admin_label" => true,
                    'description' => esc_html__('Select Style for item display portfolio', 'rit-core'),
                    'dependency' => Array('element' => 'portfolio_layout', 'value' => array( 'showcase','masonry')),
                ),
                array(
                    "type" => "dropdown",
                    "heading" => esc_html__("Columns", 'rit-core'),
                    "param_name" => "columns",
                    'dependency' => Array('element' => 'portfolio_layout', 'value' => array( 'grid','medium','showcase')),
                    'std' => '3',
                    "value" => array(
                        esc_html__('2', 'rit-core' ) => '2',
                        esc_html__('3', 'rit-core' ) => '3',
                        esc_html__('4', 'rit-core' ) => '4',
                        esc_html__('6', 'rit-core' ) => '6'
                    ),
                    'description' => esc_html__('Display portfolio with the number of column', 'rit-core'),
                ),
                array(
                    "type" => "rit_portfolio_categories",
                    "heading" => esc_html__("Category IDs", 'rit-core'),
                    "description" => esc_html__("Select category", 'rit-core'),
                    "param_name" => "cat",
                    "admin_label" => true,
                    'description' => esc_html__('Select category which you want to get portfolio in', 'rit-core'),
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Portfolio IDs", 'rit-core'),
                    "description" => esc_html__("comma separated list of portfolio ids", 'rit-core'),
                    "param_name" => "post_in"
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Portfolios number", 'rit-core'),
                    "param_name" => "number",
                    "value" => '8',
                    'description' => esc_html__('Number of portfolios showing', 'rit-core'),
                ),
                array(
                    'type' => 'checkbox',
                    'heading' => esc_html__("Show View More", 'rit-core'),
                    'param_name' => 'view_more',
                    'std' => 'no',
                    'value' => array( esc_html__( 'Yes', 'rit-core' ) => 'yes' ),
                    'dependency' => Array(
                        'element' => 'portfolio_layout',
                        'value' => array( 'grid','full')
                    ),
                ),
                array(
                    "type" => "dropdown",
                    "heading" => esc_html__("Pagination", 'rit-core'),
                    "param_name" => "pagination",
                    'std' => 'standard',
                    "value" => array(
                        esc_html__('Standard', 'rit-core' ) => 'standard',
                        esc_html__('Infinite Scroll', 'rit-core' ) => 'infinite-scroll',
                        esc_html__('Ajax Load more', 'rit-core' ) => 'ajax',
                        esc_html__('None', 'rit-core' ) => 'none',
                    ),
                    'dependency' => Array(
                        'element' => 'portfolio_layout',
                        'value' => array( 'grid','full')
                    ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'rit-core' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'rit-core' )
                )
            )
        ) );
    }
}
