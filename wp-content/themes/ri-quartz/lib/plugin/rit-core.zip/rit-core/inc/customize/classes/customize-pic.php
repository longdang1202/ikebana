<?php
/**
* Multiple select customize control class.
*/
class WP_Customize_Pic_Control extends WP_Customize_Control {

/**
* The type of customize control being rendered.
*/
public $type = 'pic';

/**
* Displays the multiple select on the customize screen.
*/
public function render_content() {
if ( empty( $this->choices ) )
return;
?>
<label>
    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
    <div class="pic-select <?php echo esc_attr($this->type); ?>">
            <?php foreach ( $this->choices as $value => $label ) { ?>
                <?php $selected =  $this->value(); ?>
                <label <?php echo ($value == $selected) ? 'class="selected"' : ''; ?>>
                    <input type="radio" value="<?php echo esc_attr( $value ); ?>" name="rit_pic_select" data-id="<?php echo $this->id; ?>" id="pic_<?php echo $value; ?>">
                    <?php if($label == 'none') { ?>
                    <img src="<?php echo RIT_PLUGIN_URL. 'rit-core/customize/assets/images/loader/none.jpg'; ?>" alt="picture" />
                    <?php } else { ?>
                    <img src="<?php echo esc_attr( $label ); ?>" alt="picture" />
                    <?php } ?>
                </label>
            <?php } ?>
    </div>
</label>
<?php }
}