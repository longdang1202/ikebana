<?php
        $_id = ri_quartz_random_ID();
        $type = $atts['type'];
        $icon_fontawesome = $atts['icon_fontawesome'];
        $icon_openiconic = $atts['icon_openiconic'];
        $icon_typicons = $atts['icon_typicons'];
        $icon_entypo = $atts['icon_entypo'];
        $icon_linecons = $atts['icon_linecons'];
        $title = $atts['title'];
        $description = $atts['description'];
        $style = $atts['style'];
        $border = $atts['border'];
        $link = $atts['link'];
        $el_class = $atts['el_class'];
        $class = 'style-' . $style . ' ' . $el_class;
        if($type != ''){
            $icon_selected = 'icon_' . $type;
            $icon_select = $atts[$icon_selected];
        }
        if($type == ''){
            $icon_select = $icon_fontawesome;
        }
        vc_icon_element_fonts_enqueue( $type );

?>
<div id="rit-icon-box<?php echo esc_attr($_id); ?>" class="rit-icon-box <?php echo esc_attr($class); ?>">
    <div class="rit-icon-box-inner">
        <div class="rit-icon-box-item clearfix">
            <?php if($style != 'icon-title') { ?>
            <span class="icon" <?php echo ($atts['icon_top'] != '' ? 'style="padding-top: '. esc_attr($atts['icon_top']) .'px"' : ''); ?>><i class="<?php echo esc_attr($icon_select); ?>"></i></span>
            <?php } ?>
            <div class="icon-box-content">
                <?php if($title != '') { ?>
                <h6>
                    <?php if($style == 'icon-title') { ?>
                        <span class="icon" <?php echo ($atts['bg_color'] != '' ? 'style="background-color:'. esc_attr($atts['bg_color']) .'"' : ''); ?>><i class="<?php echo esc_attr($icon_select); ?>"></i></span>
                    <?php } ?>
                    <?php if($link != '') { ?>
                    <a href="<?php echo esc_url($link); ?>"><?php echo wp_kses($title, array('br', array())); ?></a>
                    <?php } else { ?>
                        <span <?php echo ($atts['title_top'] != '' ? 'style="padding-top: '. esc_attr($atts['title_top']) .'px"' : ''); ?>><?php echo wp_kses($title, array('br', array())); ?></span>
                    <?php } ?>
                </h6>
                <?php } ?>
                <?php if($description != '') { ?>
                <p><?php echo wp_kses($description, array('a' => array('href' => array(), 'title' => array()), 'br' => array(), 'em' => array(), 'strong' => array(), 'p' => array(),)) ?></p>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php if($border == 'yes') { ?>
        <span class="icon-box-line"></span>
    <?php } ?>
</div>
<?php if($style == 'horizontal-2' && $atts['custom_color'] != '') { ?>
    <style type="text/css">
        #rit-icon-box<?php echo esc_attr($_id); ?> .rit-icon-box-inner{
            border-color: <?php echo esc_attr($atts['custom_color']); ?>;
        }
        #rit-icon-box<?php echo esc_attr($_id); ?> .rit-icon-box-inner:hover{
            background-color: <?php echo esc_attr($atts['custom_color']); ?>;
        }
        #rit-icon-box<?php echo esc_attr($_id); ?> .rit-icon-box-inner .icon i,
        #rit-icon-box<?php echo esc_attr($_id); ?> .rit-icon-box-inner h6 a{
            color: <?php echo esc_attr($atts['custom_color']); ?>;
        }
    </style>
<?php } ?>
<?php if($style == 'horizontal-3' && $atts['custom_color'] != '') { ?>
    <style type="text/css">
        #rit-icon-box<?php echo esc_attr($_id); ?> .rit-icon-box-inner .icon{
            border-color: <?php echo esc_attr($atts['custom_color']); ?>;
        }
        #rit-icon-box<?php echo esc_attr($_id); ?> .rit-icon-box-inner .icon i,
        #rit-icon-box<?php echo esc_attr($_id); ?> .rit-icon-box-inner h6 a,
        #rit-icon-box<?php echo esc_attr($_id); ?> .rit-icon-box-inner p{
            color: <?php echo esc_attr($atts['custom_color']); ?>;
        }
    </style>
<?php } ?>
