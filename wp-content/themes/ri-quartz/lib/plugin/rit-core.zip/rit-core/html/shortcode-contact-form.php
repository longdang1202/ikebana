<?php
    $title = $atts['title'];
    $shortcode = $atts['shortcode'];
    $style = $atts['style'];
    $el_class = $atts['el_class'];
    $contact_shortcode = explode('-', $shortcode);
?>
<div class="rit-element-builder rit-element-contact <?php echo 'style-' . esc_attr($style); ?>">
    <div class="rit-element-contact-inner">
        <?php if($style == 'suspensory') { ?>
            <span class="contact-line"></span>
            <span class="contact-circle"></span>
        <?php } ?>
        <?php if($title) {
            echo '<h3 class="rit-element-title rit-title-contact">'. esc_html($title) .'</h3>';
        } ?>
        <div class="rit-contact-content">
            <?php echo do_shortcode('[contact-form-7 id="'.$contact_shortcode[0].'" title="'.$contact_shortcode[1].'"]'); ?>
        </div>
    </div>
</div>
