<?php

$args = array(
    'post_type' => 'post',
    'posts_per_page' => ($atts['number'] > 0) ? $atts['number'] : get_option('posts_per_page')
);
if ($atts['cat'] != '')
    $args['category_name'] = $atts['cat'];
if ($atts['post_in'] != '')
    $args['post_in'] = $atts['post_in'];
$args['paged'] = (get_query_var('paged')) ? get_query_var('paged') : 1;
$the_query = new WP_Query($args);
//class for option columns
$class = $data_number = $class_wrap ='';
switch ($atts['columns']) {
    case '1':
        $class .= "col-xs-12";
        break;
    case '2':
        $class .= "col-xs-12 col-sm-6 col-md-6";
        break;
    case '3':
        $class .= "col-xs-12 col-sm-6 col-md-4";
        break;
    case '4':
        $class .= "col-xs-12 col-sm-6 col-md-3";
        break;
}
if ($atts['enable_carousel']) {
    $class = 'carousel-item col-sm-12 col-md-12';
    $class_wrap = 'rit-owl-carousel row';
    $data_number = 'data-number=' . esc_attr($atts['columns']) . ' '
                    . 'data-smalldes=' . esc_attr($atts['column_smalldes']) . ' '
                    . 'data-tablet=' . esc_attr($atts['column_tablet']) . ' '
                    . 'data-mobile=' . esc_attr($atts['column_mobile']) . ' '
                    . 'data-control='. esc_attr($atts['enable_control']) .' '
                    . 'data-pager='. esc_attr($atts['enable_pager']) .'';
}
$class_wrap .= ' style-' . $atts['layout'];
$i = 0;
?>
<div
    class="rit-element-builder <?php echo 'rit-element-'. ($atts['border_wrap'] == 'yes' ? 'has' : 'no') .'-border'; ?> content-grid <?php echo esc_attr($atts['el_class']); ?> rit-element-recent">
    <?php if ($atts['title']) { ?>
        <div class="rit-element-title rit-title-recent">
            <span><?php echo esc_html($atts['title']); ?></span>
        </div>
    <?php } ?>
    <div class="rit-element-content <?php echo ($atts['enable_carousel']) ? 'rit-element-slider' : ''; ?>">
    <div class="<?php echo 'rit-recent-posts' . ' ' . esc_attr($class_wrap); ?>" <?php echo esc_attr($data_number); ?>>

        <?php if (!$atts['enable_carousel']) { ?>
        <div class="row">
            <?php } ?>
            <?php if ($the_query->have_posts()):
                while ($the_query->have_posts()): $the_query->the_post();
                    $i++;
                    ?>
                    <?php
                    if($atts['row'] > 1 && $i % $atts['row'] == 1){
                        echo '<div class="post-showcase">';
                    }
                    ?>
                    <article class="rit-news-item <?php echo esc_attr($class); ?>" id="post-<?php the_ID(); ?>">
                        <div class="rit-news-item-inner clearfix">
                        <?php if(has_post_thumbnail()) : ?>
                            <?php if(!get_theme_mod('sp_post_thumb')) : ?>
                                <div class="post-image<?php echo (is_single()) ? ' single-image' : ''; ?>">
                                    <a href="<?php echo esc_url(get_permalink()); ?>"><?php the_post_thumbnail('full-thumb'); ?></a>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <div class="rit-news-content">
                            <?php if(get_theme_mod('rit_enable_page_heading', '1')) { ?>
                                <header class="entry-header">
                                    <?php
                                    if ( is_single() ) :
                                        the_title( '<h1 class="entry-title">', '</h1>' );
                                    else :
                                        the_title( sprintf( '<h2 class="entry-title al-left"><a href="%s" rel="'. esc_html__('bookmark', 'ri-quartz') .'">', esc_url( get_permalink() ) ), '</a></h2>' );
                                    endif;
                                    ?>
                                </header><!-- .entry-header -->
                            <?php } ?>
                            <div class="entry-content al-left">
                                <?php
                                echo ri_quartz_content($atts['limit']);
                                ?>
                            </div><!-- .entry-content -->
                            <div class="article-meta clearfix">
                                <?php if($atts['layout'] == 'default') { ?>
                                <span class="post-date pull-left"><i class="fa-calendar fa"></i><?php echo esc_html(get_the_date('F jS, Y')); ?></span>
                                <?php if($atts['view_more']) { ?>
                                <span class="readmore pull-right"><a href="<?php echo esc_url(the_permalink()); ?>"><i class="fa fa-angle-right"></i><?php echo esc_html(__('Readmore', 'ri-quartz')); ?></a></span>
                                <?php } ?>
                                <?php } elseif($atts['layout'] == '2') { ?>
                                <div class="article-meta-inner">
                                    <span class="post-date pull-left"><?php echo esc_html(get_the_date('F d, Y')); ?></span>
                                    <?php if($atts['view_more']) { ?>
                                        <span class="readmore pull-right"><a href="<?php echo esc_url(the_permalink()); ?>"><?php echo esc_html(__('Readmore', 'ri-quartz')); ?></a></span>
                                    <?php } ?>
                                </div>
                                <?php } else { ?>
                                <?php if($atts['view_more']) { ?>
                                <span class="readmore pull-left"><a href="<?php echo esc_url(the_permalink()); ?>"><?php echo esc_html(__('Read more', 'ri-quartz')); ?><i class="fa-arrow-right fa"></i></a></span>
                                <?php } ?>
                                <?php } ?>
                            </div>
                        </div>
                        </div>
                    </article>
                    <?php
                    if($atts['row'] > 1 && $i % $atts['row'] == 0){
                        echo '</div>';
                    }
                    ?>
                    <?php if ($i % $atts['columns'] == 0): ?>
                    <?php endif; ?>
                <?php endwhile;
                //end paging
            endif;
            wp_reset_postdata(); ?>
            <?php if (!$atts['enable_carousel']) { ?>
        </div>
    <?php } ?>
    </div>
    </div>
</div>
