<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */
if(!isset($_POST['show'])){
    echo '<input name="rit-filter-page-baseurl" type="hidden" value="'.rit_current_url().'">';
}
global $post;
?>
<div class="rit-products-wrap">
    <?php if (isset($atts['title'])&& $atts['title']!='') { ?>
        <h3 class="rit-element-title rit-title-product"><?php echo esc_html($atts['title']); ?></h3>
    <?php } ?>
    <?php

    $animation = $atts['show_filter'];

    if($atts['show_filter']){
        //list category
        if($atts['filter_categories'] != ''){
            $product_categories = explode(',', $atts['filter_categories'] );
            echo '<div class="rit-ajax-load rit-list-product-category"><ul>';
            echo '<li><a data-type="rit-reset-filter" href="'.rit_current_url().'">'.esc_html__('All', 'rit-core').'</a></li>';
            foreach ($product_categories as $product_cat_slug)
            {
                $product_cat = get_term_by( 'slug', $product_cat_slug, 'product_cat' );
                $selected = '';
                if(isset($atts['wc_attr']['product_cat'] ) && $atts['wc_attr']['product_cat'] == $product_cat->slug ){
                    $selected = 'rit-selected';
                }
                echo '<li><a class="'. esc_attr($selected) .'"
                            data-type="product_cat" data-value="'.esc_attr($product_cat->slug).'"
                            href="' . esc_url(get_term_link( $product_cat->slug, 'product_cat' )) . '"
                            title="' . esc_attr($product_cat->name) . '">' . esc_html($product_cat->name) . '</a></li>';

            }

            echo '</ul></div>';
        }
        //end of list category

        echo '<div class="rit-ajax-load rit-filter-button-toggle pull-right"><span onclick="filter_click();" class="rit-button rit-button-dark" id="rit-filter-button-toggle">'. esc_html(__('Filter', 'rit-core')) .'</span></div><div class="clearfix"></div>';

        $open_class = '';
        if(isset($_POST['filter_area']) && $_POST['filter_area'] == 'show' ){
            $open_class = 'open';
        }
        echo '<div class="rit-filter-wrap-toggle clearfix '. esc_attr($open_class) .'">';

        //list featured filter
        $filter_arrs = array(
            esc_html__('All', 'rit-core') => 'all',
            esc_html__('Featured product', 'rit-core') => 'featured',
            esc_html__('Onsale product', 'rit-core') => 'onsale',
            esc_html__('Best Selling', 'rit-core') => 'best-selling',
            esc_html__('Latest product', 'rit-core') => 'latest',
            esc_html__('Top rate product', 'rit-core') => 'toprate ',
            esc_html__('Sort by price: low to high', 'rit-core') => 'price',
            esc_html__('Sort by price: high to low', 'rit-core') => 'price-desc',
        );

        echo '<div class="rit-ajax-load rit-list-filter"><h5>'. esc_html(__('Sort By', 'rit-core')) .'</h5><ul>';
        foreach ($filter_arrs as $key => $value) {
            $selected = '';
            if (isset($atts['show']) && $atts['show'] == $value) {
                $selected = 'rit-selected';
            }
            echo '<li><a  class="' . esc_attr($selected) . '"
                    data-type="show"
                    data-value="' . esc_attr($value) . '"
                    href="" title="' . esc_attr($key) . '">' . esc_html($key) . '</a></li>';

        }
        echo '</ul></div>';
        //end list tags

        //list product_attributes
        if($atts['filter_attributes'] != ''){
            $product_attribute_taxonomies = explode(',', $atts['filter_attributes'] );


            if(count($product_attribute_taxonomies) > 0){
                foreach ($product_attribute_taxonomies as $product_attribute_taxonomie_slug) {

                    global $wpdb;

                    $attribute_taxonomies = $wpdb->get_results( "SELECT * FROM " . $wpdb->prefix . "woocommerce_attribute_taxonomies where attribute_name='".$product_attribute_taxonomie_slug."'" );

                    if(isset($attribute_taxonomies[0])){
                        $product_attribute_taxonomie = $attribute_taxonomies[0];
                        //$product_terms = get_terms( 'pa_'.$product_attribute_taxonomie->attribute_name, 'hide_empty=0' );
                        $product_terms = get_terms( 'pa_'.$product_attribute_taxonomie->attribute_name);

                        if(count($product_terms) > 0){
                            echo '<div class="rit-ajax-load rit-product-attribute-filter"><h5>'.esc_html($product_attribute_taxonomie->attribute_label).'</h5>';
                            echo '<ul>';
                            foreach ($product_terms as $product_term) {

                                $selected = '';
                                $removed = '';
                                if(isset($atts['wc_attr']['tax_query']) && count($atts['wc_attr']['tax_query']) > 0){
                                    foreach ($atts['wc_attr']['tax_query'] as $tax_query) {
                                        if($tax_query['taxonomy'] == $product_term->taxonomy && $tax_query['terms'] == $product_term->slug ){
                                            $selected = 'rit-selected';
                                            $removed = '<span data-type="rit-remove-attr" class="rit-remove-attribute pull-left"><i class="icon_close"></i></span>';
                                        }
                                    }

                                }
                                echo '<li>' . wp_kses(__($removed, 'rit-core'),
                                        array(
                                            'span' => array(
                                                'data-type' => array(),
                                                'class' => array()
                                            ),
                                            'i' => array(
                                                'class' => array()
                                            )
                                        )) . '<a href="#" class="rit-product-attribute '. esc_attr($selected) .'"
                                            data-type="product_attribute"
                                            data-attribute_value="'.esc_attr($product_term->slug).'"
                                            data-value="'.esc_attr($product_term->taxonomy).'"
                                            title="'.esc_attr($product_term->name).'">' . esc_html($product_term->name) . '</a></li>';
                            }
                            echo '</ul></div>';
                        }
                    }
                }
            }
        }
        //end list product_attributes

        //list tags
        if($atts['filter_tags'] != ''){
            $product_tags = explode(',', $atts['filter_tags'] );
            echo '<div class="rit-ajax-load rit-list-product-tag"><h5>'. esc_html(__('Tags', 'rit-core')) .'</h5><ul>';
            foreach ($product_tags as $product_tag_slug)
            {
                $selected = '';
                $product_tag = get_term_by( 'slug',$product_tag_slug, 'product_tag' );
                if(isset($atts['wc_attr']['product_tag']) && $atts['wc_attr']['product_tag'] == $product_tag->slug){
                    $selected = 'rit-selected';
                }
                echo '<li><a class="'. esc_attr($selected) .'"
                            data-type="product_tag"
                            data-value="'.esc_attr($product_tag->slug).'"
                            title="' . esc_attr($product_tag->name) . '">' . esc_html($product_tag->name) . '</a></li>';

            }

            echo '</ul></div>';
        }
        //end if list tag

        //reset filter
        echo '<div class="rit-ajax-load rit-reset-filter"><a class="pull-right rit-button rit-button-gray" data-type="rit-reset-filter" href="'.rit_current_url().'">'.esc_html__('Reset', 'rit-core').'</a></div>';
        //end reset filter

        echo '</div>';

        //shortcode agurgument
        if(!isset($_POST['show'])){
            $init_atts = $atts;
            unset($init_atts['wc_attr']);
            echo '<script type="text/javascript">var data = jQuery.parseJSON(\''.json_encode($init_atts).'\')</script>';
        }else{
            echo '<script type="text/javascript">var data = jQuery.parseJSON(\''.json_encode($_POST).'\')</script>';
        }
        ?>

        <script type="text/javascript">
            var filter_wrap = jQuery('.rit-filter-wrap-toggle'),
                button_filter = jQuery('#rit-filter-button-toggle'),
                filter_item = jQuery(filter_wrap).find('.rit-ajax-load');
            function filter_click(){
                if(filter_wrap.hasClass('open')){
                    filter_wrap.slideUp().removeClass('open');
                    data['filter_area'] = 'hide';
                } else {
                    filter_wrap.slideDown().addClass('open');
                    data['filter_area'] = 'show';
                }
            }
            function filter_column(){
                jQuery(filter_item).css('width', 100 / filter_item.length + '%');
            }
            filter_column();

            jQuery(document).ready(function($){

                "use strict";

                function rit_ajax_filter(){
                    if(typeof filter_links == 'undefined'){

                        var filter_links = $('.rit-ajax-load a, .rit-remove-attribute');

                        filter_links.click(function(e) {
                            e.preventDefault();
                            $('.products-filter .rit-loader-wrap').fadeIn();
                            filter_column();
                            var $this = $(this);
                            var link  = $this.attr('href');
                            var title = $this.attr('title');

                            data['action'] = 'rit_ajax_product_filter';


                            if($this.hasClass('rit-product-attribute')){
                                if(typeof data['product_attribute'] == 'object'){
                                    data['product_attribute'].push($this.data('value'));

                                    data['attribute_value'].push( $this.data('attribute_value'));
                                }else{
                                    data['product_attribute'] = [];
                                    data['product_attribute'].push($this.data('value'));

                                    data['attribute_value'] = [];
                                    data['attribute_value'].push( $this.data('attribute_value'));
                                }

                            }else {

                                data[$this.data('type')] = $this.data('value');

                            }

                            data['paged'] = 1;

                            if($this.data('type') == 'product_cat'){
                                data['product_attribute'] = [];
                                data['attribute_value'] = [];
                                data['product_tag'] = '';
                                data['show'] = '';
                            }

                            if($this.data('type') == 'rit-reset-filter'){
                                data['product_attribute'] = [];
                                data['attribute_value'] = [];
                                data['product_tag'] = '';
                                data['product_cat'] = '<?php echo $atts['filter_categories']; ?>';
                                data['show'] = '';
                            }

                            if($this.data('type') == 'rit-remove-attr'){
                                var product_attribute = $this.next().data('value');
                                var attribute_value = $this.next().data('attribute_value');

                                /*
                                 var index1 = data['product_attribute'].indexOf(product_attribute);
                                 if (index1 > -1) {
                                 data['product_attribute'].splice(index1, 1);
                                 }

                                 for (var key in data['product_attribute']) {
                                 console.log(key);
                                 console.log(product_attribute);
                                 console.log(data['product_attribute'][key]);
                                 if (data['product_attribute'][key] == product_attribute) {
                                 data['product_attribute'].splice(key, 1);
                                 break;
                                 }
                                 }
                                 */

                                var index = data['attribute_value'].indexOf(attribute_value);
                                if (index > -1) {
                                    data['attribute_value'].splice(index, 1);
                                    data['product_attribute'].splice(index, 1);
                                }
                            }

                            $.ajax({
                                url: '<?php echo  admin_url( 'admin-ajax.php')?>',
                                data: data,
                                type: 'POST',
                            }).success(function(response){
                                $('.rit-products-wrap').html($(response).html());
                                if(filter_wrap.hasClass('open')){
                                    $(filter_wrap).css('display', 'block');
                                }
                                $('.products-filter .rit-loader-wrap').fadeOut();
                                if(max_num_pages == data['paged']){
                                    $('.rit_ajax_load_more_button').hide();
                                }else{
                                    $('.rit_ajax_load_more_button').show();
                                }
                            })
                        })
                    }
                }

                rit_ajax_filter();
            }(jQuery));

        </script>
        <?php
    }

    $owlCarousel = '';
    $class = ''; ?>
    <div class="clearfix"></div>
    <div class="rit-wrapper-products-shortcode products-filter woocommerce">
        <div class="rit-loader-wrap">
            <span class="icon-spin"><span class="icon-clone"></span></span>
        </div>
        <?php


        if ($atts['products_type'] == 'products_list') {
            $class .= 'list-layout';
        } else {
            $class .= 'row grid-layout';
        }
        if ($atts['products_type'] == 'products_carousel') {
            add_action('wp_footer', 'products_carousel_script');
            $owlCarousel = 'owlCarousel';
            $class .= ' products-carousel-list';
            $item;
            switch ($atts['column']) {
                case '1':
                    $item = 1;
                    break;
                case '2':
                    $item = 2;
                    break;
                case '3':
                    $item = 3;
                    break;
                case '4':
                    $item = 4;
                    break;
                case '5':
                    $item = 5;
                    break;
                case '6':
                    $item = 6;
                    break;
                default:
                    $item = 4;
                    break;
            }
            ?>
            <script type="text/javascript">
                jQuery(document).ready(function () {

                    "use strict";

                    jQuery(".products-carousel-list").owlCarousel({
                        // Most important owl features
                        items: '<?php echo esc_js($item) ?>',
                        itemsCustom: false,
                        itemsTabletSmall: false,
                        singleItem: false,
                        itemsScaleUp: false,
                        // Navigation
                        pagination: false,
                        navigation: true,
                        navigationText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
                        rewindNav: true,
                        scrollPerPage: false
                    });
                });
            </script>
            <?php
        }
        if(isset($atts['element_custom_class']))
            $class .= ' ' . $atts['element_custom_class'];

        $product_query = new WP_Query(apply_filters('woocommerce_shortcode_products_query', $atts['wc_attr']));

        $product_query->query($atts['wc_attr']);

        remove_filter( 'posts_clauses', array( 'WC_Shortcodes', 'order_by_rating_post_clauses' ) );
        ?>
        <div class="products-filter-list <?php echo esc_attr($owlCarousel) ?>">
            <ul class="products clearfix <?php echo esc_attr($class) ?>">
                <?php while ($product_query->have_posts()) {
                    $product_query->the_post();
                    global $product;
                    ?>
                    <?php
                    if ($atts['products_type'] == 'products_list') {
                        wc_get_template_part( 'content', 'product-list' );
                    } else {
                        global $product_column, $product_filter;
                        $product_column = $atts['column'];
                        $product_filter = $atts['show_filter'];
                        wc_get_template_part( 'content', 'product-vc' );
                    }
                    ?>
                    <?php
                }
                ?>
            </ul>
        </div>
        <?php if($atts['show_loadmore']):?>
            <script type="text/javascript">
                var max_num_pages = <?php echo esc_js($product_query->max_num_pages);?>;
            </script>
        <?php endif; ?>
    </div>
    <?php
    if(!isset($_POST['ajax'])):
        if($atts['show_loadmore'] && $product_query->max_num_pages > $atts['wc_attr']['paged']):
            echo '<div class="clearfix product-loadmore al-center"><a href="#" class="rit-button rit-button-dark rit_ajax_load_more_button">'.esc_html__('Load more', 'rit-core').'</a></div>';

            ?>
            <script type="text/javascript">
                jQuery(document).ready(function ($) {

                    "use strict";

                    if(typeof filter_links == 'undefined'){

                        var rit_ajax_load_more_button = $('.rit_ajax_load_more_button');

                        rit_ajax_load_more_button.click(function(e){

                            e.preventDefault();

                            jQuery('.products-filter .rit-loader-wrap').fadeIn();

                            if(data['paged'] < max_num_pages){
                                data['action'] = 'rit_ajax_product_filter';
                                data['paged'] = parseInt(data['paged'])+parseInt(1);

                                $.ajax({
                                    url: '<?php echo  admin_url( 'admin-ajax.php')?>',
                                    data: data,
                                    type: 'POST',
                                }).success(function(response){

                                    $('.products').append($(response).find('.products').html());

                                    jQuery('.products-filter .rit-loader-wrap').fadeOut();

                                    if(max_num_pages == data['paged']){
                                        $('.rit_ajax_load_more_button').hide();
                                    }else{
                                        $('.rit_ajax_load_more_button').show();
                                    }
                                })
                            }

                        });
                    }
                });


            </script>
        <?php endif;?>
    <?php endif;?>
    <?php
    wp_reset_postdata();
    ?>
</div>