<?php
    $id = ri_quartz_random_ID();
    $cat = $atts['products_category'];
    $cat_list = explode(',', $cat);
?>
<div id="rit-list-category-<?php echo esc_attr($id); ?>" class="clearfix rit-list-category<?php echo ($atts['el_class'] != '' ? esc_attr($atts['el_class']) : ''); ?>">
    <?php if($atts['title']) { ?>
        <div class="rit-list-cat-title">
            <h4><?php echo esc_html($atts['title']); ?></h4>
        </div>
    <?php } ?>
    <?php if($cat != '') { ?>
        <div class="rit-list">
            <ul>
                <?php foreach($cat_list as $list) {
                    $product_cat = get_term_by( 'slug', $list, 'product_cat' );
                    ?>
                    <li><a href="<?php echo esc_url(get_term_link( $product_cat->slug, 'product_cat' )) ?>"><?php echo esc_attr($product_cat->name); ?></a></li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>
</div>
<?php if($atts['bg_title']) { ?>
    <style type="text/css">
        #rit-list-category-<?php echo esc_attr($id); ?> .rit-list-cat-title h4{
            background-color: <?php echo esc_attr($atts['bg_title']); ?>;
        }
        #rit-list-category-<?php echo esc_attr($id); ?> .rit-list-cat-title h4:after{
            border-color: transparent transparent transparent <?php echo esc_attr($atts['bg_title']); ?>;
        }
    </style>
<?php }
