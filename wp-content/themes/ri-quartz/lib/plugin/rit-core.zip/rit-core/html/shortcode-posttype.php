<?php

// Variable
$enable_carousel = $atts['enable_carousel'];
$title = $atts['title'];
$testimonials_cat = $atts['testimonials_cat'];
$el_class = $atts['el_class'];

// Parallax Query
$args = array(
    'post_type' => 'posttype'
);

// Testimonial Query
$args_testimonials = array(
    'post_type' => 'testimonial'
);

if ($atts['testimonials_cat']) {
    $cat = explode(',', $testimonials_cat);
    $args_testimonials['tax_query'] = array(
        array(
            'taxonomy' => 'testimonial_category',
            'field' => 'slug',
            'terms' => $cat,
        )
    );
}

$the_query = new WP_Query($args);
$the_query_testimonial = new WP_Query($args_testimonials);
$class = '';
$i = 0;
?>
<div
    class="rit-element-builder rit-element-posttype ">
        <?php if ($atts['element_title']) { ?>
            <div class="rit-element-title rit-title-posttype">
                <span><?php echo esc_html($atts['element_title']); ?></span>
            </div>
        <?php } ?>
        <div class="rit-posttype-wrap rit-element-slider posttype-layout-<?php echo esc_attr($atts['testimonials_layout']); ?>">
            <!-- Parallax Testimonial Post type -->
            <div data-control="yes" data-pager="no" data-number="<?php echo ($atts['column']) ? esc_attr($atts['column']) : '1'; ?>" data-smalldes="1" data-tablet="1" data-mobile="1" class="posttype-list rit-owl-carousel">
            <?php if ($the_query_testimonial->have_posts()):
                while ($the_query_testimonial->have_posts()): $the_query_testimonial->the_post();
                    $i++;
                    $avatar = get_post_meta(get_the_ID(), 'rit_testimonial_avatar', true);
                    $testimonial = get_post_meta(get_the_ID(), 'rit_testimonial', true);
                    $name = get_post_meta(get_the_ID(), 'rit_testimonial_name', true);
                    $position = get_post_meta(get_the_ID(), 'rit_testimonial_position', true);
                    $rit_testimonial_fb = get_post_meta(get_the_ID(), 'rit_testimonial_fb', true);
                    $rit_testimonial_tt = get_post_meta(get_the_ID(), 'rit_testimonial_tt', true);
                    $rit_testimonial_gg = get_post_meta(get_the_ID(), 'rit_testimonial_gg', true);
                    $rit_testimonial_li = get_post_meta(get_the_ID(), 'rit_testimonial_li', true);
                    $avatar_url = wp_get_attachment_url($avatar);
                    ?>
                    <div class="posttype-item testimonial-item">
                        <div class="testimonial-item-boxed">
                            <div class="custom-avatar al-center">
                                <?php if($avatar) { ?>
                                <img src="<?php echo esc_url($avatar_url); ?>" alt="Avatar" />
                                <?php } ?>
                                <?php if($name != '') { ?>
                                    <span class="name"><?php echo esc_html($name); ?></span>
                                <?php } ?>
                                <?php if($position != '') { ?>
                                    <span class="position"><?php echo esc_html($position); ?></span>
                                <?php } ?>
                                <?php if($atts['enable_social']) { ?>
                                <div class="rit-social no-name about-social">
                                    <ul>
                                        <?php if($rit_testimonial_fb != '') { ?>
                                        <li class="facebook"><a target="_blank" href="<?php echo esc_url($rit_testimonial_fb); ?>"><i class="fa fa-facebook-square"></i></a></li>
                                        <?php } ?>
                                        <?php if($rit_testimonial_tt != '') { ?>
                                        <li class="twitter"><a target="_blank" href="<?php echo esc_url($rit_testimonial_tt); ?>"><i class="fa fa-twitter-square"></i></a></li>
                                        <?php } ?>
                                        <?php if($rit_testimonial_gg != '') { ?>
                                        <li class="googleplus"><a target="_blank" href="<?php echo esc_url($rit_testimonial_gg); ?>"><i class="fa fa-google-plus-square"></i></a></li>
                                        <?php } ?>
                                        <?php if($rit_testimonial_li != '') { ?>
                                        <li class="linkedin"><a target="_blank" href="<?php echo esc_url($rit_testimonial_li); ?>"><i class="fa fa-linkedin-square"></i></a></li>
                                        <?php } ?>
                                    </ul>
                                </div>
                                <?php } ?>
                            </div>
                            <div class="testimonial-boxed-content">
                                <?php if($testimonial != '') { ?>
                                <p class="custom-info mb0">
                                    <?php if($testimonial != '') { ?>
                                        <?php echo wp_kses($testimonial,array('br' => array())); ?>
                                    <?php } ?>
                                </p>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile;
                //paging
                if (function_exists("pagination")) :
                    pagination($args['posts_per_page']);
                endif;
                //end paging
            endif;
            wp_reset_postdata();
            ?>
            </div>
        </div>
</div>