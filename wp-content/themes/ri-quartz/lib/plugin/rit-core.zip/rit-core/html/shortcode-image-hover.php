<?php

$thumbnail_library = $atts['thumbnail_library'];
$image = $atts['image'];
$title = $atts['title'];
$title_color = $atts['title_color'];
$video_url = $atts['video_url'];
$sub_title = $atts['sub_title'];
$sub_title_color = $atts['sub_title_color'];
$link = $atts['link'];
$text_link = $atts['text_link'];
$style = $atts['style'];
$description = $atts['description'];
$position = $atts['position'];
$el_class = $atts['el_class'];
$_image = explode(',', $image);
$image_isset = get_attached_file($image);

$class = 'style-' . $style . ' ' . $el_class;

?>
<div class="position-<?php echo ($position) ? $position : 'default'; ?> rit-element-builder rit-element-image-hover <?php echo ($atts['border'] ? 'has-border' : ''); ?> <?php echo ($class) ? $class : ''; ?>">
    <div class="image-hover-inner">

        <!-- Image Left Style, Style For Style Full Width -->
        <?php if($image && $image_isset) { ?>
            <a href="<?php echo esc_url($link); ?>">
                <?php
                    echo '<span class="image-overlay"></span>';
                ?>
                <?php echo wp_get_attachment_image($_image[0], 'full'); ?>
            </a>
            <?php if($thumbnail_library == 'video' && $video_url != ''){ ?>
                <?php $video_type = ri_quartz_detech_video($video_url); ?>
                <a class="rit-veno-item" data-gall="gall-video" data-type="<?php echo esc_attr($video_type); ?>" href="<?php echo esc_url($video_url); ?>"><span class="veno-icon"></span></a>
            <?php } ?>
        <?php } else {
            echo '<img src="'. esc_url(get_template_directory_uri()) . '/images/placeholder.jpg" alt="Place Holder" />';
        } ?>
        <!-- Content General -->
        <?php if($title || $sub_title || $text_link) { ?>
            <div class="image-content-hover">
                <div class="content">
                    <?php
                    $html = '';
                    if($title != '' && $style != '4'){
                        $html .= '<h'. esc_html($atts['title_tag']) .' class="title" '. ($title_color ? 'style="color: '. esc_attr($title_color) .'"' : '') .'>'. wp_kses($title, array('br'=>array())) .'</h'. esc_html($atts['title_tag']) .'>';
                    }
                    if($sub_title != '' && $style != '4'){
                        $html .= '<p class="sub-title" '. ($sub_title_color ? 'style="color: '. esc_attr($sub_title_color) .'"' : '') .'>'. wp_kses($sub_title, array('h1'=>array(),'h2'=>array(),'p'=>array())) .'</p>';
                    }
                    if($description && $style == '1'){
                        $html .= $description;
                    }
                    if($text_link){
                        $html .= '<a class="rit-button rit-button-'. esc_attr($atts['link_style']) .'" href="' . $link . '" '. ($atts['new_tab'] == true ? 'target="_blank"' : '') .'>' . $text_link . '</a>';
                    }
                    echo $html;
                    ?>
                </div>
            </div>
        <?php } ?>
    </div>
    <?php
    if($title != '' && $style == '4'){
        echo '<h'. esc_html($atts['title_tag']) .' class="title al-center" '. ($title_color ? 'style="color: '. esc_attr($title_color) .'"' : '') .'>'. wp_kses($title, array('br'=>array())) .'</h'. esc_html($atts['title_tag']) .'>';
    }
    if($sub_title != '' && $style == '4'){
        echo '<p class="sub-title al-center" '. ($sub_title_color ? 'style="color: '. esc_attr($sub_title_color) .'"' : '') .'>'. wp_kses($sub_title, array('h1'=>array(),'h2'=>array(),'p'=>array())) .'</p>';
    }
    ?>
</div>


