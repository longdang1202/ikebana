<?php

// Variable
$enable_carousel = $atts['enable_carousel'];
$title = $atts['title'];
$partners_cat = $atts['partner_cat'];
$el_class = $atts['el_class'];

// Parallax Query
$args = array(
    'post_type' => 'partner'
);

// Testimonial Query
$args_partners = array(
    'post_type' => 'partner'
);

if ($atts['partner_cat']) {
    $cat = explode(',', $partners_cat);
    $args_partners['tax_query'] = array(
        array(
            'taxonomy' => 'partner_category',
            'field' => 'slug',
            'terms' => $cat,
        )
    );
}

$the_query = new WP_Query($args);
$the_query_partner = new WP_Query($args_partners);
$class = '';
$i = 0;
?>
<div
    class="rit-element-builder rit-element-partner control-<?php echo ($atts['control'] == 1 ? 'show' : 'hover'); ?>">
        <?php if ($atts['title']) { ?>
            <div class="rit-element-title rit-title-partner">
                <span><?php echo esc_html($atts['title']); ?></span>
            </div>
        <?php } ?>
        <div class="rit-partner-wrap rit-element-slider">
            <!-- Parallax Testimonial Post type -->
            <div data-control="yes" data-pager="no" data-number="<?php echo ($atts['column']) ? esc_attr($atts['column']) : '1'; ?>" data-smalldes="4" data-tablet="3" data-mobile="1" class="partner-list rit-owl-carousel">
            <?php if ($the_query_partner->have_posts()):
                while ($the_query_partner->have_posts()): $the_query_partner->the_post();
                    $i++;
                    $rit_link_partner = get_post_meta(get_the_ID(), 'rit_link_partner', true);
                    ?>
                    <div class="partner-item <?php echo ($atts['border'] ? 'item-border' : ''); ?> <?php echo ($atts['scale'] ? 'item-scale' : ''); ?>">
                        <figure>
                            <?php echo ($atts['border'] ? '<span class="border-scale"></span>' : ''); ?>
                            <a href="<?php echo ($rit_link_partner ? esc_url($rit_link_partner) : '#'); ?>">
                                <?php
                                $attachments = get_attached_file( get_post_thumbnail_id(get_the_ID()) );
                                if(has_post_thumbnail() && $attachments) { ?>
                                    <?php the_post_thumbnail(); ?>
                                <?php } else { ?>
                                    <?php if(get_theme_mod('rit_enable_place_holder', '1') == 1) { ?>
                                        <img class="img-placeholder" src="<?php echo esc_url(get_template_directory_uri() . '/images/placeholder.jpg'); ?>" alt="<?php echo esc_html(__('Image Placeholder', 'ri-charitable')); ?>" />
                                    <?php } ?>
                                <?php } ?>
                            </a>
                        </figure>
                    </div>
                <?php endwhile;
                //paging
                if (function_exists("pagination")) :
                    pagination($args['posts_per_page']);
                endif;
                //end paging
            endif;
            wp_reset_postdata();
            ?>
            </div>
        </div>
</div>