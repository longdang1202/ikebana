<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     0.1
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */

$args = array(
    'post_type' => 'portfolio',
    'posts_per_page' => ($atts['number'] > 0) ? $atts['number'] : get_option('posts_per_page')
);
$cat = explode(',', $atts['cat']);
if ($atts['cat']) {
    $args['tax_query'] = array(
        array(
            'taxonomy' => 'portfolio_category',
            'field' => 'slug',
            'terms' => $cat,
        )
    );
}

if ($atts['post_in'])
    $args['post__in'] = explode(',', $atts['post_in']);
$args['paged'] = (rit_get_query_var('paged')) ? rit_get_query_var('paged') : 1;
$the_query = new WP_Query($args);?>
<script>
    jQuery(window).load(function () {
        jQuery('#wrapper-rit-item-masonry').isotope({
            // options
            itemSelector: '.rit-item-masonry',
            layoutMode: 'fitRows'
        });
        jQuery('#rit-masonry-filter li').click(function() {
            var filterValue = jQuery(this).data('filter');
            jQuery('#wrapper-rit-item-masonry').isotope({ filter: filterValue });
        });
    });

</script>
<div class="rit-element rit-element-portfolio rit-portfolio-showcase">
    <?php if ($atts['title']) { ?>
        <h3 class="rit-element-title rit-title-portfolio rit-heading font-2x grayblack lettet-3 al-center"><?php echo esc_html($atts['title']); ?></h3>
    <?php } ?>
<?php

$class_column = 'masonry-' . esc_attr($atts['columns']) . '-column';

//Begin control nav masonry

?>
<?php if($atts['cat'] != '') { ?>
<ul id="rit-masonry-filter" class="rit-filter <?php echo ($atts['title_position'] == 'left') ? 'pull-right' : ''; ?>">
    <li class="active" data-id="all" data-filter="*"><span><?php echo esc_html__('All', 'ri-quartz') ?></span></li>
    <?php foreach ($cat as $term) : ?>
        <li data-filter=".<?php echo esc_attr($term); ?>" data-id="<?php echo esc_attr($term); ?>"><span><?php echo esc_attr($term); ?></span></li>
    <?php endforeach; ?>
</ul>
<?php } ?>
<div id="wrapper-rit-item-masonry">
    <?php if ($the_query->have_posts()) :
        while ($the_query->have_posts()) : $the_query->the_post();
            //get list catslug
            $catslug = '';
            $termspost = get_the_terms( get_the_ID(), 'portfolio_category');
            if ($termspost && !is_wp_error($termspost)) :
                foreach ($termspost as $term) :
                    $catslug .= $term->slug . ' ';
                endforeach;
            endif;
            ?>
            <div class="rit-item-masonry all <?php echo esc_attr($catslug . $class_column) ?>">
                <?php echo rit_get_template_part('post-format/portfolio', 'default', array('atts' => $atts)) ?>
                <div class="rit-portfolio-content">
                    <h4 class="rit-cat"><?php echo wp_kses(get_the_term_list(get_the_ID(), 'portfolio_category', ' ', ' - ', ' '), array('a'=>array('class'=>array(),'href'=>array(),'rel'=>array(),'title'=>array()))); ?></h4>
                    <h3 class="rit-title"><a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a></h3>
                </div>
            </div>
            <?php
        endwhile;
    endif;
    wp_reset_postdata(); ?>
</div><!--End wrapper-rit-item-masonry-->
</div>