<?php
$owlCarousel = $class_col = $class = $query_tab = '';
if ($atts['products_type'] == 'products_carousel') {
    $owlCarousel = 'rit-element-slider';
    $class = 'products-carousel-list rit-owl-carousel';
}
switch ($atts['column']) {
    case 1:
        $class_col .= 'col-sm-12 col-md-12';
        break;
    case 2:
        $class_col .= 'col-sm-6 col-md-6';
        break;
    case 3:
        $class_col .= 'col-sm-4 col-md-4';
        break;
    case 4:
        $class_col .= 'col-sm-3 col-md-3';
        break;
    case 6:
        $class_col .= 'col-sm-2 col-md-2';
        break;
}
// array query shop
$args = array(
    'post_type' => 'product',
    'post_status' => 'publish',
    'product_cat' => $atts['products_category'],
    'ignore_sticky_posts'   => 1,
    'posts_per_page' => $atts['posts_per_page'],
    'orderby'        => 'ESC'
);
// array query best seller
$meta_query = WC()->query->get_meta_query();
$args_best_seller = array(
    'post_type' => 'product',
    'post_status' => 'publish',
    'product_cat' => $atts['products_category'],
    'ignore_sticky_posts' => 1,
    'posts_per_page' => $atts['posts_per_page'],
    'orderby' => 'meta_value_num',
    'meta_query' => $meta_query,
    'meta_key' => 'total_sales',
    'el_class' => ''
);
// array feature product
$args_feature = array(
    'post_type' => 'product',
    'post_status' => 'publish',
    'product_cat' => $atts['products_category'],
    'ignore_sticky_posts'   => 1,
    'meta_key' => '_featured',
    'meta_value' => 'yes',
    'posts_per_page' => $atts['posts_per_page']
);
// array on sales product
$args_onsale = array(
    'post_type' => 'product',
    'post_status' => 'publish',
    'product_cat' => $atts['products_category'],
    'ignore_sticky_posts'   => 1,
    'meta_query'     => array(
        'relation' => 'OR',
        array( // Simple products type
            'key'           => '_sale_price',
            'value'         => 0,
            'compare'       => '>',
            'type'          => 'numeric'
        ),
        array( // Variable products type
            'key'           => '_min_variation_sale_price',
            'value'         => 0,
            'compare'       => '>',
            'type'          => 'numeric'
        )
    ),
    'posts_per_page' => $atts['posts_per_page']
);
if($atts['show'] == 'onsale'){
    $query_shop = new WP_Query($args_onsale);
} elseif ($atts['show'] == 'featured'){
    $query_shop = new WP_Query($args_feature);
} elseif ($atts['show'] == 'best-selling'){
    $query_shop = new WP_Query($args_best_seller);
} else {
    $query_shop = new WP_Query($args);
}

global $product_column, $enable_carousel, $product_style, $countdown, $products_layout;
$countdown = $atts['countdown'];
$product_column = $atts['column'];
$enable_carousel = $atts['products_type'];
$products_layout = $atts['products_layout'];
$product_style = $atts['products_style'];
$tab = explode(',', $atts['products_category']);
$tab_mode = explode(',', $atts['products_mode']);
$enable_mode = '';
if($products_layout == 'layout-4' && $atts['products_mode'] != ''){
    $enable_mode = '1';
}
?>

<div class="rit-element-builder rit-element-recent <?php echo ($atts['thumb_image'] != '' ? 'has-image' : 'no-image'); ?> <?php echo esc_attr($atts['products_layout']); ?> <?php echo 'rit-element-'. ($atts['border_wrap'] == 'yes' ? 'has' : 'no') .'-border'; ?> <?php echo ($atts['enable_tab']) ? 'rit-element-tabs' : 'rit-element-no-tabs'; ?>">
    <?php if ($atts['title'] || $atts['enable_tab']) { ?>
        <div class="rit-element-title rit-title-product clearfix">
            <?php if($atts['title']) { ?>
                <span <?php echo ($atts['title_color'] != '' ? 'style="color: '. $atts['title_color'] .'"' : ''); ?>><?php echo esc_html($atts['title']); ?></span>
            <?php } if($atts['enable_tab']) { ?>
                <div class="rit-tab-title">
                    <ul>
                        <?php
                        if($enable_mode == 1){
                            $_i = 0;
                            foreach ($tab_mode as $mode) {
                                echo '<li class="tab-title-item"><a '. ($_i == 0 ? 'class="active"' : '') .' href="#" data-content="' . esc_attr($mode) . '">';
                                if($mode == 'new'){
                                    echo esc_html__('New Arrivals', 'rit-core');
                                } elseif($mode == 'best_seller') {
                                    echo esc_html__('Best Seller', 'rit-core');
                                } elseif($mode == 'feature'){
                                    echo esc_html__('Feature', 'rit-core');
                                } elseif($mode == 'sale'){
                                    echo esc_html__('On Sales', 'rit-core');
                                }
                                echo '</a></li>';
                                $_i++;
                            }
                        } else {
                            foreach ($tab as $tab_item) {
                                $product_cat = get_term_by( 'slug', $tab_item, 'product_cat' );
                                echo '<li class="tab-title-item"><a href="#" data-content="' . esc_attr($tab_item) . '">' . esc_html($product_cat->name) . '</a></li>';
                            }
                        }
                        ?>
                    </ul>
                </div>
            <?php } ?>
        </div>
    <?php } ?>
    <?php if($atts['thumb_image'] != '') { ?>
    <div class="row">
        <div class="col-sm-4 col-md-4 pr0 xs-pr-15">
            <div class="element-thumbnail">
                <?php if($atts['thumb_image'] && get_attached_file($atts['thumb_image'])) { ?>
                <?php if($atts['thumb_link']) {
                    $link = vc_build_link($atts['thumb_link']);
                    echo '<a href="'. esc_url($link['url']) .'" title="'. esc_html($link['title']) .'"><img src="'. esc_url(wp_get_attachment_url($atts['thumb_image'])) .'" alt="'. esc_html__('Thumbnail', 'ri-quartz') .'" /></a>';
                } else { ?>
                    <img src="<?php echo esc_url(wp_get_attachment_url($atts['thumb_image'])); ?>" alt="<?php echo esc_html__('Thumbnail', 'ri-quartz'); ?>" />
                <?php } ?>
                <?php } else {
                    echo '<img src="'. esc_url(get_template_directory_uri()) . '/images/placeholder.jpg" alt="Place Holder" />';
                } ?>
                <div class="element-thumnail-content">
                    <?php if($atts['thumb_title'] != '') { ?>
                        <h3><?php echo esc_html($atts['thumb_title']); ?><?php if($atts['thumb_price'] != '') { ?> <span><?php echo esc_html($atts['thumb_price']); ?></span><?php } ?></h3>
                    <?php } ?>
                    <?php if($atts['thumb_des']) {
                        echo '<p>'. esc_html($atts['thumb_des']) .'</p>';
                    } ?>
                    <?php if($atts['thumb_link']) {
                        $link = vc_build_link($atts['thumb_link']);
                        echo '<a class="rit-button rit-button-gray-light-radius" href="'. esc_url($link['url']) .'" title="'. esc_html($link['title']) .'">'. esc_html($link['title']) .'</a>';
                    } ?>
                </div>
            </div>

        </div><div class="col-sm-8 col-md-8 pl0">
            <?php } ?>
            <?php if ($atts['enable_tab'] == 1) { ?>
            <div class="rit-tab-content">
                <?php } ?>
                <?php if ($atts['enable_tab'] == 1) { ?>
                    <?php
                    if($enable_mode == 1){
                        $i = 0;
                        foreach ($tab_mode as $mode) { ?>
                            <div class="rit-tab-content-item <?php echo ($i == 0) ? 'active' : ''; ?>" id="<?php echo esc_attr($mode); ?>">
                                <div class="products_shortcode_wrap woocommerce <?php echo esc_attr($atts['el_class']) . esc_attr($owlCarousel); ?>">
                                    <ul class="products row <?php echo esc_attr($class); ?>"
                                        data-control="yes"
                                        data-pager="no"
                                        data-number="<?php echo esc_attr($atts['column']); ?>"
                                        data-smalldes="<?php echo esc_attr($atts['column_smalldes']); ?>"
                                        data-tablet="<?php echo esc_attr($atts['column_tablet']); ?>"
                                        data-mobile="<?php echo esc_attr($atts['column_mobile']); ?>">
                                        <?php
                                        $args_tab = $args;
                                        if($mode == 'best_seller'){
                                            $args_tab = $args_best_seller;
                                        } elseif($mode == 'feature'){
                                            $args_tab = $args_feature;
                                        } elseif($mode == 'sale'){
                                            $args_tab = $args_onsale;
                                        }
                                        $query_tab = new WP_Query($args_tab);
                                        while ($query_tab->have_posts()) {
                                            $query_tab->the_post();
                                            global $product;
                                            wc_get_template_part('content', 'product-vc');
                                        } ?>
                                        <?php wp_reset_postdata(); ?>
                                    </ul>
                                </div>
                            </div>
                            <?php $i++; }
                    } else {
                        $i = 0;
                        if($products_layout == 'layout-5'){
                            echo '<div class="row"><div class="col-sm-8 col-md-8 pr0"><div class="rit-tab-new"><div class="rit-tab-title-inner"><h4 class="mt0 mb0">'. esc_html__('new arrival', 'rit-core') .'</h4></div>';
                        }
                        foreach ($tab as $tab_item) { ?>
                            <div class="rit-tab-content-item <?php echo ($i == 0) ? 'active' : ''; ?>" id="<?php echo esc_attr($tab_item); ?>">
                                <div class="products_shortcode_wrap woocommerce <?php echo esc_attr($atts['el_class']) . esc_attr($owlCarousel); ?>">
                                    <ul class="products row <?php echo esc_attr($class); ?>"
                                        data-control="yes"
                                        data-pager="no"
                                        data-number="<?php echo esc_attr($atts['column']); ?>"
                                        data-smalldes="<?php echo esc_attr($atts['column_smalldes']); ?>"
                                        data-tablet="<?php echo esc_attr($atts['column_tablet']); ?>"
                                        data-mobile="<?php echo esc_attr($atts['column_mobile']); ?>">
                                        <?php
                                        $args_tab = array(
                                            'post_type' => 'product',
                                            'post_status' => 'publish',
                                            'product_cat' => $tab_item,
                                            'ignore_sticky_posts'   => 1,
                                            'posts_per_page' => $atts['posts_per_page'],
                                            'orderby'        => 'ESC'
                                        );
                                        $query_tab = new WP_Query($args_tab);
                                        while ($query_tab->have_posts()) {
                                            $query_tab->the_post();
                                            global $product;
                                            wc_get_template_part('content', 'product-vc');
                                        } ?>
                                        <?php wp_reset_postdata(); ?>
                                    </ul>
                                </div>
                            </div>
                            <?php $i++; }
                        if($products_layout == 'layout-5'){
                            echo '</div></div><div class="col-sm-4 col-md-4 pl0"><div class="rit-tab-sale"><div class="rit-tab-title-inner"><h4 class="mt0 mb0">'. esc_html__('hot sale', 'rit-core') .'</h4></div>';
                            ?>
                            <div class="rit-tab-content-item-second">
                                <div class="products_shortcode_wrap woocommerce <?php echo esc_attr($atts['el_class']) . esc_attr($owlCarousel); ?>">
                                    <ul class="products row <?php echo esc_attr($class); ?>"
                                        data-control="yes"
                                        data-pager="no"
                                        data-number="1"
                                        data-smalldes="<?php echo esc_attr($atts['column_smalldes']); ?>"
                                        data-tablet="<?php echo esc_attr($atts['column_tablet']); ?>"
                                        data-mobile="<?php echo esc_attr($atts['column_mobile']); ?>">
                                        <?php
                                        $args_tab_sale = $args_onsale;
                                        $query_tab = new WP_Query($args_tab_sale);
                                        $i_s = 0;
                                        while ($query_tab->have_posts()) {
                                            $query_tab->the_post();
                                            global $product;
                                            $i_s++;
                                            if($enable_carousel == 'products_carousel'){
                                                if($i_s % 3 == 1){
                                                    echo '<li class="product-showcase ml0"><ul class="ml0">';
                                                }
                                            }
                                            wc_get_template_part('content', 'product-vc');
                                            if($enable_carousel == 'products_carousel'){
                                                if($i_s % 3 == 0){
                                                    echo '</ul></li>';
                                                }
                                            }
                                        } ?>
                                        <?php wp_reset_postdata(); ?>
                                    </ul>
                                </div>
                            </div>
                        <?php } if($products_layout == 'layout-5'){
                            echo '</div></div></div>';
                        }
                    }
                } else { ?>
                    <div
                        class="products_shortcode_wrap woocommerce <?php echo esc_attr($atts['el_class']) . esc_attr($owlCarousel); ?>">
                        <ul class="products row <?php echo esc_attr($class); ?>"
                            data-control="yes"
                            data-pager="no"
                            data-number="<?php echo esc_attr($atts['column']); ?>"
                            data-smalldes="<?php echo esc_attr($atts['column_smalldes']); ?>"
                            data-tablet="<?php echo esc_attr($atts['column_tablet']); ?>"
                            data-mobile="<?php echo esc_attr($atts['column_mobile']); ?>">
                            <?php
                            $i = 0;
                            while ($query_shop->have_posts()) {
                                $i++;
                                $query_shop->the_post();
                                global $product;
                                if($enable_carousel == 'products_carousel'){
                                    if($atts['row'] > 1 && $i % $atts['row'] == 1){
                                        echo '<li class="product-showcase ml0"><ul class="ml0">';
                                    }
                                }
                                wc_get_template_part('content', 'product-vc');
                                if($enable_carousel == 'products_carousel'){
                                    if($atts['row'] > 1 && $i % $atts['row'] == 0){
                                        echo '</ul></li>';
                                    }
                                }
                            } ?>
                            <?php wp_reset_postdata(); ?>
                        </ul>
                    </div>
                <?php } ?>
                <?php if ($atts['enable_tab']) { ?>
            </div>
            <?php if($atts['thumb_image'] != '') { ?>
        </div>
    </div>
<?php } ?>
<?php } ?>
</div>