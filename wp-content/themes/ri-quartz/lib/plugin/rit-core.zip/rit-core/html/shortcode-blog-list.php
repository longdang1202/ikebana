<?php
$args = array(
    'post_type' => 'post',
    'posts_per_page' => ($atts['number'] > 0) ? $atts['number'] : get_option('posts_per_page')
);
if ($atts['cat'] != '')
    $args['category_name'] = $atts['cat'];

if ($atts['post_in'] != '')
    $args['post__in'] = explode(',', $atts['post_in']);
$args['paged'] = (get_query_var('paged')) ? get_query_var('paged') : 1;
$the_query = new WP_Query($args);
?>
<div class="rit-list-layout">
    <?php
    if ($the_query->have_posts()) :
        while ($the_query->have_posts()) : $the_query->the_post();
            ?>
            <article class="rit-news-item" id="post-<?php the_ID(); ?>">
                <div class="row">
                    <div class="col-sm-6 col-md-6 pr0">
                        <?php if(has_post_format('gallery')) : ?>

                            <?php $images = get_post_meta( get_the_ID(), '_format_gallery_images', true ); ?>

                            <?php if($images) : ?>
                                <div class="post-image<?php echo (is_single()) ? ' single-image' : ''; ?>">
                                    <ul class="bxslider">
                                        <?php foreach($images as $image) : ?>

                                            <?php $the_image = wp_get_attachment_image_src( $image, 'full-thumb' ); ?>
                                            <?php $the_caption = get_post_field('post_excerpt', $image); ?>
                                            <li><img src="<?php echo esc_url($the_image[0]); ?>" <?php if($the_caption) : ?>title="<?php esc_attr($the_caption); ?>"<?php endif; ?> /></li>

                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                        <?php elseif(has_post_format('video')) : ?>

                            <div class="post-image<?php echo (is_single()) ? ' single-video' : ''; ?>">
                                <?php $sp_video = get_post_meta( get_the_ID(), '_format_video_embed', true ); ?>
                                <?php if(wp_oembed_get( $sp_video )) : ?>
                                    <?php echo wp_oembed_get($sp_video); ?>
                                <?php else : ?>
                                    <?php echo esc_url($sp_video); ?>
                                <?php endif; ?>
                            </div>

                        <?php elseif(has_post_format('audio')) : ?>

                            <div class="post-image audio<?php echo (is_single()) ? ' single-audio' : ''; ?>">
                                <?php $sp_audio = get_post_meta( get_the_ID(), '_format_audio_embed', true ); ?>
                                <?php if(wp_oembed_get( $sp_audio )) : ?>
                                    <?php echo wp_oembed_get($sp_audio); ?>
                                <?php else : ?>
                                    <?php echo esc_url($sp_audio); ?>
                                <?php endif; ?>
                            </div>

                        <?php else : ?>

                            <?php if(has_post_thumbnail()) : ?>
                                <?php if(!get_theme_mod('sp_post_thumb')) : ?>
                                    <div class="post-image<?php echo (is_single()) ? ' single-image' : ''; ?>">
                                        <a href="<?php echo esc_url(get_permalink()); ?>"><?php the_post_thumbnail('full-thumb'); ?></a>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                        <?php endif; ?>
                    </div>
                    <div class="col-sm-6 col-md-6 pl0">
                        <div class="rit-news-info">
                            <h4 class="title-news"><a href="<?php esc_url(the_permalink()); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>
                            <span class="info-author"><?php echo esc_html(__('By', 'ri-quartz')); ?> <a class="author-link" href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>" rel="author"><?php echo wp_kses(get_the_author(),array('a'=>array('href'=>array(),'title'=>array(),'class'=>array(),'rel'=>array()))); ?></a></span>
                            <span class="separate">|</span>
                            <span class="info-date"><?php echo esc_html(get_the_date('F j, Y')); ?></span>
                            <span class="separate">|</span>
                            <span class="info-comment"><a href="<?php echo esc_url(the_permalink()); ?>#comments"><?php comments_number('0 Comment', '1 Comment', '% Comments'); ?></a></span>
                            <span class="separate">|</span>
                            <span class="info-cat"><?php echo wp_kses(get_the_category_list(','), array('a'=>array('href'=>array(),'title'=>array()))); ?></span>
                            <div class="description al-left"><?php echo ri_quartz_content($atts['excerpt']); ?></div>
                            <?php if($atts['view_more']) { ?>
                                <a class="readmore rit-button rit-button-gray-radius rit-button-medium" href="<?php esc_url(the_permalink()); ?>"><?php echo esc_html(__('Read More', 'ri-quartz')); ?><i class="fa fa-arrow-right"></i></a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </article>
            <?php
        endwhile;
        if (function_exists("rit_pagination")) :
            rit_pagination(3, $the_query);
        endif;
    endif;?>
    <?php wp_reset_postdata(); ?>
</div>