<?php
/*
Plugin Name: RiverTheme Core (shared on wplocker.com)
Plugin URI: http://rivertheme.com
Description: This is not just a plugin, it is a package with many tools a website needed.
Author: RIT
Version: 2.0.3
Author URI: http://khangvu.me/
*/

//Define global variable
require_once('rit-config.php');

require_once('inc/helpers/rit.php');
require_once('inc/helpers/vc.php');
require_once('inc/helpers/wc.php');

//Theme customize
require_once('inc/customize/customize.php');

// Widget
require_once('inc/widgets/widget-recent-post.php');
require_once('inc/widgets/widget-recent-scroller.php');
require_once('inc/widgets/widget-about.php');
require_once('inc/widgets/widget-banner-image.php');
//require_once('inc/widgets/widget-dribbble.php');
//require_once('inc/widgets/widget-facebook.php');
//require_once('inc/widgets/widget-flickr.php');
//require_once('inc/widgets/widget-social-icons.php');
//require_once('inc/widgets/widget-testimonial.php');
//require_once('inc/widgets/widget-twitter.php');
//require_once('inc/widgets/widget-tab.php');

// Meta Box
require_once('inc/meta-boxes/meta-boxes.php');

// Post format
require_once('inc/post-format/post-format.php');

//Custom post type
//require_once 'inc/post-types/portfolio.php';
require_once 'inc/post-types/testimonial.php';
//require_once 'inc/post-types/posttype.php';
//require_once 'inc/post-types/menu.php';
//require_once 'inc/post-types/events.php';
require_once 'inc/post-types/member.php';
require_once 'inc/post-types/partner.php';

//Shortcode
require_once('inc/shortcode/product.php');
//require_once('inc/shortcode/product-filter.php');
require_once('inc/shortcode/shortcode.php');
//require_once('inc/shortcode/portfolio.php');
require_once('inc/shortcode/blog.php');
require_once('inc/shortcode/list-category.php');
require_once('inc/shortcode/recent-posts.php');
require_once('inc/shortcode/image-hover.php');
require_once('inc/shortcode/posttype.php');
require_once('inc/shortcode/icon-box.php');
require_once('inc/shortcode/team-member.php');
require_once('inc/shortcode/divider.php');
require_once('inc/shortcode/partner.php');
require_once('inc/shortcode/vertical-menu.php');
require_once('inc/shortcode/google-map.php');
if(function_exists('wpcf7')){
    require_once('inc/shortcode/contact-form.php');
}

//Sample data
require_once('inc/rit-sample-data/rit-sample-data.php');
?>