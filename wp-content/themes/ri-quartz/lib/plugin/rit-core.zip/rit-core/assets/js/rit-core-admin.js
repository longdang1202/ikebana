(function ($) {
    "use strict";

    var RIT_Admin = {
        init: function() {
            this.metabox.tab();
            this.metabox.toggle();
        },
        megamenu: {
            select_image: function() {

            }
        },
        metabox: {
            element: '#postbox-container-2 #normal-sortables',
            tab: function() {
                /*
                 var tab = '<ul id="rit-admin-tab-metabox">';
                 $(this.element + ' > .postbox').each(function() {
                 tab +=  '<li><a href="#'+$(this).attr('id')+'">'+$(this).find('h3.ui-sortable-handle span').text()+'</a></li>';
                 });
                 tab += '</ul>';
                 $(this.element).prepend(tab);
                 $(this.element).tabs();
                 */
            },

            // Show / Hidden element MetaBox
            toggle: function(){

                // SIDEBAR ------------------------------ //
                // SIDEBAR VARIABLES
                var rit_sidebar_options     = $('#rit_sidebar_options'),
                    rit_sidebar_padding       = $('#rit_sidebar_padding').closest('.rwmb-field');

                // SIDEBAR SHOW / HIDDEN
                function sidebar_toggle(){
                    if(rit_sidebar_options.val() == "use-default"){
                        rit_sidebar_padding.css("display", "none");
                    } else if(rit_sidebar_options.val() == "no-sidebar"){
                        rit_sidebar_padding.css("display", "none");
                    } else if(rit_sidebar_options.val() == ""){
                        rit_sidebar_padding.css("display", "none");
                    } else if(rit_sidebar_options.val() == "left-sidebar"){
                        rit_sidebar_padding.css("display", "block");
                    } else if(rit_sidebar_options.val() == "right-sidebar"){
                        rit_sidebar_padding.css("display", "block");
                    } else {
                        rit_sidebar_padding.css("display", "block");
                    }
                }
                sidebar_toggle();

                // SIDEBAR TOGGLE
                $(rit_sidebar_options).change(function(){
                    sidebar_toggle();
                });

                // END SIDEBAR ------------------------------ //

                // PAGE WIDTH OPTION ------------------------------ //
                // PAGE WIDTH VARIABLES
                var rit_enable_full_page       = $('#rit_enable_full_page'),
                    rit_body_background_image  = $('#rit_body_background_image_description').closest('.rwmb-field'),
                    rit_background_repeat  = $('#rit_background_repeat').closest('.rwmb-field'),
                    rit_background_size  = $('#rit_background_size').closest('.rwmb-field');

                // SLIDER SHOW / HIDDEN
                function page_width_toggle(){
                    if(rit_enable_full_page.val() == "boxed"){
                        rit_body_background_image.css("display", "block");
                        rit_background_repeat.css("display", "block");
                        rit_background_size.css("display", "block");
                    } else {
                        rit_body_background_image.css("display", "none");
                        rit_background_repeat.css("display", "none");
                        rit_background_size.css("display", "none");
                    }
                }
                page_width_toggle();

                // SLIDER TOGGLE
                $(rit_enable_full_page).change(function(){
                    page_width_toggle();
                });

                // PORTFOLIO OPTIONS ------------------------------ //
                // PORTFOLIO OPTIONS VARIABLES
                var rit_portfolio_information       = $('#rit_portfolio_information'),
                    rit_portfolio_client  = $('#rit_portfolio_client').closest('.rwmb-field'),
                    rit_portfolio_date_description  = $('#rit_portfolio_date_description').closest('.rwmb-field'),
                    rit_portfolio_link  = $('#rit_portfolio_link').closest('.rwmb-field'),
                    rit_portfolio_short_des  = $('#rit_portfolio_short_des').closest('.rwmb-field');

                // SLIDER SHOW / HIDDEN
                function portfolio_information_toggle(){
                    if((rit_portfolio_information).attr('checked')){
                        rit_portfolio_client.css("display", "block");
                        rit_portfolio_date_description.css("display", "block");
                        rit_portfolio_link.css("display", "block");
                        rit_portfolio_short_des.css("display", "block");
                    } else {
                        rit_portfolio_client.css("display", "none");
                        rit_portfolio_date_description.css("display", "none");
                        rit_portfolio_link.css("display", "none");
                        rit_portfolio_short_des.css("display", "none");
                    }
                }
                portfolio_information_toggle();

                // SLIDER TOGGLE
                $(rit_portfolio_information).change(function(){
                    portfolio_information_toggle();
                });

                // BOXED PAGE OPTION ------------------------------ //
                // BOXED PAGE VARIABLES
                var rit_page_width                  = $('#rit_page_width'),
                    rit_custom_bg_body              = $('#rit_custom_bg_body').closest('.rwmb-field'),
                    rit_bg_body_repeat              = $('#rit_bg_body_repeat').closest('.rwmb-field'),
                    rit_bg_body_size                = $('#rit_bg_body_size').closest('.rwmb-field'),
                    rit_bg_body_attachment          = $('#rit_bg_body_attachment').closest('.rwmb-field'),
                    rit_bg_body_image_description   = $('#rit_bg_body_image_description').closest('.rwmb-field')

                // SLIDER SHOW / HIDDEN
                function boxed_page_toggle(){
                    if(rit_page_width.val() == "boxed"){
                        rit_custom_bg_body.css("display", "block");
                        rit_bg_body_repeat.css("display", "block");
                        rit_bg_body_size.css("display", "block");
                        rit_bg_body_attachment.css("display", "block");
                        rit_bg_body_image_description.css("display", "block");
                    } else {
                        rit_custom_bg_body.css("display", "none");
                        rit_bg_body_repeat.css("display", "none");
                        rit_bg_body_size.css("display", "none");
                        rit_bg_body_attachment.css("display", "none");
                        rit_bg_body_image_description.css("display", "none");
                    }
                }
                boxed_page_toggle();

                // SLIDER TOGGLE
                $(rit_page_width).change(function(){
                    boxed_page_toggle();
                });


                // END TITLE OPTIONS ------------------------------ //
            }
        }
    };

    $(document).ready(function() {
        RIT_Admin.init();
    });
})(jQuery);