<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     2.0.3
 * @author      CleverSoft
 * @link        http://cleversoft.co
 * @copyright   Copyright (c) 2015 CleverSoft
 * @license     GPL v2
 */

if ( ! defined( 'RIT_VERSION' ) ){
    define('RIT_VERSION', '2.0.3');
}
if ( ! defined( 'RIT_PLUGIN_PATH' ) ){
    define('RIT_PLUGIN_PATH', plugin_dir_path( __FILE__ ));
}
if ( ! defined( 'RIT_PLUGIN_URL' ) ){
    define('RIT_PLUGIN_URL', plugins_url( '/', __FILE__ ));
}
if ( ! defined( 'RIT_DIRECTORY_NAME' ) ){
    $plugin_path = explode('/', str_replace('\\', '/', RIT_PLUGIN_PATH));
    define('RIT_DIRECTORY_NAME', $plugin_path[count($plugin_path) - 2 ]);
}